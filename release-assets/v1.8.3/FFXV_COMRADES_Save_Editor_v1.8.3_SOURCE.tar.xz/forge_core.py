from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any


class CoreError(RuntimeError):
    pass


def app_root() -> Path:
    # PyInstaller one-file extracts bundled data beneath sys._MEIPASS.
    # Source/folder builds use the project directory.
    bundle_root = getattr(sys, "_MEIPASS", None)
    if bundle_root:
        return Path(bundle_root)
    return Path(__file__).resolve().parent


class ForgeCore:
    """Small JSON client for the verified COMRADES save backend."""

    DEFAULT_TIMEOUT_SECONDS = 120

    def __init__(self, executable: str | Path | None = None) -> None:
        override = os.environ.get("FFXV_FORGE_CORE")
        if executable:
            self.exe = Path(executable)
        elif override:
            self.exe = Path(override)
        else:
            self.exe = app_root() / "Bundled" / "ForgeCore.exe"

    def _run(self, *args: str) -> Any:
        if not self.exe.is_file():
            raise CoreError(f"ForgeCore was not found:\n{self.exe}")
        flags = 0
        if os.name == "nt":
            flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        try:
            proc = subprocess.run(
                [str(self.exe), *args],
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                creationflags=flags,
                timeout=self.DEFAULT_TIMEOUT_SECONDS,
            )
        except subprocess.TimeoutExpired as exc:
            raise CoreError(
                f"ForgeCore did not finish within {self.DEFAULT_TIMEOUT_SECONDS} seconds.\n\n"
                "No save was exported by this request."
            ) from exc
        except OSError as exc:
            raise CoreError(f"ForgeCore could not be started:\n{self.exe}\n\n{exc}") from exc
        text = (proc.stdout or "").strip()
        if not text:
            detail = (proc.stderr or "").strip() or f"exit code {proc.returncode}"
            raise CoreError(f"ForgeCore returned no JSON output.\n\n{detail}")
        try:
            payload = json.loads(text.splitlines()[-1])
        except json.JSONDecodeError as exc:
            raise CoreError(f"Invalid ForgeCore response:\n{text[-2000:]}") from exc
        if not isinstance(payload, dict):
            raise CoreError("ForgeCore returned an unexpected JSON response.")
        if proc.returncode != 0 and payload.get("ok"):
            detail = (proc.stderr or "").strip() or f"exit code {proc.returncode}"
            raise CoreError(f"ForgeCore reported success but exited abnormally.\n\n{detail}")
        if not payload.get("ok"):
            raise CoreError(payload.get("error") or "ForgeCore operation failed")
        data = payload.get("data")
        if data is None:
            raise CoreError("ForgeCore returned success without a data payload.")
        return data

    def version(self) -> str:
        data = self._run("version")
        return str(data.get("version", "unknown"))

    def open_save(self, path: str | Path) -> dict[str, Any]:
        return self._run("open", "--input", str(Path(path)))

    def catalog(self) -> list[dict[str, Any]]:
        return self._run("catalog")

    def weapon_options(self) -> dict[str, Any]:
        return self._run("weapon-options")

    def open_avatar(self, path: str | Path) -> dict[str, Any]:
        return self._run("avatar-open", "--input", str(Path(path)))

    def apply_avatar(self, plain_path: str | Path, request: dict[str, Any]) -> dict[str, Any]:
        fd, temp_path = tempfile.mkstemp(prefix="ffxv_avatar_edits_", suffix=".json")
        os.close(fd)
        try:
            Path(temp_path).write_text(json.dumps(request, indent=2), encoding="utf-8")
            return self._run("avatar-apply", "--input", str(Path(plain_path)), "--edits", temp_path)
        finally:
            try:
                Path(temp_path).unlink(missing_ok=True)
            except OSError:
                pass

    def apply(self, plain_path: str | Path, request: dict[str, Any]) -> dict[str, Any]:
        fd, temp_path = tempfile.mkstemp(prefix="ffxv_edits_", suffix=".json")
        os.close(fd)
        try:
            Path(temp_path).write_text(json.dumps(request, indent=2), encoding="utf-8")
            return self._run("apply", "--input", str(Path(plain_path)), "--edits", temp_path)
        finally:
            try:
                Path(temp_path).unlink(missing_ok=True)
            except OSError:
                pass
