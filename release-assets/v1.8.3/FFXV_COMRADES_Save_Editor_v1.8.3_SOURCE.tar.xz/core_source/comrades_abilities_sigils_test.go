package main

import (
	"os"
	"testing"
)

func loadAbilitiesSigilsSample(t *testing.T) ([]byte, *SaveModel) {
	t.Helper()
	const path = "testdata/gameplay0.decrypted.save"
	input, err := os.ReadFile(path)
	if err != nil {
		t.Skip("uploaded COMRADES gameplay0 sample not present")
	}
	m, err := parseSaveModelBytes(input, path)
	if err != nil {
		t.Fatal(err)
	}
	if m.GameMode != "Comrades" || m.Comrades == nil {
		t.Fatal("COMRADES model not detected")
	}
	return input, m
}

func TestComradesAbilityAndTreeLayoutParsed(t *testing.T) {
	_, m := loadAbilitiesSigilsSample(t)
	if len(m.ComradesAbilities) != 6 {
		t.Fatalf("expected 6 initialized active-Glaive abilities in reference save, got %d", len(m.ComradesAbilities))
	}
	if m.ComradesAbilities[0].FixID != 0x0104625F {
		t.Fatalf("unexpected first Glaive ability 0x%08X", m.ComradesAbilities[0].FixID)
	}
	if m.ComradesAbilityTree == nil {
		t.Fatal("ability tree not parsed")
	}
	if len(m.ComradesAbilityTree.Enabled) != 8 || len(m.ComradesAbilityTree.ReleaseBlocked) != 0 {
		t.Fatalf("unexpected ability-tree progression: enabled=%d releaseBlocked=%d", len(m.ComradesAbilityTree.Enabled), len(m.ComradesAbilityTree.ReleaseBlocked))
	}
}

func TestComradesExistingCharacterAbilityRoundTrip(t *testing.T) {
	input, m := loadAbilitiesSigilsSample(t)
	a := &m.ComradesAbilities[0]
	wantEnabled := !a.Enabled()
	wantLevel := int32(7)
	if err := stageComradesCharacterAbility(m, a.FixID, wantEnabled, wantLevel); err != nil {
		t.Fatal(err)
	}
	g := GeneralEdits{ControlledCharacter: m.Party.ControlledCharacter, Chapter: m.Party.Chapter, Gil: m.Party.Gil, ArenaMedals: m.Party.ArenaMedals, OracleCoins: m.Party.OracleCoins, AbilityPoints: m.Party.AbilityPoints}
	out, _, _, _, err := applyModelEdits(input, m, g)
	if err != nil {
		t.Fatal(err)
	}
	got, err := parseSaveModelBytes(out, "ability-roundtrip.decrypted.save")
	if err != nil {
		t.Fatal(err)
	}
	ga := comradesCharacterAbilityByFixID(got, a.FixID)
	if ga == nil || ga.Enabled() != wantEnabled || ga.Level != wantLevel || ga.Count != a.Count {
		t.Fatalf("character ability did not survive reparse: %+v", ga)
	}
}

func TestComradesPlaceholderSigilSynthesisIsDisabled(t *testing.T) {
	_, m := loadAbilitiesSigilsSample(t)
	entry := comradesSigilCatalog[0]
	r := findMasterRecord(m, "Accessories", entry.Bank)
	if r == nil || !isPlaceholderEquipment(r.FixID) {
		t.Skip("reference save no longer has placeholder Royal-Sigil bank")
	}
	before := *r
	if err := stageComradesSigilOwnership(m, entry.Bank, true); err == nil {
		t.Fatal("expected placeholder Royal-Sigil synthesis to be rejected")
	}
	if *r != before {
		t.Fatal("rejected Sigil synthesis modified the placeholder record")
	}
}

func TestComradesCharacterAbilityExactIdentityRejectsMismatch(t *testing.T) {
	_, m := loadAbilitiesSigilsSample(t)
	if len(m.ComradesAbilities) == 0 {
		t.Fatal("reference save has no character abilities")
	}
	a := m.ComradesAbilities[0]
	if err := stageComradesCharacterAbilityExact(m, 0, a.FixID, a.AbilityID+1, a.WeaponBankNumber, a.Enabled(), a.Level); err == nil {
		t.Fatal("expected exact ability identity mismatch to be rejected")
	}
}
