package main

import (
	"crypto/sha256"
	"encoding/binary"
	"encoding/hex"
	"errors"
	"fmt"
	"os"
)

type ComradesSystemSlot struct {
	Loadout            int
	Kind               string
	SlotIndex          int
	MarkerOffset       int
	FixID              uint32
	Type               uint32
	Category           uint32
	BankNumber         int32
	OriginalFixID      uint32
	OriginalType       uint32
	OriginalCategory   uint32
	OriginalBankNumber int32
}

type ComradesSystemData struct {
	Path         string
	SchemaOffset int
	RootMarker   int
	UseCharacter int32
	AvatarUseNo  int32
	Slots        []ComradesSystemSlot
	SHA256       string
}

func parseComradesSystemData(data []byte, path string) (*ComradesSystemData, error) {
	kind, err := detectFFXVPlainKind(data)
	if err != nil || kind != "Comrades system_data" {
		if err != nil {
			return nil, err
		}
		return nil, fmt.Errorf("expected Comrades system_data plaintext, got %s", kind)
	}
	schemaOffset, types, err := parseSchema(data)
	if err != nil {
		return nil, err
	}
	rootType := schemaTypeByName(types, "Black.Save.Config.SaveGameConfigNoxMultiplayer")
	equipType := schemaTypeByName(types, "Black.Save.Multiplay.SaveAvatarEquipmentStruct")
	childType := schemaTypeByName(types, "Black.Save.Equipment.SaveWeaponEquipmentStruct")
	if rootType == nil || equipType == nil || childType == nil {
		return nil, errors.New("Comrades system_data equipment schema is incomplete")
	}
	roots := findMarkers(data, rootType.Hash, schemaOffset)
	if len(roots) != 1 {
		return nil, fmt.Errorf("expected one SaveGameConfigNoxMultiplayer root, found %d", len(roots))
	}
	base := roots[0] + 8
	if base+8 > schemaOffset {
		return nil, errors.New("Comrades system_data root is truncated")
	}
	m := &ComradesSystemData{Path: path, SchemaOffset: schemaOffset, RootMarker: roots[0], UseCharacter: int32(binary.LittleEndian.Uint32(data[base : base+4])), AvatarUseNo: int32(binary.LittleEndian.Uint32(data[base+4 : base+8]))}
	if m.AvatarUseNo < 0 || m.AvatarUseNo > 7 {
		return nil, fmt.Errorf("active Comrades avatar loadout %d is outside 0..7", m.AvatarUseNo)
	}
	markers := findMarkers(data, equipType.Hash, schemaOffset)
	if len(markers) != 8 {
		return nil, fmt.Errorf("expected 8 SaveAvatarEquipmentStruct records, found %d", len(markers))
	}
	var childMarker [8]byte
	binary.LittleEndian.PutUint64(childMarker[:], childType.Hash)
	for loadout, at := range markers {
		pos := at + 8
		if pos+176 > schemaOffset {
			return nil, errors.New("Comrades avatar equipment record is truncated")
		}
		if binary.LittleEndian.Uint32(data[pos:pos+4]) != 4 {
			return nil, fmt.Errorf("loadout %d weapon count is not 4", loadout)
		}
		pos += 4
		for i := 0; i < 4; i++ {
			if string(data[pos:pos+8]) != string(childMarker[:]) {
				return nil, fmt.Errorf("loadout %d weapon slot %d marker mismatch", loadout, i+1)
			}
			pb := pos + 8
			s := ComradesSystemSlot{Loadout: loadout, Kind: "Weapon", SlotIndex: i + 1, MarkerOffset: pos, FixID: binary.LittleEndian.Uint32(data[pb : pb+4]), Type: binary.LittleEndian.Uint32(data[pb+4 : pb+8]), Category: binary.LittleEndian.Uint32(data[pb+8 : pb+12]), BankNumber: int32(binary.LittleEndian.Uint32(data[pb+12 : pb+16]))}
			s.OriginalFixID = s.FixID
			s.OriginalType = s.Type
			s.OriginalCategory = s.Category
			s.OriginalBankNumber = s.BankNumber
			m.Slots = append(m.Slots, s)
			pos += 24
		}
		if binary.LittleEndian.Uint32(data[pos:pos+4]) != 3 {
			return nil, fmt.Errorf("loadout %d accessory count is not 3", loadout)
		}
		pos += 4
		for i := 0; i < 3; i++ {
			if string(data[pos:pos+8]) != string(childMarker[:]) {
				return nil, fmt.Errorf("loadout %d accessory slot %d marker mismatch", loadout, i+1)
			}
			pb := pos + 8
			s := ComradesSystemSlot{Loadout: loadout, Kind: "Accessory", SlotIndex: i + 1, MarkerOffset: pos, FixID: binary.LittleEndian.Uint32(data[pb : pb+4]), Type: binary.LittleEndian.Uint32(data[pb+4 : pb+8]), Category: binary.LittleEndian.Uint32(data[pb+8 : pb+12]), BankNumber: int32(binary.LittleEndian.Uint32(data[pb+12 : pb+16]))}
			s.OriginalFixID = s.FixID
			s.OriginalType = s.Type
			s.OriginalCategory = s.Category
			s.OriginalBankNumber = s.BankNumber
			m.Slots = append(m.Slots, s)
			pos += 24
		}
	}
	h := sha256.Sum256(data)
	m.SHA256 = hex.EncodeToString(h[:])
	return m, nil
}

func loadComradesSystemData(path string) (*ComradesSystemData, []byte, string, error) {
	data, clean, err := readRegularFile(path)
	if err != nil {
		return nil, nil, clean, err
	}
	m, err := parseComradesSystemData(data, clean)
	if err != nil {
		return nil, nil, clean, err
	}
	return m, data, clean, nil
}

func activeComradesSystemSlot(m *ComradesSystemData, kind string, slot int) *ComradesSystemSlot {
	if m == nil {
		return nil
	}
	for i := range m.Slots {
		s := &m.Slots[i]
		if s.Loadout == int(m.AvatarUseNo) && s.Kind == kind && s.SlotIndex == slot {
			return s
		}
	}
	return nil
}

func stageComradesSystemWeapon(m *ComradesSystemData, slot int, entry ComradesWeaponCatalogEntry) error {
	if m == nil {
		return errors.New("load a decrypted Comrades system_data save first")
	}
	if slot < 1 || slot > 4 {
		return errors.New("weapon slot must be 1 through 4")
	}
	s := activeComradesSystemSlot(m, "Weapon", slot)
	if s == nil {
		return errors.New("active Comrades weapon slot was not found")
	}
	s.FixID = entry.FixID
	s.Type = entry.Type
	s.Category = 0
	s.BankNumber = entry.Bank
	return nil
}

func stageComradesSystemAccessory(m *ComradesSystemData, slot int, entry ComradesAccessoryCatalogEntry) error {
	if m == nil {
		return errors.New("load a decrypted Comrades system_data save first")
	}
	if slot < 1 || slot > 3 {
		return errors.New("accessory slot must be 1 through 3")
	}
	s := activeComradesSystemSlot(m, "Accessory", slot)
	if s == nil {
		return errors.New("active Comrades accessory slot was not found")
	}
	s.FixID = entry.FixID
	s.Type = entry.Type
	s.Category = 5
	s.BankNumber = entry.Bank
	return nil
}

func restoreComradesSystemSlots(m *ComradesSystemData) {
	if m == nil {
		return
	}
	for i := range m.Slots {
		s := &m.Slots[i]
		s.FixID = s.OriginalFixID
		s.Type = s.OriginalType
		s.Category = s.OriginalCategory
		s.BankNumber = s.OriginalBankNumber
	}
}

func applyComradesSystemEdits(input []byte, m *ComradesSystemData) ([]byte, int, int, error) {
	if m == nil {
		return nil, 0, 0, errors.New("no Comrades system_data model loaded")
	}
	out := append([]byte(nil), input...)
	allowed := map[int]bool{}
	changes := 0
	writeU32 := func(off int, v uint32) {
		binary.LittleEndian.PutUint32(out[off:off+4], v)
		for i := 0; i < 4; i++ {
			allowed[off+i] = true
		}
	}
	for i := range m.Slots {
		s := &m.Slots[i]
		changed := s.FixID != s.OriginalFixID || s.Type != s.OriginalType || s.Category != s.OriginalCategory || s.BankNumber != s.OriginalBankNumber
		if !changed {
			continue
		}
		if s.Kind == "Weapon" {
			entry := comradesWeaponCatalogByBank(s.BankNumber)
			if entry == nil || entry.FixID != s.FixID || entry.Type != s.Type || s.Category != 0 {
				return nil, 0, 0, fmt.Errorf("invalid Comrades weapon tuple in loadout %d slot %d", s.Loadout, s.SlotIndex)
			}
		} else if s.Kind == "Accessory" {
			entry := comradesAccessoryCatalogByBank(s.BankNumber)
			if entry == nil || entry.FixID != s.FixID || entry.Type != s.Type || s.Category != 5 {
				return nil, 0, 0, fmt.Errorf("invalid Comrades accessory tuple in loadout %d slot %d", s.Loadout, s.SlotIndex)
			}
		} else {
			return nil, 0, 0, fmt.Errorf("unsupported Comrades equipment kind %s", s.Kind)
		}
		pb := s.MarkerOffset + 8
		writeU32(pb, s.FixID)
		writeU32(pb+4, s.Type)
		writeU32(pb+8, s.Category)
		writeU32(pb+12, uint32(s.BankNumber))
		changes++
	}
	changedBytes := 0
	for i := range input {
		if input[i] != out[i] {
			changedBytes++
			if !allowed[i] {
				return nil, 0, 0, fmt.Errorf("unexpected system_data byte change at 0x%X", i)
			}
		}
	}
	if !equalBytes(out[len(out)-footerSize:], input[len(input)-footerSize:]) {
		return nil, 0, 0, errors.New("system_data edit changed FFXV footer")
	}
	v, err := parseComradesSystemData(out, m.Path)
	if err != nil {
		return nil, 0, 0, fmt.Errorf("edited system_data validation failed: %w", err)
	}
	for i := range m.Slots {
		a, b := m.Slots[i], v.Slots[i]
		if a.FixID != b.FixID || a.Type != b.Type || a.Category != b.Category || a.BankNumber != b.BankNumber {
			return nil, 0, 0, fmt.Errorf("system_data slot %d failed read-back validation", i)
		}
	}
	return out, changedBytes, changes, nil
}

func saveEditedComradesSystemData(inputPath string, input []byte, m *ComradesSystemData) (*EditedSaveResult, error) {
	out, changed, eqChanges, err := applyComradesSystemEdits(input, m)
	if err != nil {
		return nil, err
	}
	backup, err := uniqueVariantPathV2(inputPath, ".backup")
	if err != nil {
		return nil, err
	}
	output, err := uniqueVariantPathV2(inputPath, ".edited")
	if err != nil {
		return nil, err
	}
	if err = writeFileExclusive(backup, input, 0o644); err != nil {
		return nil, err
	}
	if err = writeFileExclusive(output, out, 0o644); err != nil {
		return nil, err
	}
	r := &EditedSaveResult{OutputPath: output, BackupPath: backup, ChangedBytes: changed, EquipmentChanges: eqChanges}
	sourceMeta := inputPath + metadataSuffix
	if _, e := os.Stat(sourceMeta); e == nil {
		if _, me := readMetadata(sourceMeta, input); me == nil {
			b, re := os.ReadFile(sourceMeta)
			if re != nil {
				return nil, re
			}
			r.MetadataPath = output + metadataSuffix
			if we := writeFileExclusive(r.MetadataPath, b, 0o600); we != nil {
				return nil, we
			}
			r.MetadataCopied = true
		} else {
			r.MetadataWarning = "A sidecar exists but failed validation and was not copied: " + me.Error()
		}
	} else if !os.IsNotExist(e) {
		r.MetadataWarning = "Could not inspect sidecar: " + e.Error()
	} else {
		r.MetadataWarning = "No .ffxvmeta.json sidecar was present. Built-in Encrypt requires a matching sidecar."
	}
	h := sha256.Sum256(out)
	r.SHA256 = hex.EncodeToString(h[:])
	return r, nil
}
