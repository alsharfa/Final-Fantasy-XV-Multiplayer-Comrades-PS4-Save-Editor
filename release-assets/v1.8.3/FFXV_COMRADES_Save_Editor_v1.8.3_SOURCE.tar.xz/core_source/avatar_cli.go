package main

import (
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"strings"
)

type avatarStatusSummary struct {
	SourcePath   string `json:"sourcePath"`
	PlainPath    string `json:"plainPath"`
	MetadataPath string `json:"metadataPath,omitempty"`
	WasEncrypted bool   `json:"wasEncrypted"`
	FileSize     int    `json:"fileSize"`
	SHA256       string `json:"sha256"`

	HP       uint32 `json:"hp"`
	HPMax    uint32 `json:"hpMax"`
	MP       uint32 `json:"mp"`
	MPMax    uint32 `json:"mpMax"`
	Level    uint32 `json:"level"`
	LevelMax uint32 `json:"levelMax"`
	Strength uint32 `json:"strength"`
	Vitality uint32 `json:"vitality"`
	Magic    uint32 `json:"magic"`
	Spirit   uint32 `json:"spirit"`
	Critical uint32 `json:"critical"`
}

type avatarStatusEditRequest struct {
	HP       uint32 `json:"hp"`
	HPMax    uint32 `json:"hpMax"`
	MP       uint32 `json:"mp"`
	MPMax    uint32 `json:"mpMax"`
	Level    uint32 `json:"level"`
	Strength uint32 `json:"strength"`
	Vitality uint32 `json:"vitality"`
	Magic    uint32 `json:"magic"`
	Spirit   uint32 `json:"spirit"`
	Critical uint32 `json:"critical"`
}

type avatarApplyResult struct {
	EditedPlainPath string              `json:"editedPlainPath"`
	ModdedPath      string              `json:"moddedPath,omitempty"`
	BackupPath      string              `json:"backupPath"`
	ChangedBytes    int                 `json:"changedBytes"`
	SHA256          string              `json:"sha256"`
	Summary         avatarStatusSummary `json:"summary"`
	Verification    map[string]any      `json:"verification"`
}

func summarizeAvatar(source, plainPath, metadataPath string, encrypted bool, m *ComradesAvatarFile, size int) avatarStatusSummary {
	return avatarStatusSummary{
		SourcePath: source, PlainPath: plainPath, MetadataPath: metadataPath,
		WasEncrypted: encrypted, FileSize: size, SHA256: m.SHA256,
		HP: m.HP, HPMax: m.HPMax, MP: m.MP, MPMax: m.MPMax,
		Level: m.Level, LevelMax: m.LevelMax,
		Strength: m.Strength, Vitality: m.Vitality, Magic: m.Magic,
		Spirit: m.Spirit, Critical: m.Critical,
	}
}

func openAvatarSave(path string) (*avatarStatusSummary, error) {
	input, normalized, err := readRegularFile(path)
	if err != nil {
		return nil, err
	}
	source := normalized
	plainPath := normalized
	metadataPath := ""
	encrypted := false

	kind, plainErr := detectFFXVPlainKind(input)
	if plainErr != nil {
		r, err := processFile(normalized, true)
		if err != nil {
			return nil, fmt.Errorf("avatar0 is neither supported plaintext nor decryptable FFXV data: %w", err)
		}
		plainPath, metadataPath, encrypted = r.OutputPath, r.MetadataPath, true
		input, _, err = readRegularFile(plainPath)
		if err != nil {
			return nil, err
		}
		kind, err = detectFFXVPlainKind(input)
		if err != nil {
			return nil, err
		}
	} else if _, err := os.Stat(plainPath + metadataSuffix); err == nil {
		metadataPath = plainPath + metadataSuffix
	}
	if kind != "Comrades avatar0" {
		return nil, fmt.Errorf("expected Comrades avatar0, detected %s", kind)
	}
	m, err := parseComradesAvatarFile(input, plainPath)
	if err != nil {
		return nil, err
	}
	s := summarizeAvatar(source, plainPath, metadataPath, encrypted, m, len(input))
	return &s, nil
}

func readAvatarEditRequest(path string) (avatarStatusEditRequest, error) {
	var r avatarStatusEditRequest
	b, err := os.ReadFile(path)
	if err != nil {
		return r, err
	}
	if err := json.Unmarshal(b, &r); err != nil {
		return r, fmt.Errorf("invalid avatar edits JSON: %w", err)
	}
	return r, nil
}

func applyAvatarStatus(plainPath, editsPath string) (*avatarApplyResult, error) {
	if strings.TrimSpace(plainPath) == "" || strings.TrimSpace(editsPath) == "" {
		return nil, errors.New("avatar apply requires plaintext avatar0 and edits JSON")
	}
	m, input, normalized, err := loadComradesAvatarFile(plainPath)
	if err != nil {
		return nil, err
	}
	req, err := readAvatarEditRequest(editsPath)
	if err != nil {
		return nil, err
	}
	if err := stageComradesAvatarStatus(m, req.HP, req.HPMax, req.MP, req.MPMax, req.Level, req.Strength, req.Vitality, req.Magic, req.Spirit, req.Critical); err != nil {
		return nil, err
	}
	edited, err := saveEditedComradesAvatar(normalized, input, m)
	if err != nil {
		return nil, err
	}

	result := &avatarApplyResult{
		EditedPlainPath: edited.OutputPath,
		BackupPath:      edited.BackupPath,
		ChangedBytes:    edited.ChangedBytes,
		SHA256:          edited.SHA256,
		Verification: map[string]any{
			"result": "PASS",
			"detail": "avatar0 status write was byte-whitelisted and reparsed successfully",
		},
	}

	// If this avatar came from the normal encrypted workflow, preserve the
	// metadata sidecar and immediately produce a verified encrypted import file.
	if edited.MetadataCopied {
		enc, err := processFile(edited.OutputPath, false)
		if err != nil {
			return nil, fmt.Errorf("avatar0 encryption failed after verified edit: %w", err)
		}
		result.ModdedPath = enc.OutputPath
		result.Verification["crypto"] = "encrypted output decrypts back to the edited avatar0 byte-for-byte"
	}

	outBytes, _, err := readRegularFile(edited.OutputPath)
	if err != nil {
		return nil, err
	}
	parsed, err := parseComradesAvatarFile(outBytes, edited.OutputPath)
	if err != nil {
		return nil, err
	}
	result.Summary = summarizeAvatar(edited.OutputPath, edited.OutputPath, edited.MetadataPath, false, parsed, len(outBytes))
	return result, nil
}
