package main

import (
	"path/filepath"
	"strings"
	"testing"
)

func TestCreateForgeWorkspaceIsTimestampedAndUnique(t *testing.T) {
	root := t.TempDir()
	input := filepath.Join(root, "gameplay0.decrypted.save")
	first, err := createForgeWorkspace(input)
	if err != nil {
		t.Fatal(err)
	}
	second, err := createForgeWorkspace(input)
	if err != nil {
		t.Fatal(err)
	}
	if first == second {
		t.Fatal("workspace path was reused")
	}
	if filepath.Base(filepath.Dir(first)) != "Forge_Output" {
		t.Fatalf("workspace parent=%q, want Forge_Output", filepath.Base(filepath.Dir(first)))
	}
	if !strings.Contains(filepath.Base(first), "-") {
		t.Fatalf("workspace %q does not look timestamped", first)
	}
	nestedInput := filepath.Join(first, "gameplay0.edited.save")
	third, err := createForgeWorkspace(nestedInput)
	if err != nil {
		t.Fatal(err)
	}
	if filepath.Dir(third) != filepath.Dir(first) {
		t.Fatalf("nested edit created a nested Forge_Output tree: first=%q third=%q", first, third)
	}
}

func TestGameplayPlaintextEncryptOutputUsesModdedGameplay0(t *testing.T) {
	root := t.TempDir()
	input := filepath.Join(root, "gameplay0.decrypted.save")
	out, err := uniqueOutputPath(input, false)
	if err != nil {
		t.Fatal(err)
	}
	if filepath.Base(out) != "gameplay0.save" {
		t.Fatalf("output base=%q, want gameplay0.save", filepath.Base(out))
	}
	if filepath.Base(filepath.Dir(out)) != "MODDED" {
		t.Fatalf("output folder=%q, want MODDED", filepath.Base(filepath.Dir(out)))
	}
}

func TestBuildApplyReportContainsRecoveryDetails(t *testing.T) {
	gil := uint32(999)
	kw := uint32(1234)
	req := applyRequest{Gil: &gil, KW: &kw, WeaponEdits: []weaponEditRequest{{Bank: 1}}}
	out := &applyResult{
		WorkspacePath:   `C:\save\Forge_Output\20260825-083700`,
		BackupPath:      `C:\save\backup.save`,
		EditedPlainPath: `C:\save\gameplay0.edited.save`,
		ModdedPath:      `C:\save\MODDED\gameplay0.save`,
		SaveStatus:      "complete",
		SHA256:          strings.Repeat("a", 64),
		Verification:    applyVerificationView{Result: "PASS", ModelReadback: "PASS", ProtectedFields: "PASS", EquipmentIntegrity: "PASS", SaveSizePreserved: true, FooterPreserved: true, UnexpectedByteChanges: 0, EncryptionRoundTrip: "PASS"},
	}
	report := buildApplyReport(`C:\save\gameplay0.decrypted.save`, []byte("original"), req, out)
	for _, want := range []string{"Core: 2.8.0-wpf", "Gil: 999", "kW: 1234", "Weapon edits: 1", "Save status: complete", "Encrypted import:", "Post-save verification", "Overall result: PASS", "Unexpected byte changes: 0", "Encryption round-trip: PASS"} {
		if !strings.Contains(report, want) {
			t.Fatalf("report missing %q\n%s", want, report)
		}
	}
}
