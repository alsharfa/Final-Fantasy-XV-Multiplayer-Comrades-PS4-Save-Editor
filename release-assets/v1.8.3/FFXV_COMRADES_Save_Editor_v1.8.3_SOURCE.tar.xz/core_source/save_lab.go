package main

import (
	"encoding/binary"
	"fmt"
	"math"
	"os"
	"path/filepath"
	"sort"
	"strings"
)

type saveDiffRange struct {
	Start   int
	End     int // exclusive
	Changed int
}

type schemaOccurrence struct {
	Offset int
	Type   string
	Hash   uint64
}

func collectSchemaOccurrences(data []byte, schemaOffset int, types []SchemaType) []schemaOccurrence {
	if schemaOffset <= 0 || schemaOffset > len(data) {
		schemaOffset = len(data)
	}
	byHash := make(map[uint64]string, len(types))
	for _, t := range types {
		byHash[t.Hash] = t.Name
	}
	out := make([]schemaOccurrence, 0, 512)
	for i := 0; i+8 <= schemaOffset; i++ {
		h := binary.LittleEndian.Uint64(data[i : i+8])
		if name, ok := byHash[h]; ok {
			out = append(out, schemaOccurrence{Offset: i, Type: name, Hash: h})
			i += 7
		}
	}
	return out
}

func nearestOccurrence(occ []schemaOccurrence, off int) *schemaOccurrence {
	if len(occ) == 0 {
		return nil
	}
	i := sort.Search(len(occ), func(i int) bool { return occ[i].Offset > off }) - 1
	if i < 0 {
		return nil
	}
	// Avoid attributing a remote earlier object when the changed byte is far away.
	if off-occ[i].Offset > 0x4000 {
		return nil
	}
	return &occ[i]
}

func diffSaveRanges(a, b []byte, mergeGap int) ([]saveDiffRange, int) {
	maxLen := len(a)
	if len(b) > maxLen {
		maxLen = len(b)
	}
	changedTotal := 0
	raw := make([]saveDiffRange, 0, 128)
	inRun := false
	start, changed := 0, 0
	for i := 0; i < maxLen; i++ {
		different := i >= len(a) || i >= len(b) || a[i] != b[i]
		if different {
			changedTotal++
			if !inRun {
				start, changed, inRun = i, 1, true
			} else {
				changed++
			}
		} else if inRun {
			raw = append(raw, saveDiffRange{Start: start, End: i, Changed: changed})
			inRun = false
		}
	}
	if inRun {
		raw = append(raw, saveDiffRange{Start: start, End: maxLen, Changed: changed})
	}
	if mergeGap <= 0 || len(raw) < 2 {
		return raw, changedTotal
	}
	merged := []saveDiffRange{raw[0]}
	for _, r := range raw[1:] {
		last := &merged[len(merged)-1]
		if r.Start-last.End <= mergeGap {
			last.End = r.End
			last.Changed += r.Changed
		} else {
			merged = append(merged, r)
		}
	}
	return merged, changedTotal
}

func valueProbe(data []byte, off int) string {
	if off < 0 || off >= len(data) {
		return "<out of range>"
	}
	parts := []string{fmt.Sprintf("u8=%d", data[off])}
	if off+2 <= len(data) {
		parts = append(parts, fmt.Sprintf("u16=%d", binary.LittleEndian.Uint16(data[off:off+2])))
	}
	if off+4 <= len(data) {
		u := binary.LittleEndian.Uint32(data[off : off+4])
		f := math.Float32frombits(u)
		parts = append(parts, fmt.Sprintf("u32=%d (0x%08X)", u, u))
		if !math.IsNaN(float64(f)) && !math.IsInf(float64(f), 0) && math.Abs(float64(f)) < 1e12 {
			parts = append(parts, fmt.Sprintf("f32=%g", f))
		}
		if n := knownFixIDName(u); n != "" {
			parts = append(parts, "FixID="+n)
		}
	}
	return strings.Join(parts, "  ")
}

func knownFixIDName(id uint32) string {
	if id == 0 {
		return ""
	}
	if n, ok := equipmentEnglishNames[id]; ok && n != "" {
		return n
	}
	if n, ok := itemEnglishNames[id]; ok && n != "" {
		return n
	}
	if n, ok := clothEnglishNames[id]; ok && n != "" {
		return n
	}
	for _, a := range abilityCatalog {
		if a.FixID == id {
			return a.Name
		}
	}
	return ""
}

func saveKindLabel(data []byte) string {
	if k, err := detectFFXVPlainKind(data); err == nil {
		return k
	}
	return "Unknown / unsupported plaintext"
}

func buildSaveCompareReport(pathA string, a []byte, pathB string, b []byte) string {
	ranges, changed := diffSaveRanges(a, b, 8)
	var typesA, typesB []SchemaType
	schemaA, schemaB := len(a), len(b)
	if off, t, err := parseSchema(a); err == nil {
		schemaA, typesA = off, t
	}
	if off, t, err := parseSchema(b); err == nil {
		schemaB, typesB = off, t
	}
	occA := collectSchemaOccurrences(a, schemaA, typesA)
	occB := collectSchemaOccurrences(b, schemaB, typesB)

	var sb strings.Builder
	fmt.Fprintf(&sb, "FFXV SAVE COMPARE REPORT\n\nA: %s\n   kind: %s\n   size: %d\nB: %s\n   kind: %s\n   size: %d\n\n", pathA, saveKindLabel(a), len(a), pathB, saveKindLabel(b), len(b))
	fmt.Fprintf(&sb, "Changed bytes: %d\nGrouped change regions (gap <= 8 bytes): %d\nSchema types: A=%d B=%d\nObject markers: A=%d B=%d\n\n", changed, len(ranges), len(typesA), len(typesB), len(occA), len(occB))
	if changed == 0 {
		sb.WriteString("The two files are byte-identical.\n")
		return sb.String()
	}
	sb.WriteString("CHANGE REGIONS\n")
	limit := len(ranges)
	if limit > 500 {
		limit = 500
	}
	for i := 0; i < limit; i++ {
		r := ranges[i]
		span := r.End - r.Start
		fmt.Fprintf(&sb, "\n#%03d  0x%X..0x%X  span=%d  changed=%d\n", i+1, r.Start, r.End-1, span, r.Changed)
		if oa := nearestOccurrence(occA, r.Start); oa != nil {
			fmt.Fprintf(&sb, "  A object: %s @ 0x%X  relative +0x%X\n", oa.Type, oa.Offset, r.Start-oa.Offset)
		}
		if ob := nearestOccurrence(occB, r.Start); ob != nil {
			fmt.Fprintf(&sb, "  B object: %s @ 0x%X  relative +0x%X\n", ob.Type, ob.Offset, r.Start-ob.Offset)
		}
		fmt.Fprintf(&sb, "  A: %s\n", valueProbe(a, r.Start))
		fmt.Fprintf(&sb, "  B: %s\n", valueProbe(b, r.Start))
		if span <= 8 && r.Changed <= 8 {
			sb.WriteString("  Candidate: compact scalar/flag change\n")
		}
	}
	if len(ranges) > limit {
		fmt.Fprintf(&sb, "\n... %d additional regions omitted from this report preview.\n", len(ranges)-limit)
	}
	sb.WriteString("\nUSAGE NOTE\nCompare controlled saves that differ by exactly one in-game action. Repeated pairs let you distinguish counters, flags, FixIDs and packed structures before enabling writes.\n")
	return sb.String()
}

func writeUniqueTextReport(inputPath, tag, text string) (string, error) {
	clean := filepath.Clean(inputPath)
	ext := filepath.Ext(clean)
	stem := strings.TrimSuffix(clean, ext)
	for i := 1; i <= 10000; i++ {
		out := stem + tag + ".txt"
		if i > 1 {
			out = fmt.Sprintf("%s%s_%d.txt", stem, tag, i)
		}
		if _, err := os.Stat(out); os.IsNotExist(err) {
			if err := writeFileExclusive(out, []byte(text), 0o644); err != nil {
				return "", err
			}
			return out, nil
		} else if err != nil {
			return "", err
		}
	}
	return "", fmt.Errorf("could not find unused report path")
}

func hexASCII(data []byte, start, count int) string {
	if start < 0 {
		start = 0
	}
	if start >= len(data) || count <= 0 {
		return ""
	}
	end := start + count
	if end > len(data) {
		end = len(data)
	}
	var b strings.Builder
	for row := start; row < end; row += 16 {
		rowEnd := row + 16
		if rowEnd > end {
			rowEnd = end
		}
		fmt.Fprintf(&b, "%08X  ", row)
		for i := row; i < row+16; i++ {
			if i < rowEnd {
				fmt.Fprintf(&b, "%02X ", data[i])
			} else {
				b.WriteString("   ")
			}
		}
		b.WriteString(" ")
		for i := row; i < rowEnd; i++ {
			c := data[i]
			if c >= 32 && c <= 126 {
				b.WriteByte(c)
			} else {
				b.WriteByte('.')
			}
		}
		b.WriteByte('\n')
	}
	return b.String()
}

func buildSchemaTypeExplorer(data []byte, model *SaveModel, typeIndex int) string {
	if model == nil || typeIndex < 0 || typeIndex >= len(model.Types) {
		return "No schema type selected."
	}
	t := model.Types[typeIndex]
	markers := findMarkers(data, t.Hash, model.SchemaOffset)
	var b strings.Builder
	fmt.Fprintf(&b, "STRUCTURE EXPLORER\nType: %s\nHash: 0x%016X\nParent: 0x%016X\nFields: %d\nOccurrences before schema: %d\n\n", t.Name, t.Hash, t.ParentHash, len(t.Fields), len(markers))
	b.WriteString("FIELDS\n")
	for _, f := range t.Fields {
		fmt.Fprintf(&b, "%-30s  %-34s  off 0x%X  size %d\n", f.Name, f.TypeName, f.Offset, f.Size)
	}
	if len(markers) == 0 {
		return b.String()
	}
	b.WriteString("\nOCCURRENCES\n")
	n := len(markers)
	if n > 64 {
		n = 64
	}
	for i := 0; i < n; i++ {
		fmt.Fprintf(&b, "[%02d] marker 0x%X payload 0x%X\n", i, markers[i], markers[i]+8)
	}
	if len(markers) > n {
		fmt.Fprintf(&b, "... %d more occurrence(s)\n", len(markers)-n)
	}
	first := markers[0]
	b.WriteString("\nFIRST OCCURRENCE RAW PREVIEW (marker + 160 bytes)\n")
	b.WriteString(hexASCII(data, first, 168))
	b.WriteString("\nFIRST OCCURRENCE FIELD PROBES\n")
	payload := first + 8
	for _, f := range t.Fields {
		off := payload + int(f.Offset)
		if off < 0 || off >= model.SchemaOffset {
			continue
		}
		fmt.Fprintf(&b, "%s @ +0x%X / file 0x%X: %s\n", f.Name, f.Offset, off, valueProbe(data, off))
	}
	b.WriteString("\nRead-only explorer: field offsets can be logical schema offsets; packed booleans/enums may shift physical bytes in some structures. Use Save Compare to prove write locations first.\n")
	return b.String()
}

func buildFullStructureReport(data []byte, model *SaveModel) string {
	if model == nil {
		return "No gameplay0 model loaded."
	}
	var b strings.Builder
	fmt.Fprintf(&b, "FFXV STRUCTURE REPORT\nFile: %s\nMode: %s\nSize: %d\nSchema offset: 0x%X\nTypes: %d\n\n", model.Path, model.GameMode, len(data), model.SchemaOffset, len(model.Types))
	for i, t := range model.Types {
		ms := findMarkers(data, t.Hash, model.SchemaOffset)
		fmt.Fprintf(&b, "[%04d] %s\n  hash=0x%016X parent=0x%016X fields=%d occurrences=%d", i, t.Name, t.Hash, t.ParentHash, len(t.Fields), len(ms))
		if len(ms) > 0 {
			b.WriteString(" offsets=")
			lim := len(ms)
			if lim > 12 {
				lim = 12
			}
			for j := 0; j < lim; j++ {
				if j != 0 {
					b.WriteString(",")
				}
				fmt.Fprintf(&b, "0x%X", ms[j])
			}
			if len(ms) > lim {
				fmt.Fprintf(&b, ",+%d more", len(ms)-lim)
			}
		}
		b.WriteByte('\n')
		for _, f := range t.Fields {
			fmt.Fprintf(&b, "    %-30s %-34s off=0x%X size=%d\n", f.Name, f.TypeName, f.Offset, f.Size)
		}
		b.WriteByte('\n')
	}
	return b.String()
}

func findAllU32(data []byte, limit int, v uint32) []int {
	if limit <= 0 || limit > len(data) {
		limit = len(data)
	}
	var needle [4]byte
	binary.LittleEndian.PutUint32(needle[:], v)
	out := make([]int, 0, 4)
	for i := 0; i+4 <= limit; i++ {
		if data[i] == needle[0] && data[i+1] == needle[1] && data[i+2] == needle[2] && data[i+3] == needle[3] {
			out = append(out, i)
			i += 3
		}
	}
	return out
}

func buildComradesDiscoveryReport(data []byte, model *SaveModel) string {
	if model == nil || model.GameMode != "Comrades" {
		return "Load a decrypted Comrades gameplay0 save first."
	}
	occ := collectSchemaOccurrences(data, model.SchemaOffset, model.Types)
	var b strings.Builder
	fmt.Fprintf(&b, "COMRADES DISCOVERY REPORT\nFile: %s\nSize: %d\nSchema offset: 0x%X\nTypes: %d\nObject markers: %d\n\n", model.Path, len(data), model.SchemaOffset, len(model.Types), len(occ))

	keywords := []string{"quest", "chocobo", "plant", "power", "electric", "energy", "avatar", "job", "command", "cloth", "appearance", "color", "outpost", "shop", "map"}
	b.WriteString("RELEVANT SCHEMA TYPES\n")
	for _, t := range model.Types {
		ln := strings.ToLower(t.Name)
		match := false
		for _, k := range keywords {
			if strings.Contains(ln, k) {
				match = true
				break
			}
		}
		if !match {
			continue
		}
		ms := findMarkers(data, t.Hash, model.SchemaOffset)
		fmt.Fprintf(&b, "- %s  occurrences=%d  hash=0x%016X\n", t.Name, len(ms), t.Hash)
		for _, f := range t.Fields {
			fmt.Fprintf(&b, "    %s : %s off=0x%X size=%d\n", f.Name, f.TypeName, f.Offset, f.Size)
		}
	}

	b.WriteString("\nROYAL SIGIL FixID SCAN\n")
	foundSigil := 0
	for _, s := range comradesSigilCatalog {
		hits := findAllU32(data, model.SchemaOffset, s.FixID)
		if len(hits) == 0 {
			continue
		}
		foundSigil += len(hits)
		fmt.Fprintf(&b, "%s  0x%08X  hits=%d\n", s.Name, s.FixID, len(hits))
		lim := len(hits)
		if lim > 8 {
			lim = 8
		}
		for _, h := range hits[:lim] {
			if o := nearestOccurrence(occ, h); o != nil {
				fmt.Fprintf(&b, "  0x%X  %s +0x%X\n", h, o.Type, h-o.Offset)
			} else {
				fmt.Fprintf(&b, "  0x%X\n", h)
			}
		}
	}
	if foundSigil == 0 {
		b.WriteString("No Royal Sigil FixIDs occur directly in this gameplay0 payload. That supports keeping direct equip gated until a controlled save pair identifies the job-command representation.\n")
	}

	for _, target := range []string{"Black.Save.Quest.SaveQuestGameInformationStruct", "Black.Save.Multiplay.SaveChocoboDataStruct", "Black.Save.Multiplay.SavePlantMapDataStruct"} {
		t := schemaTypeByName(model.Types, target)
		if t == nil {
			continue
		}
		ms := findMarkers(data, t.Hash, model.SchemaOffset)
		fmt.Fprintf(&b, "\n%s\nOccurrences: %d\n", target, len(ms))
		lim := len(ms)
		if lim > 24 {
			lim = 24
		}
		for i := 0; i < lim; i++ {
			p := ms[i] + 8
			fmt.Fprintf(&b, "[%02d] marker=0x%X payload=0x%X  %s\n", i, ms[i], p, valueProbe(data, p))
		}
		if len(ms) > lim {
			fmt.Fprintf(&b, "... %d more\n", len(ms)-lim)
		}
	}

	b.WriteString("\nNEXT MAPPING METHOD\n1. Make two decrypted saves differing by one action only.\n2. Use Compare With Save on the Advanced page.\n3. Repeat with a second controlled value change.\n4. Only promote a candidate to writable after its object, offset, type/range and read-back behavior are consistent.\n")
	return b.String()
}
