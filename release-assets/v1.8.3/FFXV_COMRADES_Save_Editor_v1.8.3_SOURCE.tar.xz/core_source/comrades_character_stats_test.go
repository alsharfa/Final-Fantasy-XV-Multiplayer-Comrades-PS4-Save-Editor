package main

import (
	"os"
	"testing"
)

func TestComradesCharacterStatsRoundTripWhenSamplePresent(t *testing.T) {
	const path = "testdata/gameplay0.decrypted.save"
	input, err := os.ReadFile(path)
	if err != nil {
		t.Skip("uploaded COMRADES gameplay0 sample not present")
	}
	m, err := parseSaveModelBytes(input, path)
	if err != nil {
		t.Fatal(err)
	}
	if m.GameMode != "Comrades" || m.Comrades == nil {
		t.Fatal("COMRADES character status not detected")
	}
	if m.Comrades.LevelMax < 2 {
		t.Fatal("unexpected level max")
	}

	level := uint32(2)
	if m.Comrades.LevelMax >= 73 {
		level = 73
	}
	if err := stageComradesStatus(m, 12345, 54321, 321, 999, level, 4321, 3456, 2345, 1234, 777, m.Comrades.Exp, m.Comrades.ExpTotal, m.Comrades.AbilityPoints); err != nil {
		t.Fatal(err)
	}
	g := GeneralEdits{
		ControlledCharacter: m.Party.ControlledCharacter,
		Chapter:             m.Party.Chapter,
		Gil:                 m.Party.Gil,
		ArenaMedals:         m.Party.ArenaMedals,
		OracleCoins:         m.Party.OracleCoins,
		AbilityPoints:       m.Party.AbilityPoints,
	}
	out, _, _, _, err := applyModelEdits(input, m, g)
	if err != nil {
		t.Fatal(err)
	}
	got, err := parseSaveModelBytes(out, "character-roundtrip.decrypted.save")
	if err != nil {
		t.Fatal(err)
	}
	c := got.Comrades
	if c == nil {
		t.Fatal("character status missing after reparse")
	}
	if c.HP != 12345 || c.HPMax != 54321 || c.MP != 321 || c.MPMax != 999 || c.Level != level || c.Strength != 4321 || c.Vitality != 3456 || c.Magic != 2345 || c.Spirit != 1234 || c.Critical != 777 {
		t.Fatalf("character stats did not round-trip: %+v", c)
	}
}

func TestComradesCharacterSchemaUsesNamedDirectFieldsWhenSamplePresent(t *testing.T) {
	const path = "testdata/gameplay0.decrypted.save"
	input, err := os.ReadFile(path)
	if err != nil {
		t.Skip("uploaded COMRADES gameplay0 sample not present")
	}
	_, types, err := parseSchema(input)
	if err != nil {
		t.Fatal(err)
	}
	st := schemaTypeByName(types, "Black.Save.Player.SaveStatusStruct")
	if st == nil {
		t.Fatal("SaveStatusStruct missing")
	}
	present := map[string]bool{}
	for _, f := range st.Fields {
		present[f.Name] = true
	}
	for _, name := range []string{"hp", "hp_max", "mp", "mp_max", "level", "level_max", "strength", "vitality", "magic", "spirit", "critical"} {
		if !present[name] {
			t.Fatalf("verified field %q missing from SaveStatusStruct schema", name)
		}
	}
	if present["attack"] || present["defense"] || present["defence"] {
		t.Fatal("unexpected direct attack/defense total field appeared; review UI policy before exposing")
	}
}
