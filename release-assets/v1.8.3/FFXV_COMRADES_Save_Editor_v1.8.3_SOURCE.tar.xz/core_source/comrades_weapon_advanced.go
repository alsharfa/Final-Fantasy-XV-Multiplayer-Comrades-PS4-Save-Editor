package main

import (
	"errors"
	"fmt"
)

type comradesWeaponAdvancedEdits struct {
	Ability1            uint32
	Ability2            uint32
	ResidentAbility     uint32
	ResidentAbilityBank int32
	StatusAdjust        [19]int32
}

// stageComradesWeaponAdvanced edits only fields physically verified in the
// packed COMRADES SaveWeaponStruct: two serialized ability links, one resident
// ability link and the 19 status_adjust integers. The save schema contains two
// ability structures, not four. Weapon EXP and remodel/evolution identity are
// not present as writable fields in this record and are intentionally not
// synthesized here.
func stageComradesWeaponAdvanced(model *SaveModel, bank int, e comradesWeaponAdvancedEdits) (*EquipmentRecord, error) {
	if model == nil || model.GameMode != "Comrades" {
		return nil, errors.New("load a Comrades gameplay0 save first")
	}
	r := findMasterRecord(model, "Weapons", bank)
	if r == nil || r.FixID == 0 || isPlaceholderEquipment(r.FixID) {
		return nil, errors.New("selected Comrades weapon record is not initialized")
	}

	targetAbilities := [2]uint32{e.Ability1, e.Ability2}
	for i, id := range targetAbilities {
		current := r.Abilities[i].FixID
		if id == current {
			continue
		}
		if id == 0 {
			return nil, fmt.Errorf("ability slot %d cannot be newly set to raw zero; select the canonical None ability instead", i+1)
		}
		if !isVerifiedComradesWeaponAbility(id) {
			return nil, fmt.Errorf("ability slot %d is not a verified COMRADES weapon ability", i+1)
		}
		r.Abilities[i] = AbilityLink{FixID: id, BankNumber: -1}
	}

	if e.ResidentAbility != r.ResidentAbility.FixID || e.ResidentAbilityBank != r.ResidentAbility.BankNumber {
		if e.ResidentAbility == 0 {
			return nil, errors.New("resident ability cannot be newly set to raw zero; select the verified None resident preset instead")
		}
		valid := false
		for _, p := range comradesResidentPresets {
			if p.FixID == e.ResidentAbility && p.Bank == e.ResidentAbilityBank {
				valid = true
				break
			}
		}
		if !valid {
			return nil, errors.New("resident ability is not one of the verified COMRADES presets")
		}
		r.ResidentAbility = AbilityLink{FixID: e.ResidentAbility, BankNumber: e.ResidentAbilityBank}
	}

	all9999 := true
	for i, v := range e.StatusAdjust {
		// Some legitimate evolved weapons carry a larger opaque value in an
		// unknown status slot (for example 60800 in a verified Parrying Daggers
		// record). Preserve such existing values exactly; only refuse a newly
		// introduced out-of-range value.
		if (v < -9999 || v > 9999) && v != r.StatusAdjust[i] {
			return nil, fmt.Errorf("status adjustment %d must be between -9999 and 9999 unless preserving the loaded value %d", i+1, r.StatusAdjust[i])
		}
		if v != 9999 {
			all9999 = false
		}
	}
	if all9999 {
		return nil, errors.New("the all-9999 raw status profile is a known destructive pattern and cannot be written")
	}
	r.StatusAdjust = e.StatusAdjust
	return r, nil
}
