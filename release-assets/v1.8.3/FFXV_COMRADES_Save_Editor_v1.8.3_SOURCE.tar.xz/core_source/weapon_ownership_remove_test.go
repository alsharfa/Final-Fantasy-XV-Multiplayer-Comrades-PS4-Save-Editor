package main

import (
	"os"
	"testing"
)

func TestComradesWeaponOwnershipCanBeRemovedWhenNotEquipped(t *testing.T) {
	const path = "testdata/gameplay0_decrypted(2).save"
	plain, err := os.ReadFile(path)
	if os.IsNotExist(err) {
		t.Skip("uploaded Comrades sample not present")
	}
	if err != nil {
		t.Fatal(err)
	}
	m, err := parseSaveModelBytes(plain, path)
	if err != nil {
		t.Fatal(err)
	}

	var target *EquipmentRecord
	for i := range m.Equipment {
		r := &m.Equipment[i]
		if r.Category != "Weapons" || !r.Exists || r.FixID == 0 || isPlaceholderEquipment(r.FixID) {
			continue
		}
		if r.EquipmentOwner >= 0 {
			continue
		}
		if _, _, _, assigned := equipmentRecordAssignedTo(m, "Weapons", uint32(r.CategoryIndex)); assigned {
			continue
		}
		target = r
		break
	}
	if target == nil {
		t.Skip("no owned unequipped initialized weapon in sample")
	}

	bank := target.CategoryIndex
	if _, err := stageComradesWeaponOwnershipState(m, bank, false); err != nil {
		t.Fatal(err)
	}
	if target.Exists {
		t.Fatal("weapon was not staged as unowned")
	}

	g := GeneralEdits{ControlledCharacter: m.Party.ControlledCharacter, Chapter: m.Party.Chapter, Gil: m.Party.Gil, ArenaMedals: m.Party.ArenaMedals, OracleCoins: m.Party.OracleCoins, AbilityPoints: m.Party.AbilityPoints}
	out, _, _, _, err := applyModelEdits(plain, m, g)
	if err != nil {
		t.Fatal(err)
	}
	got, err := parseSaveModelBytes(out, "ownership-remove.decrypted.save")
	if err != nil {
		t.Fatal(err)
	}
	reread := findMasterRecord(got, "Weapons", bank)
	if reread == nil || reread.Exists {
		t.Fatalf("weapon bank %d removal did not survive save reparse: %+v", bank, reread)
	}
}

func TestComradesWeaponRemovalRejectsEquippedWeapon(t *testing.T) {
	m := &SaveModel{
		GameMode: "Comrades",
		Equipment: []EquipmentRecord{{
			Category: "Weapons", CategoryIndex: 5, FixID: 0x01000001, Exists: true,
		}},
		Equipped: []EquippedSlot{{
			Character: "Avatar", Kind: "Weapon", SlotIndex: 1, FixID: 0x01000001, Category: 0, BankNumber: 5,
		}},
	}
	if _, err := stageComradesWeaponOwnershipState(m, 5, false); err == nil {
		t.Fatal("expected equipped weapon removal to be rejected")
	}
	if !m.Equipment[0].Exists {
		t.Fatal("equipped weapon ownership changed despite rejection")
	}
}
