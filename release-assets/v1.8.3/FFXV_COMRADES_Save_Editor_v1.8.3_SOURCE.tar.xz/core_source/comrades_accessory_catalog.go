package main

type ComradesAccessoryCatalogEntry struct {
	FixID uint32
	Type  uint32
	Bank  int32
	Name  string
}

// These are the initialized Comrades accessory master records present in the
// supplied retail Comrades gameplay0 schema. Empty master slots are not
// synthesized because doing so would require unverified weapon.bin parameter
// payload fields, not just a FixID.
var comradesAccessoryCatalog = []ComradesAccessoryCatalogEntry{
	{0x0104CFBE, 48, 0, "HP-8700K Booster"},
	{0x0104CFBF, 49, 1, "MP-8700K Booster"},
	{0x0104CFB3, 48, 2, "Ring of Resistance"},
	{0x0104CFB4, 48, 3, "Nixperience Band"},
	{0x0104CFB5, 48, 4, "AP Adapter"},
	{0x0104CFB6, 49, 5, "Tech Turbocharger"},
	{0x0104CFB7, 49, 6, "Armiger Accelerator"},
	{0x0104CFB8, 48, 7, "Warrior's Fanfare"},
	{0x0104CFB9, 48, 8, "Blitzer's Fanfare"},
	{0x0104CFBA, 48, 9, "Tactician's Fanfare"},
	{0x0104CFBB, 48, 10, "Key of Prosperity"},
	{0x0104CFBC, 49, 11, "Radiant Gemstone"},
	{0x0104CFBD, 49, 12, "Stamina Badge"},
	{0x0104CFC0, 48, 13, "Accessory DLC 013"},
	{0x0104CFC1, 48, 14, "Accessory DLC 014"},
	{0x0104CFC2, 48, 15, "Accessory DLC 015"},
	{0x0104CFC3, 48, 16, "Accessory DLC 016"},
	{0x0104CFC4, 48, 17, "Accessory DLC 017"},
	{0x0104CFC5, 48, 18, "Accessory DLC 018"},
	{0x0104CFC6, 48, 19, "Accessory DLC 019"},
	{0x0104CFC7, 48, 20, "Accessory DLC 020"},
	{0x0104CFC8, 48, 21, "Accessory DLC 021"},
	{0x0104CFC9, 48, 22, "Accessory DLC 022"},
	{0x0104CFCA, 48, 23, "Accessory DLC 023"},
	{0x0104CFCB, 48, 24, "Accessory DLC 024"},
	{0x0104CFCC, 48, 25, "Accessory DLC 025"},
	{0x0104CFCD, 48, 26, "Accessory DLC 026"},
	{0x0104CFCE, 48, 27, "Accessory DLC 027"},
	{0x0104CFCF, 48, 28, "Accessory DLC 028"},
	{0x0104CFD0, 48, 29, "Accessory DLC 029"},
	{0x0104CFD1, 48, 30, "Accessory DLC 030"},
	{0x0104CFD2, 48, 31, "Accessory DLC 031"},
}

func comradesAccessoryCatalogByBank(bank int32) *ComradesAccessoryCatalogEntry {
	for i := range comradesAccessoryCatalog {
		if comradesAccessoryCatalog[i].Bank == bank {
			return &comradesAccessoryCatalog[i]
		}
	}
	return nil
}
func comradesAccessoryCatalogByFixID(id uint32) *ComradesAccessoryCatalogEntry {
	for i := range comradesAccessoryCatalog {
		if comradesAccessoryCatalog[i].FixID == id {
			return &comradesAccessoryCatalog[i]
		}
	}
	return nil
}

type ComradesSigilCatalogEntry struct {
	FixID    uint32
	Name     string
	Internal string
	JobIndex int32
	Type     uint32
	NameID   uint32
	Bank     int
}

var comradesSigilCatalog = []ComradesSigilCatalogEntry{
	{0x0105B580, "The Father's Sigil: Revitalize", "ACCESSORY_MP_JOB_000", 0, 48, 0x0B0192DB, 32},
	{0x0105B582, "The Warrior's Sigil: Untouchable", "ACCESSORY_MP_JOB_002", 2, 48, 0x0B0192DD, 33},
	{0x0105B583, "The Wanderer's Sigil: Cheer", "ACCESSORY_MP_JOB_003", 8, 48, 0x0B0192DE, 34},
	{0x0105B584, "The Mystic's Sigil: Graviton", "ACCESSORY_MP_JOB_004", 11, 48, 0x0B0192DF, 35},
	{0x0105B585, "The Rogue's Sigil: Aerial Ace", "ACCESSORY_MP_JOB_005", 4, 48, 0x0B0192E0, 36},
	{0x0105B586, "The Clever's Sigil: Spectral Arms", "ACCESSORY_MP_JOB_006", 10, 48, 0x0B0192E1, 37},
	{0x0105B587, "The Pious's Sigil: Multicast", "ACCESSORY_MP_JOB_007", 6, 48, 0x0B0192E2, 38},
	{0x0105B588, "The Just's Sigil: Omniguard", "ACCESSORY_MP_JOB_008", 1, 48, 0x0B0192E3, 39},
	{0x0105B589, "The Fierce's Sigil: Rampage", "ACCESSORY_MP_JOB_009", 9, 48, 0x0B0192E4, 40},
	{0x0105B58A, "The Tall's Sigil: Aura", "ACCESSORY_MP_JOB_010", 3, 48, 0x0B0192E5, 41},
	{0x0105B58B, "The Oracle's Sigil: Healing Light", "ACCESSORY_MP_JOB_011", 7, 48, 0x0B0192E6, 42},
	{0x0105E31D, "The Wise's Sigil: Dragoon Drain", "ACCESSORY_MP_JOB_301", 5, 48, 0x0B0192DC, 43},
	{0x01061716, "The Conqueror's Sigil: Elemancy", "ACCESSORY_MP_JOB_900", 12, 48, 0x0B01A8E2, 44},
	{0x01062D60, "Founder King's Sigil", "ACCESSORY_GOTY_NOC_010", 165, 49, 0x0B01C039, 45},
}

func comradesSigilCatalogByBank(bank int) *ComradesSigilCatalogEntry {
	for i := range comradesSigilCatalog {
		if comradesSigilCatalog[i].Bank == bank {
			return &comradesSigilCatalog[i]
		}
	}
	return nil
}
