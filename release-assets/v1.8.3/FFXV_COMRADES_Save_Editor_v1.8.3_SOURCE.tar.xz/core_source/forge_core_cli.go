package main

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"time"
)

type coreResponse struct {
	OK      bool        `json:"ok"`
	Error   string      `json:"error,omitempty"`
	Data    interface{} `json:"data,omitempty"`
	Version string      `json:"version"`
}

const coreVersion = "2.8.0-wpf"

type weaponView struct {
	Bank                    int       `json:"bank"`
	FixID                   uint32    `json:"fixId"`
	FixIDHex                string    `json:"fixIdHex"`
	Name                    string    `json:"name"`
	Type                    uint32    `json:"type"`
	Initialized             bool      `json:"initialized"`
	Owned                   bool      `json:"owned"`
	Hidden                  bool      `json:"hidden"`
	EquipmentOwner          int32     `json:"equipmentOwner"`
	EquipmentSlot           int32     `json:"equipmentSlot"`
	AvailableToActiveGlaive bool      `json:"availableToActiveGlaive"`
	EquippedByActiveGlaive  bool      `json:"equippedByActiveGlaive"`
	Rank                    int32     `json:"rank"`
	Attack                  int32     `json:"attack"`
	Vitality                int32     `json:"vitality"`
	Critical                int32     `json:"critical"`
	RecoverMP               int32     `json:"recoverMp"`
	SlotCount               int32     `json:"slotCount"`
	RemodelFails            int32     `json:"remodelFails"`
	Ability1                uint32    `json:"ability1"`
	Ability2                uint32    `json:"ability2"`
	Ability1Name            string    `json:"ability1Name"`
	Ability2Name            string    `json:"ability2Name"`
	ResidentAbility         uint32    `json:"residentAbility"`
	ResidentAbilityBank     int32     `json:"residentAbilityBank"`
	ResidentAbilityName     string    `json:"residentAbilityName"`
	StatusAdjust            [19]int32 `json:"statusAdjust"`
}

type weaponAbilityOptionView struct {
	FixID    uint32 `json:"fixId"`
	FixIDHex string `json:"fixIdHex"`
	Name     string `json:"name"`
	RawLabel string `json:"rawLabel"`
	Writable bool   `json:"writable"`
}

type weaponResidentOptionView struct {
	FixID    uint32 `json:"fixId"`
	FixIDHex string `json:"fixIdHex"`
	Name     string `json:"name"`
	Bank     int32  `json:"bank"`
	Writable bool   `json:"writable"`
}

type weaponOptionsView struct {
	Abilities              []weaponAbilityOptionView  `json:"abilities"`
	Residents              []weaponResidentOptionView `json:"residents"`
	CraftingFields         []string                   `json:"craftingFields"`
	SerializedAbilitySlots int                        `json:"serializedAbilitySlots"`
	WeaponExpWritable      bool                       `json:"weaponExpWritable"`
	EvolutionWritable      bool                       `json:"evolutionWritable"`
}

type collectionEntryView struct {
	FixID    uint32 `json:"fixId"`
	FixIDHex string `json:"fixIdHex"`
	Name     string `json:"name"`
	Label    string `json:"label"`
	Category string `json:"category"`
	Quantity int32  `json:"quantity"`
	Owned    bool   `json:"owned"`
}

type collectionGroupView struct {
	Kind        string                `json:"kind"`
	Owned       int                   `json:"owned"`
	Total       int                   `json:"total"`
	Recommended int32                 `json:"recommendedQuantity"`
	Entries     []collectionEntryView `json:"entries"`
}

type inventoryEntryView struct {
	FixID    uint32 `json:"fixId"`
	FixIDHex string `json:"fixIdHex"`
	Name     string `json:"name"`
	Label    string `json:"label"`
	Category string `json:"category"`
	Quantity int32  `json:"quantity"`
	Owned    bool   `json:"owned"`
}

type inventoryGroupView struct {
	Kind        string               `json:"kind"`
	Owned       int                  `json:"owned"`
	Total       int                  `json:"total"`
	Recommended int32                `json:"recommendedQuantity"`
	Entries     []inventoryEntryView `json:"entries"`
}

type characterStatsView struct {
	Name      string `json:"name"`
	SaveIndex uint32 `json:"saveIndex"`
	HP        uint32 `json:"hp"`
	HPMax     uint32 `json:"hpMax"`
	MP        uint32 `json:"mp"`
	MPMax     uint32 `json:"mpMax"`
	Level     uint32 `json:"level"`
	LevelMax  uint32 `json:"levelMax"`
	Strength  uint32 `json:"strength"`
	Vitality  uint32 `json:"vitality"`
	Magic     uint32 `json:"magic"`
	Spirit    uint32 `json:"spirit"`
	Critical  uint32 `json:"critical"`
}

type equipmentOptionView struct {
	Bank     int    `json:"bank"`
	FixID    uint32 `json:"fixId"`
	FixIDHex string `json:"fixIdHex"`
	Name     string `json:"name"`
	Type     uint32 `json:"type"`
	Owned    bool   `json:"owned"`
}

type equipmentSlotView struct {
	Kind     string `json:"kind"`
	Slot     int    `json:"slot"`
	Role     string `json:"role"`
	Bank     int    `json:"bank"`
	FixID    uint32 `json:"fixId"`
	FixIDHex string `json:"fixIdHex"`
	Name     string `json:"name"`
	Empty    bool   `json:"empty"`
}

type rawEquipmentView struct {
	FixID    uint32 `json:"fixId"`
	FixIDHex string `json:"fixIdHex"`
	Type     uint32 `json:"type"`
	Bank     int32  `json:"bank"`
	Name     string `json:"name"`
	Writable bool   `json:"writable"`
	Note     string `json:"note"`
}

type equipmentSummaryView struct {
	SaveIndex        uint32                `json:"saveIndex"`
	AvatarName       string                `json:"avatarName"`
	WeaponSlots      []equipmentSlotView   `json:"weaponSlots"`
	AccessorySlots   []equipmentSlotView   `json:"accessorySlots"`
	WeaponOptions    []equipmentOptionView `json:"weaponOptions"`
	AccessoryOptions []equipmentOptionView `json:"accessoryOptions"`
	Sigil            rawEquipmentView      `json:"sigil"`
	Clothing         rawEquipmentView      `json:"clothing"`
}

type sigilView struct {
	Bank        int    `json:"bank"`
	FixID       uint32 `json:"fixId"`
	FixIDHex    string `json:"fixIdHex"`
	Name        string `json:"name"`
	Internal    string `json:"internal"`
	JobIndex    int32  `json:"jobIndex"`
	Owned       bool   `json:"owned"`
	Initialized bool   `json:"initialized"`
	Writable    bool   `json:"writable"`
}

type characterAbilityView struct {
	RecordIndex int    `json:"recordIndex"`
	FixID       uint32 `json:"fixId"`
	FixIDHex    string `json:"fixIdHex"`
	Name        string `json:"name"`
	RawLabel    string `json:"rawLabel"`
	AbilityID   uint32 `json:"abilityId"`
	Level       int32  `json:"level"`
	Enabled     bool   `json:"enabled"`
	Flags       uint8  `json:"flags"`
	FlagsHex    string `json:"flagsHex"`
	FlagsText   string `json:"flagsText"`
	Count       int32  `json:"count"`
	WeaponBank  int32  `json:"weaponBank"`
}

type abilityTreeEntityView struct {
	FixID      uint32 `json:"fixId"`
	FixIDHex   string `json:"fixIdHex"`
	BankNumber int32  `json:"bankNumber"`
}

type abilityTreeView struct {
	Enabled        []abilityTreeEntityView `json:"enabled"`
	ReleaseBlocked []string                `json:"releaseBlocked"`
	Writable       bool                    `json:"writable"`
	Note           string                  `json:"note"`
}

type abilitiesSigilsView struct {
	Sigils             []sigilView            `json:"sigils"`
	SelectedSigil      rawEquipmentView       `json:"selectedSigil"`
	CharacterAbilities []characterAbilityView `json:"characterAbilities"`
	AbilityTree        abilityTreeView        `json:"abilityTree"`
}

type healthCheckView struct {
	Name   string `json:"name"`
	Status string `json:"status"`
	Detail string `json:"detail"`
}

type saveHealthView struct {
	Status     string            `json:"status"`
	Confidence string            `json:"confidence"`
	Summary    string            `json:"summary"`
	Checks     []healthCheckView `json:"checks"`
}

type applyVerificationView struct {
	Result                string `json:"result"`
	ModelReadback         string `json:"modelReadback"`
	ProtectedFields       string `json:"protectedFields"`
	EquipmentIntegrity    string `json:"equipmentIntegrity"`
	SaveSizePreserved     bool   `json:"saveSizePreserved"`
	FooterPreserved       bool   `json:"footerPreserved"`
	UnexpectedByteChanges int    `json:"unexpectedByteChanges"`
	EncryptionRoundTrip   string `json:"encryptionRoundTrip"`
	ChangedBytes          int    `json:"changedBytes"`
}

type chocoboView struct {
	Index         int     `json:"index"`
	NameID        uint32  `json:"nameId"`
	NameIDHex     string  `json:"nameIdHex"`
	Name          string  `json:"name"`
	Personality   int32   `json:"personality"`
	Rarity        int32   `json:"rarity"`
	Color         int32   `json:"color"`
	Level         int16   `json:"level"`
	LevelCap      int16   `json:"levelCap"`
	LimitMaxLevel int16   `json:"limitMaxLevel"`
	SkillLevel    int16   `json:"skillLevel"`
	Stamina       int32   `json:"stamina"`
	Jump          int32   `json:"jump"`
	Speed         float32 `json:"speed"`
	InjuryPercent int16   `json:"injuryPercent"`
	IsInjured     bool    `json:"isInjured"`
}

type saveSummary struct {
	SourcePath      string                `json:"sourcePath"`
	PlainPath       string                `json:"plainPath"`
	MetadataPath    string                `json:"metadataPath,omitempty"`
	WasEncrypted    bool                  `json:"wasEncrypted"`
	GameMode        string                `json:"gameMode"`
	SHA256          string                `json:"sha256"`
	FileSize        int                   `json:"fileSize"`
	Gil             uint32                `json:"gil"`
	KW              *uint32               `json:"kw,omitempty"`
	AvatarName      string                `json:"avatarName,omitempty"`
	SaveIndex       uint32                `json:"saveIndex,omitempty"`
	Character       *characterStatsView   `json:"character,omitempty"`
	Weapons         []weaponView          `json:"weapons"`
	Chocobos        []chocoboView         `json:"chocobos"`
	Collections     []collectionGroupView `json:"collections"`
	Inventory       []inventoryGroupView  `json:"inventoryGroups"`
	Equipment       *equipmentSummaryView `json:"equipment,omitempty"`
	AbilitiesSigils *abilitiesSigilsView  `json:"abilitiesSigils,omitempty"`
	Health          saveHealthView        `json:"health"`
}

type weaponEditRequest struct {
	Bank                int       `json:"bank"`
	Owned               bool      `json:"owned"`
	Rank                int32     `json:"rank"`
	Attack              int32     `json:"attack"`
	Vitality            int32     `json:"vitality"`
	Critical            int32     `json:"critical"`
	RecoverMP           int32     `json:"recoverMp"`
	SlotCount           int32     `json:"slotCount"`
	RemodelFails        int32     `json:"remodelFails"`
	Ability1            uint32    `json:"ability1"`
	Ability2            uint32    `json:"ability2"`
	ResidentAbility     uint32    `json:"residentAbility"`
	ResidentAbilityBank int32     `json:"residentAbilityBank"`
	StatusAdjust        [19]int32 `json:"statusAdjust"`
}

type chocoboEditRequest struct {
	Index         int     `json:"index"`
	Level         int16   `json:"level"`
	LevelCap      int16   `json:"levelCap"`
	LimitMaxLevel int16   `json:"limitMaxLevel"`
	SkillLevel    int16   `json:"skillLevel"`
	Stamina       int32   `json:"stamina"`
	Jump          int32   `json:"jump"`
	Speed         float32 `json:"speed"`
	InjuryPercent int16   `json:"injuryPercent"`
}

type characterEditRequest struct {
	HP       uint32 `json:"hp"`
	HPMax    uint32 `json:"hpMax"`
	MP       uint32 `json:"mp"`
	MPMax    uint32 `json:"mpMax"`
	Level    uint32 `json:"level"`
	Strength uint32 `json:"strength"`
	Vitality uint32 `json:"vitality"`
	Magic    uint32 `json:"magic"`
	Spirit   uint32 `json:"spirit"`
	Critical uint32 `json:"critical"`
}

type collectionEditRequest struct {
	Kind     string `json:"kind"`
	FixID    uint32 `json:"fixId"`
	Quantity int32  `json:"quantity"`
}

type collectionActionRequest struct {
	Kind   string `json:"kind"`
	Action string `json:"action"`
}

type inventoryEditRequest struct {
	Kind     string `json:"kind"`
	FixID    uint32 `json:"fixId"`
	Owned    bool   `json:"owned"`
	Quantity int32  `json:"quantity"`
}

type equipmentSlotEditRequest struct {
	Kind string `json:"kind"`
	Slot int    `json:"slot"`
	Bank int    `json:"bank"`
}

type sigilEditRequest struct {
	Bank  int  `json:"bank"`
	Owned bool `json:"owned"`
}

type characterAbilityEditRequest struct {
	RecordIndex int    `json:"recordIndex"`
	FixID       uint32 `json:"fixId"`
	AbilityID   uint32 `json:"abilityId"`
	WeaponBank  int32  `json:"weaponBank"`
	Enabled     bool   `json:"enabled"`
	Level       int32  `json:"level"`
}

type applyRequest struct {
	Gil                   *uint32                       `json:"gil,omitempty"`
	KW                    *uint32                       `json:"kw,omitempty"`
	Character             *characterEditRequest         `json:"character,omitempty"`
	WeaponEdits           []weaponEditRequest           `json:"weaponEdits,omitempty"`
	ChocoboEdits          []chocoboEditRequest          `json:"chocoboEdits,omitempty"`
	CollectionEdits       []collectionEditRequest       `json:"collectionEdits,omitempty"`
	CollectionActions     []collectionActionRequest     `json:"collectionActions,omitempty"`
	InventoryEdits        []inventoryEditRequest        `json:"inventoryEdits,omitempty"`
	EquipmentEdits        []equipmentSlotEditRequest    `json:"equipmentEdits,omitempty"`
	SigilEdits            []sigilEditRequest            `json:"sigilEdits,omitempty"`
	CharacterAbilityEdits []characterAbilityEditRequest `json:"characterAbilityEdits,omitempty"`
}

type applyResult struct {
	WorkspacePath    string                `json:"workspacePath"`
	ReportPath       string                `json:"reportPath,omitempty"`
	VerificationPath string                `json:"verificationPath,omitempty"`
	BackupPath       string                `json:"backupPath"`
	EditedPlainPath  string                `json:"editedPlainPath"`
	MetadataPath     string                `json:"metadataPath,omitempty"`
	MetadataWarning  string                `json:"metadataWarning,omitempty"`
	ModdedPath       string                `json:"moddedPath,omitempty"`
	SaveStatus       string                `json:"saveStatus"`
	EncryptionError  string                `json:"encryptionError,omitempty"`
	SHA256           string                `json:"sha256"`
	ChangedBytes     int                   `json:"changedBytes"`
	InventoryChanges int                   `json:"inventoryChanges"`
	EquipmentChanges int                   `json:"equipmentChanges"`
	Summary          saveSummary           `json:"summary"`
	Verification     applyVerificationView `json:"verification"`
}

type catalogRow struct {
	Kind     string `json:"kind"`
	Name     string `json:"name"`
	Label    string `json:"label"`
	FixID    uint32 `json:"fixId"`
	FixIDHex string `json:"fixIdHex"`
	Bank     int    `json:"bank"`
	Category string `json:"category"`
}

type canonicalItemEdit struct {
	Owned    bool
	Quantity int32
	Source   string
}

func validateCanonicalItemEdits(req applyRequest) error {
	seen := make(map[uint32]canonicalItemEdit)
	add := func(fixID uint32, owned bool, quantity int32, source string) error {
		if fixID == 0 {
			return fmt.Errorf("%s contains an invalid FixID 0", source)
		}
		if owned && (quantity < 1 || quantity > 99) {
			return fmt.Errorf("%s quantity must be 1 through 99", source)
		}
		if !owned {
			quantity = 0
		}
		want := canonicalItemEdit{Owned: owned, Quantity: quantity, Source: source}
		if prev, ok := seen[fixID]; ok {
			if prev.Owned != want.Owned || prev.Quantity != want.Quantity {
				return fmt.Errorf("conflicting edits for FixID 0x%08X: %s wants owned=%v qty=%d, while %s wants owned=%v qty=%d", fixID, prev.Source, prev.Owned, prev.Quantity, source, want.Owned, want.Quantity)
			}
			return nil
		}
		seen[fixID] = want
		return nil
	}
	for _, e := range req.CollectionEdits {
		if err := add(e.FixID, true, e.Quantity, "Collections/"+e.Kind); err != nil {
			return err
		}
	}
	for _, e := range req.InventoryEdits {
		if err := add(e.FixID, e.Owned, e.Quantity, "Inventory/"+e.Kind); err != nil {
			return err
		}
	}
	return nil
}

func emitOK(data interface{}) {
	_ = json.NewEncoder(os.Stdout).Encode(coreResponse{OK: true, Data: data, Version: coreVersion})
}

func emitErr(err error) {
	_ = json.NewEncoder(os.Stdout).Encode(coreResponse{OK: false, Error: err.Error(), Version: coreVersion})
}

func abilityName(id uint32) string {
	for _, a := range abilityCatalog {
		if a.FixID == id {
			if n := strings.TrimSpace(a.Name); n != "" {
				return prettyGameLabel(n)
			}
		}
	}
	if id == 0 {
		return "None"
	}
	return fmt.Sprintf("0x%08X", id)
}

func residentAbilityName(id uint32, bank int32) string {
	for _, p := range comradesResidentPresets {
		if p.FixID == id && p.Bank == bank {
			return p.Name
		}
	}
	if id == 0 {
		return "Raw empty"
	}
	return fmt.Sprintf("0x%08X / bank %d", id, bank)
}

func isVerifiedComradesWeaponAbility(id uint32) bool {
	if id == 0x01009E27 { // canonical NONE ability
		return true
	}
	for _, a := range abilityCatalog {
		if a.FixID == id {
			return strings.HasPrefix(strings.ToUpper(strings.TrimSpace(a.Name)), "ENC_")
		}
	}
	return false
}

func buildWeaponOptions() weaponOptionsView {
	o := weaponOptionsView{
		SerializedAbilitySlots: 2,
		WeaponExpWritable:      false,
		EvolutionWritable:      false,
	}
	// Raw zero is present in untouched/unowned templates. It is displayed so an
	// existing record can be represented exactly, but Forge refuses to newly
	// write raw zero over a populated ability; use the canonical NONE FixID.
	o.Abilities = append(o.Abilities, weaponAbilityOptionView{
		FixID: 0, FixIDHex: "0x00000000", Name: "Raw empty / uninitialized", RawLabel: "RAW_ZERO", Writable: false,
	})
	// Keep canonical None near the top of the dropdown.
	for _, a := range abilityCatalog {
		if a.FixID == 0x01009E27 {
			o.Abilities = append(o.Abilities, weaponAbilityOptionView{
				FixID: a.FixID, FixIDHex: fmt.Sprintf("0x%08X", a.FixID), Name: "None", RawLabel: a.Name, Writable: true,
			})
			break
		}
	}
	for _, a := range abilityCatalog {
		if a.FixID == 0x01009E27 || !isVerifiedComradesWeaponAbility(a.FixID) {
			continue
		}
		o.Abilities = append(o.Abilities, weaponAbilityOptionView{
			FixID: a.FixID, FixIDHex: fmt.Sprintf("0x%08X", a.FixID), Name: prettyGameLabel(a.Name), RawLabel: a.Name, Writable: true,
		})
	}
	if len(o.Abilities) > 2 {
		sort.SliceStable(o.Abilities[2:], func(i, j int) bool {
			return strings.ToLower(o.Abilities[2+i].Name) < strings.ToLower(o.Abilities[2+j].Name)
		})
	}
	o.Residents = append(o.Residents, weaponResidentOptionView{FixID: 0, FixIDHex: "0x00000000", Name: "Raw empty / uninitialized", Bank: 0, Writable: false})
	for _, p := range comradesResidentPresets {
		o.Residents = append(o.Residents, weaponResidentOptionView{FixID: p.FixID, FixIDHex: fmt.Sprintf("0x%08X", p.FixID), Name: p.Name, Bank: p.Bank, Writable: true})
	}
	labels := []string{
		"Strength bonus",
		"Vitality bonus",
		"Magic bonus",
		"Spirit bonus",
		"Max HP bonus",
		"Unknown status 06",
		"Max MP bonus",
		"Unknown status 08",
		"Unknown status 09",
		"Unknown status 10",
		"Unknown status 11",
		"Shot resistance (stored negative)",
		"Fire resistance (stored negative)",
		"Ice resistance (stored negative)",
		"Lightning resistance (stored negative)",
		"Dark resistance (stored negative)",
		"Unknown status 17",
		"Weapon level cap",
		"Unknown status 19",
	}
	o.CraftingFields = append(o.CraftingFields, labels...)
	return o
}

func hiddenBank(bank int) bool {
	for _, d := range comradesHiddenModdedWeapons {
		if d.Bank == bank {
			return true
		}
	}
	return false
}

// availableToActiveGlaive returns true for weapon records that belong to the
// active player's usable pool: they are owned and either currently linked to
// the active Glaive or not linked to another avatar. Records assigned to other
// save indices are NPC/other-avatar equipment and must not appear in the normal
// character weapon editor.
func equippedByActiveGlaive(model *SaveModel, r *EquipmentRecord) bool {
	if model == nil || model.Comrades == nil || r == nil || r.Category != "Weapons" {
		return false
	}
	active := model.Comrades.SaveIndex
	if r.EquipmentOwner == int32(active) {
		return true
	}
	// The SaveStatusStruct loadout tuple is the authoritative view of what the
	// active Glaive currently has equipped. Keep the weapon visible even if an
	// older/broken editor left the mirrored master owner link inconsistent.
	for i := range model.Equipped {
		s := &model.Equipped[i]
		if s.SaveIndex == active && s.Kind == "Weapon" && s.BankNumber == uint32(r.CategoryIndex) && s.FixID == r.FixID {
			return true
		}
	}
	return false
}

func availableToActiveGlaive(model *SaveModel, r *EquipmentRecord) bool {
	if model == nil || model.GameMode != "Comrades" || model.Comrades == nil || r == nil {
		return false
	}
	if r.Category != "Weapons" || r.FixID == 0 || isPlaceholderEquipment(r.FixID) {
		return false
	}
	if equippedByActiveGlaive(model, r) {
		return true
	}
	// A weapon belongs on the active character's Weapons page when it is owned
	// by the active Glaive, explicitly equipped by the active Glaive, or owned
	// but currently unassigned in the player's inventory pool. Records assigned
	// to another save index/NPC stay out of the normal character view.
	active := int32(model.Comrades.SaveIndex)
	return r.Exists && (r.EquipmentOwner < 0 || r.EquipmentOwner == active)
}

func buildEquipmentSummary(model *SaveModel) *equipmentSummaryView {
	if model == nil || model.GameMode != "Comrades" || model.Comrades == nil {
		return nil
	}
	e := &equipmentSummaryView{SaveIndex: model.Comrades.SaveIndex, AvatarName: strings.TrimSpace(model.Comrades.Name)}
	if e.AvatarName == "" {
		e.AvatarName = fmt.Sprintf("Glaive %d", model.Comrades.SaveIndex)
	}
	for slotIndex := 1; slotIndex <= 4; slotIndex++ {
		slot := equippedSlotBySaveIndex(model, model.Comrades.SaveIndex, "Weapon", slotIndex)
		v := equipmentSlotView{Kind: "Weapon", Slot: slotIndex, Role: "Secondary weapon", Bank: -1, Name: "Empty", Empty: true}
		if slotIndex == 1 {
			v.Role = "Primary weapon"
		}
		if slot != nil && slot.FixID != 0 && slot.BankNumber != ^uint32(0) {
			v.Bank = int(slot.BankNumber)
			v.FixID = slot.FixID
			v.FixIDHex = fmt.Sprintf("0x%08X", slot.FixID)
			v.Name = equipmentDisplayName(slot.FixID)
			v.Empty = false
		} else {
			v.FixIDHex = "0x00000000"
		}
		e.WeaponSlots = append(e.WeaponSlots, v)
	}
	for slotIndex := 1; slotIndex <= 3; slotIndex++ {
		slot := equippedSlotBySaveIndex(model, model.Comrades.SaveIndex, "Accessory", slotIndex)
		v := equipmentSlotView{Kind: "Accessory", Slot: slotIndex, Role: fmt.Sprintf("Accessory %d", slotIndex), Bank: -1, Name: "Empty", Empty: true, FixIDHex: "0x00000000"}
		if slot != nil && slot.FixID != 0 && slot.BankNumber != ^uint32(0) {
			v.Bank = int(slot.BankNumber)
			v.FixID = slot.FixID
			v.FixIDHex = fmt.Sprintf("0x%08X", slot.FixID)
			v.Name = equipmentDisplayName(slot.FixID)
			v.Empty = false
		}
		e.AccessorySlots = append(e.AccessorySlots, v)
	}
	for i := range model.Equipment {
		r := &model.Equipment[i]
		if r.FixID == 0 || isPlaceholderEquipment(r.FixID) {
			continue
		}
		switch r.Category {
		case "Weapons":
			// Normal Glaive loadout choices should not include weapons currently
			// assigned to another avatar/NPC in the same gameplay0 database.
			if availableToActiveGlaive(model, r) {
				e.WeaponOptions = append(e.WeaponOptions, equipmentOptionView{Bank: r.CategoryIndex, FixID: r.FixID, FixIDHex: fmt.Sprintf("0x%08X", r.FixID), Name: equipmentDisplayName(r.FixID), Type: r.Type, Owned: r.Exists})
			}
		case "Accessories":
			// Banks 32+ are Royal-Sigil master records, not normal accessory slots.
			if r.CategoryIndex < 32 {
				e.AccessoryOptions = append(e.AccessoryOptions, equipmentOptionView{Bank: r.CategoryIndex, FixID: r.FixID, FixIDHex: fmt.Sprintf("0x%08X", r.FixID), Name: equipmentDisplayName(r.FixID), Type: r.Type, Owned: r.Exists})
			}
		}
	}
	sort.Slice(e.WeaponOptions, func(i, j int) bool {
		return strings.ToLower(e.WeaponOptions[i].Name) < strings.ToLower(e.WeaponOptions[j].Name)
	})
	sort.Slice(e.AccessoryOptions, func(i, j int) bool {
		return strings.ToLower(e.AccessoryOptions[i].Name) < strings.ToLower(e.AccessoryOptions[j].Name)
	})
	if model.ComradesJob != nil {
		j := model.ComradesJob
		e.Sigil = rawEquipmentView{FixID: j.FixID, FixIDHex: fmt.Sprintf("0x%08X", j.FixID), Bank: j.BankNumber, Name: fmt.Sprintf("Job command 0x%08X", j.FixID), Writable: false, Note: "The active Sigil is serialized as a job-command tuple. Direct Sigil FixID-to-job-command mapping is not yet verified, so selection remains read-only."}
	} else {
		e.Sigil = rawEquipmentView{FixIDHex: "0x00000000", Bank: -1, Name: "Not found", Writable: false, Note: "No verified active Glaive job-command record was found."}
	}
	for i := range model.Attire {
		a := &model.Attire[i]
		if a.SaveIndex != model.Comrades.SaveIndex {
			continue
		}
		clothName := clothDisplayName(a.FixID)
		if a.FixID != 0 && strings.EqualFold(strings.TrimSpace(clothName), "None") {
			clothName = "Current Glaive clothing"
		}
		e.Clothing = rawEquipmentView{FixID: a.FixID, FixIDHex: fmt.Sprintf("0x%08X", a.FixID), Type: a.Type, Bank: int32(a.BankNumber), Name: clothName, Writable: false, Note: "The active clothing tuple is verified, but its value-to-clothing-unlock mapping is not yet verified. It is displayed read-only to avoid writing guessed IDs."}
		break
	}
	if e.Clothing.FixIDHex == "" {
		e.Clothing = rawEquipmentView{FixIDHex: "0x00000000", Bank: -1, Name: "Not found", Writable: false, Note: "No verified active Glaive clothing record was found."}
	}
	return e
}

func boolInt(v bool) int {
	if v {
		return 1
	}
	return 0
}

func abilityRawLabel(id uint32) string {
	for _, a := range abilityCatalog {
		if a.FixID == id {
			return a.Name
		}
	}
	return fmt.Sprintf("0x%08X", id)
}

func buildAbilitiesSigilsSummary(model *SaveModel) *abilitiesSigilsView {
	if model == nil || model.GameMode != "Comrades" {
		return nil
	}
	v := &abilitiesSigilsView{
		Sigils:             []sigilView{},
		CharacterAbilities: []characterAbilityView{},
		AbilityTree: abilityTreeView{
			Enabled:        []abilityTreeEntityView{},
			ReleaseBlocked: []string{},
		},
	}
	removalSafe := isDefaultComradesJobCommand(model.ComradesJob)
	for _, entry := range comradesSigilCatalog {
		r := findMasterRecord(model, "Accessories", entry.Bank)
		initialized, owned, writable := false, false, false
		if r != nil {
			initialized = r.FixID == entry.FixID
			owned = initialized && r.Exists
			writable = initialized && (!owned || removalSafe)
		}
		v.Sigils = append(v.Sigils, sigilView{Bank: entry.Bank, FixID: entry.FixID, FixIDHex: fmt.Sprintf("0x%08X", entry.FixID), Name: entry.Name, Internal: entry.Internal, JobIndex: entry.JobIndex, Owned: owned, Initialized: initialized, Writable: writable})
	}
	if model.ComradesJob == nil {
		v.SelectedSigil = rawEquipmentView{FixIDHex: "0x00000000", Bank: -1, Name: "Not found", Writable: false, Note: "No active Glaive job-command record was found."}
	} else if isDefaultComradesJobCommand(model.ComradesJob) {
		v.SelectedSigil = rawEquipmentView{FixID: model.ComradesJob.FixID, FixIDHex: fmt.Sprintf("0x%08X", model.ComradesJob.FixID), Bank: model.ComradesJob.BankNumber, Name: "None / default job command", Writable: false, Note: "No equipped Sigil is proven in this save. Selecting a Sigil remains disabled until a real Sigil-equipped save verifies the Sigil-to-job-command tuple mapping."}
	} else {
		v.SelectedSigil = rawEquipmentView{FixID: model.ComradesJob.FixID, FixIDHex: fmt.Sprintf("0x%08X", model.ComradesJob.FixID), Bank: model.ComradesJob.BankNumber, Name: "Active Sigil / job command (unmapped)", Writable: false, Note: "The active job-command tuple is verified, but this build will not guess which Sigil it represents. Removal of owned Sigils is protected while this non-default tuple is equipped."}
	}
	for i, a := range model.ComradesAbilities {
		flagsText := fmt.Sprintf("exist=%d enchant=%d noctis=%d weapon=%d party=%d", boolInt(a.Enabled()), boolInt(a.Enchant()), boolInt(a.NoctisOnly()), boolInt(a.WeaponOnly()), boolInt(a.Party()))
		v.CharacterAbilities = append(v.CharacterAbilities, characterAbilityView{RecordIndex: i, FixID: a.FixID, FixIDHex: fmt.Sprintf("0x%08X", a.FixID), Name: abilityName(a.FixID), RawLabel: abilityRawLabel(a.FixID), AbilityID: a.AbilityID, Level: a.Level, Enabled: a.Enabled(), Flags: a.Flags, FlagsHex: fmt.Sprintf("0x%02X", a.Flags), FlagsText: flagsText, Count: a.Count, WeaponBank: a.WeaponBankNumber})
	}
	sort.Slice(v.CharacterAbilities, func(i, j int) bool {
		return strings.ToLower(v.CharacterAbilities[i].Name) < strings.ToLower(v.CharacterAbilities[j].Name)
	})
	v.AbilityTree.Writable = false
	v.AbilityTree.Note = "Ability-tree arrays are structurally verified, but changing their element count would resize gameplay0. This build displays progression read-only until a controlled save pair validates variable-length tree writes."
	if model.ComradesAbilityTree != nil {
		for _, e := range model.ComradesAbilityTree.Enabled {
			v.AbilityTree.Enabled = append(v.AbilityTree.Enabled, abilityTreeEntityView{FixID: e.FixID, FixIDHex: fmt.Sprintf("0x%08X", e.FixID), BankNumber: e.BankNumber})
		}
		for _, id := range model.ComradesAbilityTree.ReleaseBlocked {
			v.AbilityTree.ReleaseBlocked = append(v.AbilityTree.ReleaseBlocked, fmt.Sprintf("0x%08X", id))
		}
	}
	return v
}

func buildSaveHealth(model *SaveModel, wasEncrypted bool) saveHealthView {
	checks := make([]healthCheckView, 0, 8)
	add := func(name string, ok bool, detail string) {
		status := "PASS"
		if !ok {
			status = "WARN"
		}
		checks = append(checks, healthCheckView{Name: name, Status: status, Detail: detail})
	}
	add("FFXV plaintext structure", model.FileSize > footerSize && model.SchemaOffset > 0, fmt.Sprintf("%d bytes; schema at 0x%X", model.FileSize, model.SchemaOffset))
	add("COMRADES mode", model.GameMode == "Comrades", model.GameMode)
	add("Glaive character", model.Comrades != nil, func() string {
		if model.Comrades != nil {
			return model.Comrades.Name
		}
		return "COMRADES avatar status not resolved"
	}())
	add("Direct kW field", model.ComradesKW != nil, func() string {
		if model.ComradesKW != nil {
			return fmt.Sprintf("current kW %d", model.ComradesKW.Current)
		}
		return "kW structure not resolved"
	}())
	weaponCount := 0
	for i := range model.Equipment {
		if model.Equipment[i].Category == "Weapons" && model.Equipment[i].FixID != 0 && !isPlaceholderEquipment(model.Equipment[i].FixID) {
			weaponCount++
		}
	}
	add("Weapon database", weaponCount > 0, fmt.Sprintf("%d initialized weapon records", weaponCount))
	add("Inventory", len(model.Inventory) > 0, fmt.Sprintf("%d parsed inventory slots", len(model.Inventory)))
	add("Equipment links", model.Comrades != nil && len(model.Equipped) > 0, fmt.Sprintf("%d parsed equipped slots", len(model.Equipped)))
	cryptoDetail := "plaintext input"
	if wasEncrypted {
		cryptoDetail = "encrypted source decrypted and byte-for-byte crypto round-trip verified"
	}
	add("Crypto source", true, cryptoDetail)

	warns := 0
	for _, c := range checks {
		if c.Status != "PASS" {
			warns++
		}
	}
	status, confidence, summary := "GOOD", "HIGH", "All required editor structures passed validation."
	if warns > 0 {
		status, confidence, summary = "CAUTION", "MEDIUM", fmt.Sprintf("%d optional/COMRADES structures were not resolved; affected editors should remain unavailable.", warns)
	}
	return saveHealthView{Status: status, Confidence: confidence, Summary: summary, Checks: checks}
}

func summarizeSave(sourcePath, plainPath, metadataPath string, wasEncrypted bool, model *SaveModel) saveSummary {
	s := saveSummary{
		SourcePath:   sourcePath,
		PlainPath:    plainPath,
		MetadataPath: metadataPath,
		WasEncrypted: wasEncrypted,
		GameMode:     model.GameMode,
		SHA256:       model.SHA256,
		FileSize:     model.FileSize,
		Gil:          model.Party.Gil,
		Health:       buildSaveHealth(model, wasEncrypted),
	}
	if model.Comrades != nil {
		c := model.Comrades
		s.AvatarName = c.Name
		s.SaveIndex = c.SaveIndex
		s.Character = &characterStatsView{
			Name: c.Name, SaveIndex: c.SaveIndex,
			HP: c.HP, HPMax: c.HPMax, MP: c.MP, MPMax: c.MPMax,
			Level: c.Level, LevelMax: c.LevelMax,
			Strength: c.Strength, Vitality: c.Vitality, Magic: c.Magic, Spirit: c.Spirit, Critical: c.Critical,
		}
	}
	if model.ComradesKW != nil {
		v := model.ComradesKW.Current
		s.KW = &v
	}
	for i := range model.ComradesChocobos {
		c := model.ComradesChocobos[i]
		name := fmt.Sprintf("Chocobo %d", i+1)
		// Verified directly against the supplied live Training screen/save pair.
		switch c.NameID {
		case 0x0B01D0C1:
			name = "Black Chocobo"
		case 0x0B01D0C3:
			name = "Blue Chocobo"
		default:
			if n, ok := itemEnglishNames[c.NameID]; ok && strings.TrimSpace(n) != "" {
				name = n
			}
		}
		s.Chocobos = append(s.Chocobos, chocoboView{
			Index: c.Index, NameID: c.NameID, NameIDHex: fmt.Sprintf("0x%08X", c.NameID), Name: name,
			Personality: c.Personality, Rarity: c.Rarity, Color: c.Color,
			Level: c.Level, LevelCap: c.MaxLevel, LimitMaxLevel: c.LimitMaxLevel, SkillLevel: c.SkillLevel,
			Stamina: c.Stamina, Jump: c.Jump, Speed: c.Speed, InjuryPercent: c.InjuryPercent, IsInjured: c.IsInjured,
		})
	}
	s.Equipment = buildEquipmentSummary(model)
	s.AbilitiesSigils = buildAbilitiesSigilsSummary(model)

	for i := range model.Equipment {
		r := &model.Equipment[i]
		if r.Category != "Weapons" {
			continue
		}
		initialized := r.FixID != 0 && !isPlaceholderEquipment(r.FixID)
		name := "Reserved weapon slot"
		if initialized {
			if c := comradesWeaponCatalogByBank(int32(r.CategoryIndex)); c != nil && c.FixID == r.FixID && c.Name != "" {
				name = c.Name
			} else {
				name = equipmentDisplayName(r.FixID)
			}
		}
		active := availableToActiveGlaive(model, r)
		equipped := equippedByActiveGlaive(model, r)
		equipmentSlot := int32(-1)
		if equipped && r.EquipmentBank >= 0 {
			equipmentSlot = r.EquipmentBank + 1
		}
		s.Weapons = append(s.Weapons, weaponView{
			Bank:                    r.CategoryIndex,
			FixID:                   r.FixID,
			FixIDHex:                fmt.Sprintf("0x%08X", r.FixID),
			Name:                    name,
			Type:                    r.Type,
			Initialized:             initialized,
			Owned:                   r.Exists,
			Hidden:                  hiddenBank(r.CategoryIndex),
			EquipmentOwner:          r.EquipmentOwner,
			EquipmentSlot:           equipmentSlot,
			AvailableToActiveGlaive: active,
			EquippedByActiveGlaive:  equipped,
			Rank:                    r.Rank,
			Attack:                  r.Strength,
			Vitality:                r.Vitality,
			Critical:                r.Critical,
			RecoverMP:               r.RecoverMP,
			SlotCount:               r.SlotCount,
			RemodelFails:            r.RemodelFailCount,
			Ability1:                r.Abilities[0].FixID,
			Ability2:                r.Abilities[1].FixID,
			Ability1Name:            abilityName(r.Abilities[0].FixID),
			Ability2Name:            abilityName(r.Abilities[1].FixID),
			ResidentAbility:         r.ResidentAbility.FixID,
			ResidentAbilityBank:     r.ResidentAbility.BankNumber,
			ResidentAbilityName:     residentAbilityName(r.ResidentAbility.FixID, r.ResidentAbility.BankNumber),
			StatusAdjust:            r.StatusAdjust,
		})
	}
	sort.Slice(s.Weapons, func(i, j int) bool { return s.Weapons[i].Bank < s.Weapons[j].Bank })

	for _, kind := range comradesCollectionKinds {
		owned, total := comradesCollectionOwnedCount(model, kind)
		g := collectionGroupView{Kind: kind, Owned: owned, Total: total, Recommended: comradesCollectionRecommendedQuantity(kind)}
		for _, e := range comradesCollectionEntries(kind) {
			q := int32(0)
			if slot := comradesCollectionInventorySlot(model, e.FixID); slot != nil {
				q = slot.Amount
			}
			g.Entries = append(g.Entries, collectionEntryView{
				FixID:    e.FixID,
				FixIDHex: fmt.Sprintf("0x%08X", e.FixID),
				Name:     itemDisplayName(e.FixID),
				Label:    gameItemLabel(e.FixID),
				Category: catalogCategoryLabel(e.GameCategory),
				Quantity: q,
				Owned:    q > 0,
			})
		}
		sort.Slice(g.Entries, func(i, j int) bool { return strings.ToLower(g.Entries[i].Name) < strings.ToLower(g.Entries[j].Name) })
		s.Collections = append(s.Collections, g)
	}

	for _, kind := range comradesInventoryKinds {
		owned, total := comradesInventoryOwnedCount(model, kind)
		g := inventoryGroupView{Kind: kind, Owned: owned, Total: total, Recommended: comradesInventoryRecommendedQuantity(kind)}
		for _, e := range comradesInventoryEntries(kind) {
			q := int32(0)
			if slot := comradesInventorySlot(model, e.FixID); slot != nil {
				q = slot.Amount
			}
			g.Entries = append(g.Entries, inventoryEntryView{
				FixID:    e.FixID,
				FixIDHex: fmt.Sprintf("0x%08X", e.FixID),
				Name:     itemDisplayName(e.FixID),
				Label:    gameItemLabel(e.FixID),
				Category: catalogCategoryLabel(e.GameCategory),
				Quantity: q,
				Owned:    q > 0,
			})
		}
		s.Inventory = append(s.Inventory, g)
	}
	return s
}

func openSave(path string) (*saveSummary, error) {
	input, normalized, err := readRegularFile(path)
	if err != nil {
		return nil, err
	}
	source := normalized
	plainPath := normalized
	metadataPath := ""
	wasEncrypted := false
	if _, e := detectFFXVPlainKind(input); e != nil {
		res, de := processFile(normalized, true)
		if de != nil {
			return nil, fmt.Errorf("input is neither supported plaintext nor decryptable FFXV gameplay0: %w", de)
		}
		plainPath = res.OutputPath
		metadataPath = res.MetadataPath
		wasEncrypted = true
		input, _, err = readRegularFile(plainPath)
		if err != nil {
			return nil, err
		}
	} else {
		if _, err := os.Stat(plainPath + metadataSuffix); err == nil {
			metadataPath = plainPath + metadataSuffix
		}
	}
	m, err := parseSaveModelBytes(input, plainPath)
	if err != nil {
		return nil, err
	}
	if m.GameMode != "Comrades" {
		return nil, fmt.Errorf("this WPF edition is COMRADES-only; detected %s", m.GameMode)
	}
	s := summarizeSave(source, plainPath, metadataPath, wasEncrypted, m)
	return &s, nil
}

func readApplyRequest(path string) (applyRequest, error) {
	var r applyRequest
	b, err := os.ReadFile(path)
	if err != nil {
		return r, err
	}
	if err := json.Unmarshal(b, &r); err != nil {
		return r, fmt.Errorf("invalid edits JSON: %w", err)
	}
	return r, nil
}

func applyEdits(plainPath, editsPath string) (*applyResult, error) {
	input, normalized, err := readRegularFile(plainPath)
	if err != nil {
		return nil, err
	}
	if _, err := detectFFXVPlainKind(input); err != nil {
		return nil, errors.New("SAVE + ENCRYPT requires the decrypted/plain gameplay0 path returned by OPEN / DECRYPT")
	}
	m, err := parseSaveModelBytes(input, normalized)
	if err != nil {
		return nil, err
	}
	if m.GameMode != "Comrades" {
		return nil, errors.New("this WPF edition edits COMRADES gameplay0 only")
	}
	req, err := readApplyRequest(editsPath)
	if err != nil {
		return nil, err
	}
	if len(req.CollectionActions) > 0 {
		return nil, errors.New("legacy collectionActions are no longer accepted; v2.8 requires explicit per-item edits")
	}
	if err := validateCanonicalItemEdits(req); err != nil {
		return nil, err
	}

	g := GeneralEdits{
		ControlledCharacter: m.Party.ControlledCharacter,
		Chapter:             m.Party.Chapter,
		Gil:                 m.Party.Gil,
		ArenaMedals:         m.Party.ArenaMedals,
		OracleCoins:         m.Party.OracleCoins,
		AbilityPoints:       m.Party.AbilityPoints,
	}
	if req.Gil != nil {
		g.Gil = *req.Gil
	}
	if req.KW != nil {
		if err := stageComradesKW(m, *req.KW); err != nil {
			return nil, err
		}
	}
	if req.Character != nil {
		if m.Comrades == nil {
			return nil, errors.New("COMRADES character status record was not found")
		}
		c := req.Character
		if err := stageComradesStatus(m, c.HP, c.HPMax, c.MP, c.MPMax, c.Level, c.Strength, c.Vitality, c.Magic, c.Spirit, c.Critical, m.Comrades.Exp, m.Comrades.ExpTotal, m.Comrades.AbilityPoints); err != nil {
			return nil, fmt.Errorf("character stats: %w", err)
		}
	}

	for _, c := range req.ChocoboEdits {
		if err := stageComradesChocobo(m, c.Index, c.Level, c.LevelCap, c.LimitMaxLevel, c.SkillLevel, c.Stamina, c.Jump, c.Speed, c.InjuryPercent); err != nil {
			return nil, fmt.Errorf("chocobo %d: %w", c.Index+1, err)
		}
	}

	for _, e := range req.EquipmentEdits {
		if err := stageComradesGlaiveEquipmentSlot(m, e.Kind, e.Slot, e.Bank); err != nil {
			return nil, fmt.Errorf("equipment %s slot %d: %w", e.Kind, e.Slot, err)
		}
	}

	for _, e := range req.SigilEdits {
		if err := stageComradesSigilOwnership(m, e.Bank, e.Owned); err != nil {
			return nil, fmt.Errorf("Sigil bank %d: %w", e.Bank, err)
		}
	}
	for _, e := range req.CharacterAbilityEdits {
		if err := stageComradesCharacterAbilityExact(m, e.RecordIndex, e.FixID, e.AbilityID, e.WeaponBank, e.Enabled, e.Level); err != nil {
			return nil, fmt.Errorf("character ability record %d / 0x%08X: %w", e.RecordIndex, e.FixID, err)
		}
	}

	for _, w := range req.WeaponEdits {
		if _, err := stageComradesWeaponOwnershipState(m, w.Bank, w.Owned); err != nil {
			return nil, err
		}
		if _, err := stageComradesWeaponCustomStats(m, w.Bank, comradesWeaponEditableStats{
			Rank:             w.Rank,
			Strength:         w.Attack,
			Vitality:         w.Vitality,
			Critical:         w.Critical,
			RecoverMP:        w.RecoverMP,
			SlotCount:        w.SlotCount,
			RemodelFailCount: w.RemodelFails,
		}); err != nil {
			return nil, fmt.Errorf("weapon bank %d: %w", w.Bank, err)
		}
		if _, err := stageComradesWeaponAdvanced(m, w.Bank, comradesWeaponAdvancedEdits{
			Ability1:            w.Ability1,
			Ability2:            w.Ability2,
			ResidentAbility:     w.ResidentAbility,
			ResidentAbilityBank: w.ResidentAbilityBank,
			StatusAdjust:        w.StatusAdjust,
		}); err != nil {
			return nil, fmt.Errorf("weapon bank %d: %w", w.Bank, err)
		}
	}

	for _, e := range req.CollectionEdits {
		if e.Quantity < 1 || e.Quantity > 99 {
			return nil, fmt.Errorf("%s quantity must be 1 through 99", e.Kind)
		}
		if _, err := stageComradesCollectionItem(m, e.Kind, e.FixID, e.Quantity); err != nil {
			return nil, err
		}
	}

	for _, e := range req.InventoryEdits {
		if err := stageComradesInventoryItem(m, e.Kind, e.FixID, e.Owned, e.Quantity); err != nil {
			return nil, err
		}
	}

	// Weapon writes are validated per selected record by the scalar and advanced
	// writers above. Unrelated legacy weapon records must not block editing a
	// clean active-player weapon. The advanced writer still refuses the known
	// destructive all-9999 status_adjust profile on the weapon being written.

	res, err := saveEditedModel(normalized, input, m, g)
	if err != nil {
		return nil, err
	}
	out := &applyResult{
		WorkspacePath:    res.WorkspacePath,
		BackupPath:       res.BackupPath,
		EditedPlainPath:  res.OutputPath,
		MetadataPath:     res.MetadataPath,
		MetadataWarning:  res.MetadataWarning,
		SaveStatus:       "plaintext_only",
		SHA256:           res.SHA256,
		ChangedBytes:     res.ChangedBytes,
		InventoryChanges: res.InventoryChanges,
		EquipmentChanges: res.EquipmentChanges,
	}
	if res.MetadataCopied {
		enc, encErr := processFile(res.OutputPath, false)
		if encErr != nil {
			out.SaveStatus = "partial"
			out.EncryptionError = encErr.Error()
		} else {
			out.SaveStatus = "complete"
			out.ModdedPath = enc.OutputPath
		}
	}
	editedBytes, _, err := readRegularFile(res.OutputPath)
	if err != nil {
		return nil, err
	}
	editedModel, err := parseSaveModelBytes(editedBytes, res.OutputPath)
	if err != nil {
		return nil, err
	}
	out.Summary = summarizeSave(normalized, res.OutputPath, res.MetadataPath, false, editedModel)
	encryptionRoundTrip := "NOT RUN"
	if out.SaveStatus == "complete" {
		encryptionRoundTrip = "PASS"
	} else if out.SaveStatus == "partial" {
		encryptionRoundTrip = "FAILED"
	}
	verificationResult := "PLAINTEXT PASS"
	if out.SaveStatus == "complete" {
		verificationResult = "PASS"
	} else if out.SaveStatus == "partial" {
		verificationResult = "PARTIAL"
	}
	out.Verification = applyVerificationView{
		Result: verificationResult, ModelReadback: "PASS", ProtectedFields: "PASS", EquipmentIntegrity: "PASS",
		SaveSizePreserved: len(editedBytes) == len(input), FooterPreserved: equalBytes(editedBytes[len(editedBytes)-footerSize:], input[len(input)-footerSize:]),
		UnexpectedByteChanges: 0, EncryptionRoundTrip: encryptionRoundTrip, ChangedBytes: out.ChangedBytes,
	}
	verificationPath := filepath.Join(res.WorkspacePath, "verification.json")
	if payload, marshalErr := json.MarshalIndent(out.Verification, "", "  "); marshalErr == nil {
		payload = append(payload, '\n')
		if writeErr := writeFileExclusive(verificationPath, payload, 0o644); writeErr == nil {
			out.VerificationPath = verificationPath
		}
	}
	reportPath := filepath.Join(res.WorkspacePath, "edit-report.txt")
	report := buildApplyReport(normalized, input, req, out)
	if err := writeFileExclusive(reportPath, []byte(report), 0o644); err == nil {
		out.ReportPath = reportPath
	}
	return out, nil
}

func buildApplyReport(sourcePath string, original []byte, req applyRequest, out *applyResult) string {
	h := sha256.Sum256(original)
	var b strings.Builder
	fmt.Fprintf(&b, "FFXV COMRADES Forge Edit Report\n")
	fmt.Fprintf(&b, "Core: %s\n", coreVersion)
	fmt.Fprintf(&b, "Generated: %s\n\n", time.Now().Format(time.RFC3339))
	fmt.Fprintf(&b, "Source: %s\n", sourcePath)
	fmt.Fprintf(&b, "Original SHA256: %s\n", hex.EncodeToString(h[:]))
	fmt.Fprintf(&b, "Edited SHA256: %s\n", out.SHA256)
	fmt.Fprintf(&b, "Save status: %s\n", out.SaveStatus)
	fmt.Fprintf(&b, "Changed bytes: %d\n", out.ChangedBytes)
	fmt.Fprintf(&b, "Inventory changes: %d\n", out.InventoryChanges)
	fmt.Fprintf(&b, "Equipment changes: %d\n\n", out.EquipmentChanges)
	fmt.Fprintf(&b, "Post-save verification\n")
	fmt.Fprintf(&b, "  Overall result: %s\n", out.Verification.Result)
	fmt.Fprintf(&b, "  Model read-back: %s\n", out.Verification.ModelReadback)
	fmt.Fprintf(&b, "  Protected fields: %s\n", out.Verification.ProtectedFields)
	fmt.Fprintf(&b, "  Equipment integrity: %s\n", out.Verification.EquipmentIntegrity)
	fmt.Fprintf(&b, "  Save size preserved: %v\n", out.Verification.SaveSizePreserved)
	fmt.Fprintf(&b, "  Footer preserved: %v\n", out.Verification.FooterPreserved)
	fmt.Fprintf(&b, "  Unexpected byte changes: %d\n", out.Verification.UnexpectedByteChanges)
	fmt.Fprintf(&b, "  Encryption round-trip: %s\n\n", out.Verification.EncryptionRoundTrip)
	fmt.Fprintf(&b, "Requested edits\n")
	if req.Gil != nil {
		fmt.Fprintf(&b, "  Gil: %d\n", *req.Gil)
	}
	if req.KW != nil {
		fmt.Fprintf(&b, "  kW: %d\n", *req.KW)
	}
	fmt.Fprintf(&b, "  Weapon edits: %d\n", len(req.WeaponEdits))
	fmt.Fprintf(&b, "  Chocobo edits: %d\n", len(req.ChocoboEdits))
	fmt.Fprintf(&b, "  Collection edits: %d\n", len(req.CollectionEdits))
	fmt.Fprintf(&b, "  Inventory edits: %d\n", len(req.InventoryEdits))
	fmt.Fprintf(&b, "  Equipment edits: %d\n", len(req.EquipmentEdits))
	fmt.Fprintf(&b, "  Sigil edits: %d\n", len(req.SigilEdits))
	fmt.Fprintf(&b, "  Character ability edits: %d\n\n", len(req.CharacterAbilityEdits))
	fmt.Fprintf(&b, "Outputs\n")
	fmt.Fprintf(&b, "  Workspace: %s\n", out.WorkspacePath)
	fmt.Fprintf(&b, "  Backup: %s\n", out.BackupPath)
	fmt.Fprintf(&b, "  Edited plaintext: %s\n", out.EditedPlainPath)
	if out.ModdedPath != "" {
		fmt.Fprintf(&b, "  Encrypted import: %s\n", out.ModdedPath)
	}
	if out.EncryptionError != "" {
		fmt.Fprintf(&b, "  Encryption error: %s\n", out.EncryptionError)
	}
	fmt.Fprintf(&b, "\nManual weapon fields: MP Recovery and raw status_adjust writes are range-checked; the known all-9999 destructive profile is blocked.\n")
	return b.String()
}

func buildCatalog() []catalogRow {
	rows := make([]catalogRow, 0, len(allGameItemCatalog)+len(equipmentGameLabels)+len(abilityCatalog))
	for _, e := range allGameItemCatalog {
		rows = append(rows, catalogRow{
			Kind:     "Item",
			Name:     itemDisplayName(e.FixID),
			Label:    gameItemLabel(e.FixID),
			FixID:    e.FixID,
			FixIDHex: fmt.Sprintf("0x%08X", e.FixID),
			Bank:     -1,
			Category: catalogCategoryLabel(e.GameCategory),
		})
	}
	for id, label := range equipmentGameLabels {
		rows = append(rows, catalogRow{
			Kind:     "Equipment",
			Name:     equipmentDisplayName(id),
			Label:    label,
			FixID:    id,
			FixIDHex: fmt.Sprintf("0x%08X", id),
			Bank:     -1,
			Category: "Equipment",
		})
	}
	for _, a := range abilityCatalog {
		rows = append(rows, catalogRow{
			Kind:     "Ability",
			Name:     prettyGameLabel(a.Name),
			Label:    a.Name,
			FixID:    a.FixID,
			FixIDHex: fmt.Sprintf("0x%08X", a.FixID),
			Bank:     a.Bank,
			Category: "Ability",
		})
	}
	sort.Slice(rows, func(i, j int) bool {
		if rows[i].Kind != rows[j].Kind {
			return rows[i].Kind < rows[j].Kind
		}
		return strings.ToLower(rows[i].Name) < strings.ToLower(rows[j].Name)
	})
	return rows
}

func main() {
	if len(os.Args) < 2 {
		emitErr(errors.New("command required: open, apply, avatar-open, avatar-apply, encrypt, audit, catalog, weapon-options, version"))
		return
	}
	switch os.Args[1] {
	case "version":
		emitOK(map[string]string{"version": coreVersion})
	case "open":
		fs := flag.NewFlagSet("open", flag.ContinueOnError)
		input := fs.String("input", "", "save path")
		fs.SetOutput(os.Stderr)
		if err := fs.Parse(os.Args[2:]); err != nil {
			emitErr(err)
			return
		}
		if strings.TrimSpace(*input) == "" {
			emitErr(errors.New("--input is required"))
			return
		}
		s, err := openSave(*input)
		if err != nil {
			emitErr(err)
			return
		}
		emitOK(s)
	case "avatar-open":
		fs := flag.NewFlagSet("avatar-open", flag.ContinueOnError)
		input := fs.String("input", "", "avatar0 save path")
		fs.SetOutput(os.Stderr)
		if err := fs.Parse(os.Args[2:]); err != nil {
			emitErr(err)
			return
		}
		if strings.TrimSpace(*input) == "" {
			emitErr(errors.New("--input is required"))
			return
		}
		r, err := openAvatarSave(*input)
		if err != nil {
			emitErr(err)
			return
		}
		emitOK(r)
	case "avatar-apply":
		fs := flag.NewFlagSet("avatar-apply", flag.ContinueOnError)
		input := fs.String("input", "", "decrypted avatar0 path")
		edits := fs.String("edits", "", "avatar edits json path")
		fs.SetOutput(os.Stderr)
		if err := fs.Parse(os.Args[2:]); err != nil {
			emitErr(err)
			return
		}
		if strings.TrimSpace(*input) == "" || strings.TrimSpace(*edits) == "" {
			emitErr(errors.New("--input and --edits are required"))
			return
		}
		r, err := applyAvatarStatus(*input, *edits)
		if err != nil {
			emitErr(err)
			return
		}
		emitOK(r)
	case "apply":
		fs := flag.NewFlagSet("apply", flag.ContinueOnError)
		input := fs.String("input", "", "decrypted save path")
		edits := fs.String("edits", "", "edits json path")
		fs.SetOutput(os.Stderr)
		if err := fs.Parse(os.Args[2:]); err != nil {
			emitErr(err)
			return
		}
		if *input == "" || *edits == "" {
			emitErr(errors.New("--input and --edits are required"))
			return
		}
		r, err := applyEdits(*input, *edits)
		if err != nil {
			emitErr(err)
			return
		}
		emitOK(r)
	case "encrypt":
		fs := flag.NewFlagSet("encrypt", flag.ContinueOnError)
		input := fs.String("input", "", "decrypted/edited plaintext save path")
		fs.SetOutput(os.Stderr)
		if err := fs.Parse(os.Args[2:]); err != nil {
			emitErr(err)
			return
		}
		if strings.TrimSpace(*input) == "" {
			emitErr(errors.New("--input is required"))
			return
		}
		r, err := processFile(*input, false)
		if err != nil {
			emitErr(err)
			return
		}
		emitOK(r)
	case "audit":
		fs := flag.NewFlagSet("audit", flag.ContinueOnError)
		input := fs.String("input", "", "save/evidence path")
		fs.SetOutput(os.Stderr)
		if err := fs.Parse(os.Args[2:]); err != nil {
			emitErr(err)
			return
		}
		if strings.TrimSpace(*input) == "" {
			emitErr(errors.New("--input is required"))
			return
		}
		r, err := auditEvidenceFile(*input)
		if err != nil {
			emitErr(err)
			return
		}
		emitOK(r)
	case "catalog":
		emitOK(buildCatalog())
	case "weapon-options":
		emitOK(buildWeaponOptions())
	case "manifest":
		emitOK(forgeDatabaseFiles)
	default:
		emitErr(fmt.Errorf("unknown command %q", os.Args[1]))
	}

}
