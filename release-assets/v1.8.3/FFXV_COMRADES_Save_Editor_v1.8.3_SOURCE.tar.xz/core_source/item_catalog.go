package main

import (
	"errors"
	"fmt"
)

const (
	timedQuestQPFixID uint32 = 0x0105663E
	maxTimedQuestQP   int32  = 999999
)

func timedQuestQPSlot(model *SaveModel) *InventorySlot {
	if model == nil {
		return nil
	}
	for i := range model.Inventory {
		s := &model.Inventory[i]
		if s.FixID == timedQuestQPFixID {
			return s
		}
	}
	return nil
}

func timedQuestQP(model *SaveModel) int32 {
	if s := timedQuestQPSlot(model); s != nil {
		return s.Amount
	}
	return 0
}

func stageTimedQuestQP(model *SaveModel, amount int32) (*InventorySlot, error) {
	if model == nil {
		return nil, errors.New("no save is loaded")
	}
	if amount < 0 || amount > maxTimedQuestQP {
		return nil, fmt.Errorf("Timed Quest QP must be 0 through %d", maxTimedQuestQP)
	}
	if existing := timedQuestQPSlot(model); existing != nil {
		existing.Amount = amount
		return existing, nil
	}
	if amount == 0 {
		return nil, nil
	}
	var empty *InventorySlot
	for i := range model.Inventory {
		s := &model.Inventory[i]
		if s.Category == "Event / Key Items" && s.FixID == 0 {
			empty = s
			break
		}
	}
	if empty == nil {
		return nil, errors.New("Event / Key Items is full; no empty slot is available for Timed Quest QP")
	}
	empty.FixID = timedQuestQPFixID
	empty.Amount = amount
	return empty, nil
}

func catalogInventoryCategory(gameCategory string) (string, bool) {
	switch gameCategory {
	case "BATTLE":
		return "Battle Items", true
	case "EVENT":
		return "Event / Key Items", true
	case "FOOD":
		return "Food / Ingredients", true
	case "TREASURE":
		return "Treasures", true
	case "CAR":
		return "Car / Regalia Items", true
	case "LEISURE":
		return "Leisure Items", true
	case "REINFORCEMENT":
		return "Reinforcement Items", true
	default:
		return "", false
	}
}

func catalogCategoryLabel(gameCategory string) string {
	if c, ok := catalogInventoryCategory(gameCategory); ok {
		return c
	}
	switch gameCategory {
	case "NONE":
		return "Internal / Non-inventory"
	case "SPECIAL":
		return "Special / Elemental"
	default:
		return gameCategory
	}
}

var gameItemCatalogByFixID = func() map[uint32]ItemCatalogEntry {
	m := make(map[uint32]ItemCatalogEntry, len(allGameItemCatalog))
	for _, e := range allGameItemCatalog {
		if _, exists := m[e.FixID]; !exists {
			m[e.FixID] = e
		}
	}
	return m
}()

func catalogEntryByFixID(fixID uint32) (ItemCatalogEntry, bool) {
	e, ok := gameItemCatalogByFixID[fixID]
	return e, ok
}

func addGameItemToInventory(model *SaveModel, fixID uint32, quantity int32) (*InventorySlot, error) {
	if model == nil {
		return nil, errors.New("no save is loaded")
	}
	if quantity < 1 || quantity > 99 {
		return nil, errors.New("quantity must be 1 through 99")
	}
	entry, ok := catalogEntryByFixID(fixID)
	if !ok {
		return nil, fmt.Errorf("FixID 0x%08X is not in the embedded FFXV item catalog", fixID)
	}
	targetCategory, ok := catalogInventoryCategory(entry.GameCategory)
	if !ok {
		return nil, fmt.Errorf("%s is a %s record and is not stored in the normal gameplay inventory arrays", itemDisplayName(fixID), catalogCategoryLabel(entry.GameCategory))
	}
	var empty *InventorySlot
	for i := range model.Inventory {
		s := &model.Inventory[i]
		if s.Category != targetCategory {
			continue
		}
		if s.FixID == fixID {
			s.Amount = quantity
			return s, nil
		}
		if empty == nil && s.FixID == 0 {
			empty = s
		}
	}
	if empty == nil {
		return nil, fmt.Errorf("%s is full; there is no empty slot available for %s", targetCategory, itemDisplayName(fixID))
	}
	empty.FixID = fixID
	empty.Amount = quantity
	return empty, nil
}
