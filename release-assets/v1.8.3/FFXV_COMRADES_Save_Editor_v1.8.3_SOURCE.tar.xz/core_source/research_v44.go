package main

import (
	"encoding/binary"
	"fmt"
	"math"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
)

type ResearchCandidate struct {
	Offset   int
	Width    int
	Encoding string
	ValueA   string
	ValueB   string
	Context  string
	Status   string
	Note     string
	Score    int
}

func bitfieldDiffReport(a, b []byte, maxRows int) string {
	maxLen := len(a)
	if len(b) < maxLen {
		maxLen = len(b)
	}
	var out strings.Builder
	out.WriteString("BITFIELD ANALYZER\n\n")
	rows := 0
	for i := 0; i < maxLen; i++ {
		if a[i] == b[i] {
			continue
		}
		x := a[i] ^ b[i]
		bits := make([]string, 0, 8)
		for bit := 0; bit < 8; bit++ {
			mask := byte(1 << bit)
			if x&mask == 0 {
				continue
			}
			from, to := 0, 0
			if a[i]&mask != 0 {
				from = 1
			}
			if b[i]&mask != 0 {
				to = 1
			}
			bits = append(bits, fmt.Sprintf("bit%d %d→%d", bit, from, to))
		}
		fmt.Fprintf(&out, "0x%08X  %02X → %02X  XOR=%02X  %s\n", i, a[i], b[i], x, strings.Join(bits, ", "))
		rows++
		if maxRows > 0 && rows >= maxRows {
			out.WriteString("... output truncated ...\n")
			break
		}
	}
	if rows == 0 {
		out.WriteString("No changed bits.\n")
	}
	return out.String()
}

func appendCandidate(out *[]ResearchCandidate, off, width int, enc, va, vb, context string, score int) {
	*out = append(*out, ResearchCandidate{Offset: off, Width: width, Encoding: enc, ValueA: va, ValueB: vb, Context: context, Status: "Possible", Score: score})
}

func correlateNumericValues(a, b []byte, expectedA, expectedB int64, schemaOffset int, types []SchemaType) []ResearchCandidate {
	limit := len(a)
	if len(b) < limit {
		limit = len(b)
	}
	if schemaOffset > 0 && schemaOffset < limit {
		limit = schemaOffset
	}
	occ := collectSchemaOccurrences(a, schemaOffset, types)
	ctx := func(off int) string {
		if o := nearestOccurrence(occ, off); o != nil {
			return fmt.Sprintf("%s+0x%X", o.Type, off-o.Offset)
		}
		return "raw"
	}
	c := make([]ResearchCandidate, 0, 32)
	for off := 0; off < limit; off++ {
		if expectedA >= 0 && expectedA <= 255 && expectedB >= 0 && expectedB <= 255 && a[off] == byte(expectedA) && b[off] == byte(expectedB) {
			appendCandidate(&c, off, 1, "u8", strconv.FormatInt(expectedA, 10), strconv.FormatInt(expectedB, 10), ctx(off), 100)
		}
		if off+2 <= limit {
			ua, ub := uint64(expectedA), uint64(expectedB)
			if expectedA >= 0 && expectedA <= 65535 && expectedB >= 0 && expectedB <= 65535 {
				if binary.LittleEndian.Uint16(a[off:off+2]) == uint16(ua) && binary.LittleEndian.Uint16(b[off:off+2]) == uint16(ub) {
					appendCandidate(&c, off, 2, "u16le", fmt.Sprint(expectedA), fmt.Sprint(expectedB), ctx(off), 110)
				}
				if binary.BigEndian.Uint16(a[off:off+2]) == uint16(ua) && binary.BigEndian.Uint16(b[off:off+2]) == uint16(ub) {
					appendCandidate(&c, off, 2, "u16be", fmt.Sprint(expectedA), fmt.Sprint(expectedB), ctx(off), 95)
				}
			}
		}
		if off+4 <= limit {
			if expectedA >= math.MinInt32 && expectedA <= math.MaxUint32 && expectedB >= math.MinInt32 && expectedB <= math.MaxUint32 {
				ua, ub := uint32(expectedA), uint32(expectedB)
				if binary.LittleEndian.Uint32(a[off:off+4]) == ua && binary.LittleEndian.Uint32(b[off:off+4]) == ub {
					appendCandidate(&c, off, 4, "u32le", fmt.Sprint(expectedA), fmt.Sprint(expectedB), ctx(off), 120)
				}
				if binary.BigEndian.Uint32(a[off:off+4]) == ua && binary.BigEndian.Uint32(b[off:off+4]) == ub {
					appendCandidate(&c, off, 4, "u32be", fmt.Sprint(expectedA), fmt.Sprint(expectedB), ctx(off), 90)
				}
			}
			fa, fb := float32(expectedA), float32(expectedB)
			if math.Float32bits(fa) == binary.LittleEndian.Uint32(a[off:off+4]) && math.Float32bits(fb) == binary.LittleEndian.Uint32(b[off:off+4]) {
				appendCandidate(&c, off, 4, "f32le", fmt.Sprint(expectedA), fmt.Sprint(expectedB), ctx(off), 105)
			}
		}
		if off+8 <= limit {
			ua, ub := uint64(expectedA), uint64(expectedB)
			if expectedA >= 0 && expectedB >= 0 && binary.LittleEndian.Uint64(a[off:off+8]) == ua && binary.LittleEndian.Uint64(b[off:off+8]) == ub {
				appendCandidate(&c, off, 8, "u64le", fmt.Sprint(expectedA), fmt.Sprint(expectedB), ctx(off), 115)
			}
			da, db := math.Float64bits(float64(expectedA)), math.Float64bits(float64(expectedB))
			if binary.LittleEndian.Uint64(a[off:off+8]) == da && binary.LittleEndian.Uint64(b[off:off+8]) == db {
				appendCandidate(&c, off, 8, "f64le", fmt.Sprint(expectedA), fmt.Sprint(expectedB), ctx(off), 100)
			}
		}
	}
	// De-duplicate exact offset/encoding matches then sort strongest first.
	seen := map[string]bool{}
	d := c[:0]
	for _, x := range c {
		k := fmt.Sprintf("%d/%s", x.Offset, x.Encoding)
		if seen[k] {
			continue
		}
		seen[k] = true
		d = append(d, x)
	}
	sort.SliceStable(d, func(i, j int) bool {
		if d[i].Score != d[j].Score {
			return d[i].Score > d[j].Score
		}
		return d[i].Offset < d[j].Offset
	})
	return d
}

func buildSavePairWizardReport(pathA string, a []byte, pathB string, b []byte, expectedA, expectedB *int64) (string, []ResearchCandidate) {
	schemaOffset := len(a)
	var types []SchemaType
	if off, t, err := parseSchema(a); err == nil {
		schemaOffset, types = off, t
	}
	ranges, changed := diffSaveRanges(a, b, 8)
	occ := collectSchemaOccurrences(a, schemaOffset, types)
	candidates := make([]ResearchCandidate, 0, 64)
	for _, r := range ranges {
		if r.End-r.Start <= 8 && r.Changed <= 8 {
			context := "raw"
			if o := nearestOccurrence(occ, r.Start); o != nil {
				context = fmt.Sprintf("%s+0x%X", o.Type, r.Start-o.Offset)
			}
			candidates = append(candidates, ResearchCandidate{Offset: r.Start, Width: r.End - r.Start, Encoding: "changed-range", ValueA: valueProbe(a, r.Start), ValueB: valueProbe(b, r.Start), Context: context, Status: "Possible", Score: 50})
		}
	}
	if expectedA != nil && expectedB != nil {
		exact := correlateNumericValues(a, b, *expectedA, *expectedB, schemaOffset, types)
		candidates = append(candidates, exact...)
	}
	sort.SliceStable(candidates, func(i, j int) bool {
		if candidates[i].Score != candidates[j].Score {
			return candidates[i].Score > candidates[j].Score
		}
		return candidates[i].Offset < candidates[j].Offset
	})

	var out strings.Builder
	fmt.Fprintf(&out, "FFXV SAVE PAIR WIZARD\n\nA: %s\nB: %s\nKinds: %s / %s\nSizes: %d / %d\nChanged bytes: %d\nGrouped regions: %d\n\n", pathA, pathB, saveKindLabel(a), saveKindLabel(b), len(a), len(b), changed, len(ranges))
	if expectedA != nil && expectedB != nil {
		fmt.Fprintf(&out, "Expected in-game value: %d → %d\n\n", *expectedA, *expectedB)
	}
	out.WriteString("RANKED CANDIDATES\n")
	if len(candidates) == 0 {
		out.WriteString("No compact candidate fields found. Make a cleaner controlled pair.\n")
	}
	lim := len(candidates)
	if lim > 300 {
		lim = 300
	}
	for i := 0; i < lim; i++ {
		x := candidates[i]
		fmt.Fprintf(&out, "#%03d score=%3d  0x%08X  width=%d  %-13s  %-44s  %s → %s\n", i+1, x.Score, x.Offset, x.Width, x.Encoding, x.Context, x.ValueA, x.ValueB)
	}
	out.WriteString("\nBIT CHANGES\n")
	out.WriteString(bitfieldDiffReport(a, b, 250))
	out.WriteString("\nMETHOD\nUse one in-game change per pair. Repeat the same field with a second value transition. Promote a candidate only when offset/context/encoding repeat and edited output survives a retail load.\n")
	return out.String(), candidates
}

func candidateTSV(c []ResearchCandidate) string {
	var b strings.Builder
	b.WriteString("offset\twidth\tencoding\tvalue_a\tvalue_b\tcontext\tstatus\tscore\tnote\n")
	for _, x := range c {
		fmt.Fprintf(&b, "0x%X\t%d\t%s\t%s\t%s\t%s\t%s\t%d\t%s\n", x.Offset, x.Width, x.Encoding, strings.ReplaceAll(x.ValueA, "\t", " "), strings.ReplaceAll(x.ValueB, "\t", " "), x.Context, x.Status, x.Score, strings.ReplaceAll(x.Note, "\t", " "))
	}
	return b.String()
}

func writeCandidateTracker(basePath string, c []ResearchCandidate) (string, error) {
	clean := filepath.Clean(basePath)
	stem := strings.TrimSuffix(clean, filepath.Ext(clean))
	path := stem + ".research_candidates.tsv"
	// Preserve manually promoted statuses/notes when the same key already exists.
	oldStatus := map[string][2]string{}
	if raw, err := os.ReadFile(path); err == nil {
		lines := strings.Split(string(raw), "\n")
		for _, ln := range lines[1:] {
			f := strings.Split(ln, "\t")
			if len(f) < 9 {
				continue
			}
			oldStatus[f[0]+"/"+f[2]] = [2]string{f[6], f[8]}
		}
	}
	for i := range c {
		k := fmt.Sprintf("0x%X/%s", c[i].Offset, c[i].Encoding)
		if v, ok := oldStatus[k]; ok {
			if v[0] != "" {
				c[i].Status = v[0]
			}
			c[i].Note = v[1]
		}
	}
	return path, os.WriteFile(path, []byte(candidateTSV(c)), 0644)
}

func buildFullItemBrowserReport(model *SaveModel) string {
	if model == nil {
		return "No gameplay0 model loaded."
	}
	type row struct {
		Cat, Name string
		Fix       uint32
		Qty       int32
		Owned     bool
		Bank      int
	}
	rows := make([]row, 0, len(model.Inventory)+len(model.Equipment))
	for _, s := range model.Inventory {
		rows = append(rows, row{s.Category, itemDisplayName(s.FixID), s.FixID, s.Amount, s.Amount > 0, s.CategoryIndex})
	}
	for _, e := range model.Equipment {
		if e.FixID == 0 || isPlaceholderEquipment(e.FixID) {
			continue
		}
		rows = append(rows, row{e.Category, equipmentDisplayName(e.FixID), e.FixID, 1, e.Exists, e.CategoryIndex})
	}
	sort.SliceStable(rows, func(i, j int) bool {
		if rows[i].Cat != rows[j].Cat {
			return rows[i].Cat < rows[j].Cat
		}
		return strings.ToLower(rows[i].Name) < strings.ToLower(rows[j].Name)
	})
	var b strings.Builder
	fmt.Fprintf(&b, "FULL ITEM / EQUIPMENT BROWSER\nMode: %s\nRows: %d\n\n", model.GameMode, len(rows))
	fmt.Fprintf(&b, "%-18s %-40s %-10s %-7s %-6s %s\n", "CATEGORY", "NAME", "FIXID", "QTY", "OWNED", "BANK/SLOT")
	for _, r := range rows {
		fmt.Fprintf(&b, "%-18s %-40s %08X   %-7d %-6t %d\n", r.Cat, r.Name, r.Fix, r.Qty, r.Owned, r.Bank)
	}
	return b.String()
}

func repairComradesEquipmentSafe(gp *SaveModel, sys *ComradesSystemData) (string, int, error) {
	if gp == nil || gp.GameMode != "Comrades" || gp.Comrades == nil {
		return "", 0, fmt.Errorf("load Comrades gameplay0 first")
	}
	if sys == nil {
		return "", 0, fmt.Errorf("load matching Comrades system_data first")
	}
	owner := int32(gp.Comrades.SaveIndex)
	fixed := 0
	var b strings.Builder
	fmt.Fprintf(&b, "SAFE EQUIPMENT REPAIR\nLoadout %d / avatar save index %d\n\n", sys.AvatarUseNo, owner)
	for _, s := range sys.Slots {
		if s.Loadout != int(sys.AvatarUseNo) {
			continue
		}
		cat := "Weapons"
		if s.Kind == "Accessory" {
			cat = "Accessories"
		}
		r := findMasterRecord(gp, cat, int(s.BankNumber))
		if r == nil || r.FixID != s.FixID || r.Type != s.Type {
			fmt.Fprintf(&b, "%s %d: skipped master mismatch\n", s.Kind, s.SlotIndex)
			continue
		}
		changed := false
		if !r.Exists {
			r.Exists = true
			changed = true
		}
		desiredBank := int32(s.SlotIndex - 1)
		if r.EquipmentOwner != owner || r.EquipmentBank != desiredBank {
			r.EquipmentOwner = owner
			r.EquipmentBank = desiredBank
			changed = true
		}
		if changed {
			fixed++
			fmt.Fprintf(&b, "%s %d: staged ownership/link repair for %s\n", s.Kind, s.SlotIndex, equipmentDisplayName(s.FixID))
		} else {
			fmt.Fprintf(&b, "%s %d: already consistent\n", s.Kind, s.SlotIndex)
		}
	}
	fmt.Fprintf(&b, "\nStaged safe repairs: %d\n", fixed)
	return b.String(), fixed, nil
}

func backupComradesSaveSet(s *ComradesSaveSet) (string, error) {
	if s == nil {
		return "", fmt.Errorf("no Comrades save set loaded")
	}
	dir := filepath.Join(s.Dir, "FFXV_SaveEditor_Backup")
	if err := os.MkdirAll(dir, 0755); err != nil {
		return "", err
	}
	copied := 0
	for _, f := range s.Files {
		raw, err := os.ReadFile(f.Path)
		if err != nil {
			return "", err
		}
		base := filepath.Base(f.Path)
		dst := filepath.Join(dir, base)
		if _, err := os.Stat(dst); err == nil {
			stem := strings.TrimSuffix(base, filepath.Ext(base))
			ext := filepath.Ext(base)
			for n := 2; n < 10000; n++ {
				p := filepath.Join(dir, fmt.Sprintf("%s_%d%s", stem, n, ext))
				if _, e := os.Stat(p); os.IsNotExist(e) {
					dst = p
					break
				}
			}
		}
		if err := writeFileExclusive(dst, raw, 0644); err != nil {
			return "", err
		}
		// Copy matching crypto sidecar if present.
		side := f.Path + ".ffxvmeta.json"
		if sr, e := os.ReadFile(side); e == nil {
			_ = writeFileExclusive(dst+".ffxvmeta.json", sr, 0644)
		}
		copied++
	}
	return fmt.Sprintf("Backed up %d save file(s) to %s", copied, dir), nil
}
