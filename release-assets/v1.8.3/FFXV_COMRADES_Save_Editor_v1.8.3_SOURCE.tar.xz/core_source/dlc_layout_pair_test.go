package main

import (
	"bytes"
	"encoding/json"
	"os"
	"path/filepath"
	"testing"
)

// Exact regression for the uploaded DLC/Comrades encrypted <-> decrypted pair.
// The test is fixture-aware so source distributions remain runnable without
// bundling user saves.
func TestUploadedDLCGameplayPairWhenPresent(t *testing.T) {
	encryptedPath := "testdata/gameplay0(20260821-145222).save"
	decryptedPath := "testdata/gameplay0.decrypted.save"

	encrypted, err := os.ReadFile(encryptedPath)
	if os.IsNotExist(err) {
		t.Skip("uploaded DLC encrypted sample not present")
	}
	if err != nil {
		t.Fatal(err)
	}
	expectedPlain, err := os.ReadFile(decryptedPath)
	if os.IsNotExist(err) {
		t.Skip("uploaded DLC decrypted sample not present")
	}
	if err != nil {
		t.Fatal(err)
	}

	intermediate, err := decryptOuterLayer(encrypted)
	if err != nil {
		t.Fatal(err)
	}
	plain, first, err := decodeGameplayChain(intermediate)
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(plain, expectedPlain) {
		t.Fatal("decryption does not match the uploaded DLC plaintext byte-for-byte")
	}

	kind, err := detectFFXVPlainKind(plain)
	if err != nil {
		t.Fatal(err)
	}
	if kind != "Comrades gameplay0" {
		t.Fatalf("save kind=%q, want Comrades gameplay0", kind)
	}

	model, err := parseSaveModelBytes(plain, decryptedPath)
	if err != nil {
		t.Fatal(err)
	}
	if model.GameMode != "Comrades" {
		t.Fatalf("model mode=%q, want Comrades", model.GameMode)
	}
	if model.Party.ControlledCharacter != 11 {
		t.Fatalf("controlled character=%d, want 11 for the uploaded DLC avatar", model.Party.ControlledCharacter)
	}

	encoded, err := encodeGameplayChain(plain, first)
	if err != nil {
		t.Fatal(err)
	}
	roundTrip, err := encryptOuterLayer(encoded)
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(roundTrip, encrypted) {
		t.Fatal("DLC plaintext did not re-encrypt byte-for-byte to the uploaded source")
	}

	metadata := makeMetadata(encrypted, plain, first)
	raw, err := json.Marshal(metadata)
	if err != nil {
		t.Fatal(err)
	}
	var decoded sidecarMetadata
	if err := json.Unmarshal(raw, &decoded); err != nil {
		t.Fatal(err)
	}
	if decoded.SaveKind != "Comrades gameplay0" {
		t.Fatalf("sidecar save_kind=%q, want Comrades gameplay0", decoded.SaveKind)
	}
}

func TestOneClickEditedPlaintextEncryptsToModdedWhenPairPresent(t *testing.T) {
	encryptedPath := "testdata/gameplay0(20260821-145222).save"
	decryptedPath := "testdata/gameplay0.decrypted.save"
	encrypted, err := os.ReadFile(encryptedPath)
	if os.IsNotExist(err) {
		t.Skip("uploaded DLC encrypted sample not present")
	}
	if err != nil {
		t.Fatal(err)
	}
	plain, err := os.ReadFile(decryptedPath)
	if os.IsNotExist(err) {
		t.Skip("uploaded DLC decrypted sample not present")
	}
	if err != nil {
		t.Fatal(err)
	}
	intermediate, err := decryptOuterLayer(encrypted)
	if err != nil {
		t.Fatal(err)
	}
	_, first, err := decodeGameplayChain(intermediate)
	if err != nil {
		t.Fatal(err)
	}

	d := t.TempDir()
	plainPath := d + "/gameplay0.edited.save"
	if err := os.WriteFile(plainPath, plain, 0o600); err != nil {
		t.Fatal(err)
	}
	if err := writeMetadataExclusive(plainPath+metadataSuffix, makeMetadata(encrypted, plain, first)); err != nil {
		t.Fatal(err)
	}

	res, err := processFile(plainPath, false)
	if err != nil {
		t.Fatal(err)
	}
	if got := filepath.Base(res.OutputPath); got != "gameplay0.save" {
		t.Fatalf("one-click encrypted output name=%q, want gameplay0.save", got)
	}
	if got := filepath.Base(filepath.Dir(res.OutputPath)); got != "MODDED" {
		t.Fatalf("one-click encrypted output folder=%q, want MODDED", got)
	}
	got, err := os.ReadFile(res.OutputPath)
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(got, encrypted) {
		t.Fatal("one-click encrypted output did not match the uploaded DLC source byte-for-byte")
	}
}

func TestDLCComradesGilKWStatsSurviveOneClickEncryption(t *testing.T) {
	encryptedPath := "testdata/gameplay0(20260821-145222).save"
	decryptedPath := "testdata/gameplay0.decrypted.save"
	encrypted, err := os.ReadFile(encryptedPath)
	if os.IsNotExist(err) {
		t.Skip("uploaded DLC encrypted sample not present")
	}
	if err != nil {
		t.Fatal(err)
	}
	plain, err := os.ReadFile(decryptedPath)
	if os.IsNotExist(err) {
		t.Skip("uploaded DLC decrypted sample not present")
	}
	if err != nil {
		t.Fatal(err)
	}

	m, err := parseSaveModelBytes(plain, decryptedPath)
	if err != nil {
		t.Fatal(err)
	}
	if m.GameMode != "Comrades" || m.Comrades == nil || m.ComradesKW == nil {
		t.Fatal("uploaded DLC sample did not expose Comrades gameplay fields")
	}
	if err := stageComradesStatus(m, 77777, 88888, 7777, 8888, 98, 7777, 6666, 5555, 4444, 3333, 87654321, 88765432, 765432); err != nil {
		t.Fatal(err)
	}
	if err := stageComradesKW(m, 424242); err != nil {
		t.Fatal(err)
	}
	g := GeneralEdits{
		ControlledCharacter: m.Party.ControlledCharacter,
		Chapter:             m.Party.Chapter,
		Gil:                 7654321,
		ArenaMedals:         m.Party.ArenaMedals,
		OracleCoins:         m.Party.OracleCoins,
		AbilityPoints:       m.Party.AbilityPoints,
	}
	edited, _, _, _, err := applyModelEdits(plain, m, g)
	if err != nil {
		t.Fatal(err)
	}

	intermediate, err := decryptOuterLayer(encrypted)
	if err != nil {
		t.Fatal(err)
	}
	_, first, err := decodeGameplayChain(intermediate)
	if err != nil {
		t.Fatal(err)
	}
	d := t.TempDir()
	editedPath := filepath.Join(d, "gameplay0.edited.save")
	if err := os.WriteFile(editedPath, edited, 0o600); err != nil {
		t.Fatal(err)
	}
	if err := writeMetadataExclusive(editedPath+metadataSuffix, makeMetadata(encrypted, plain, first)); err != nil {
		t.Fatal(err)
	}
	res, err := processFile(editedPath, false)
	if err != nil {
		t.Fatal(err)
	}

	encOut, err := os.ReadFile(res.OutputPath)
	if err != nil {
		t.Fatal(err)
	}
	mid, err := decryptOuterLayer(encOut)
	if err != nil {
		t.Fatal(err)
	}
	recovered, _, err := decodeGameplayChain(mid)
	if err != nil {
		t.Fatal(err)
	}
	got, err := parseSaveModelBytes(recovered, res.OutputPath)
	if err != nil {
		t.Fatal(err)
	}
	if got.Party.Gil != 7654321 {
		t.Fatalf("Gil after encrypted round trip=%d", got.Party.Gil)
	}
	if got.ComradesKW == nil || got.ComradesKW.Current != 424242 {
		t.Fatalf("kW after encrypted round trip=%+v", got.ComradesKW)
	}
	c := got.Comrades
	if c == nil || c.HP != 77777 || c.HPMax != 88888 || c.MP != 7777 || c.MPMax != 8888 || c.Level != 98 || c.Strength != 7777 || c.Vitality != 6666 || c.Magic != 5555 || c.Spirit != 4444 || c.Critical != 3333 || c.Exp != 87654321 || c.ExpTotal != 88765432 || c.AbilityPoints != 765432 {
		t.Fatalf("Comrades status mismatch after encrypted round trip: %+v", c)
	}
}
