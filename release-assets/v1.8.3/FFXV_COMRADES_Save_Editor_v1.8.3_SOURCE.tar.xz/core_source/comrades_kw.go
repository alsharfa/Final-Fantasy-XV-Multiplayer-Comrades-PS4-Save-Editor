package main

import (
	"encoding/binary"
	"errors"
	"fmt"
)

// Direct Comrades electricity (kW) mapping verified from controlled retail
// gameplay0 snapshots where the in-game display changed 200 -> 1320 kW.
//
// SaveCommonStruct is serialized densely. The field is reserved_[39], which is
// marker+0xA9 (payload base marker+8, then +0xA1). The absolute file offset can
// move when preceding dynamic records change, so edits must always resolve the
// structure marker rather than hard-code an absolute file address.
const (
	comradesKWTypeName         = "Black.Save.Common.SaveCommonStruct"
	comradesKWOffsetFromMarker = 0xA9
	maxComradesKW              = uint32(0x7fffffff) // schema type is signed int
	maxComradesKWPreset        = uint32(999999999)
)

type ComradesKWData struct {
	MarkerOffset int
	ValueOffset  int
	Current      uint32
	Original     uint32
}

func parseComradesKW(data []byte, schemaOffset int, types []SchemaType) (*ComradesKWData, error) {
	t := schemaTypeByName(types, comradesKWTypeName)
	if t == nil {
		return nil, errors.New("SaveCommonStruct is missing")
	}
	// Guard the exact schema family used to verify the field. This prevents a
	// future layout with the same type name but a different packed shape from
	// silently receiving a write at the old relative offset.
	reservedOK, plantOK := false, false
	for _, f := range t.Fields {
		if f.Name == "reserved_" && f.TypeName == "int" && f.Size == 200 {
			reservedOK = true
		}
		if f.Name == "plantMapData_" && f.TypeName == "Black.Save.Multiplay.SavePlantMapDataStruct" {
			plantOK = true
		}
	}
	if !reservedOK || !plantOK {
		return nil, errors.New("SaveCommonStruct layout does not match the verified Comrades kW schema")
	}
	markers := findMarkers(data, t.Hash, schemaOffset)
	if len(markers) != 1 {
		return nil, fmt.Errorf("expected one SaveCommonStruct marker, found %d", len(markers))
	}
	off := markers[0] + comradesKWOffsetFromMarker
	if off < 0 || off+4 > schemaOffset || off+4 > len(data) {
		return nil, errors.New("Comrades kW field is truncated")
	}
	v := binary.LittleEndian.Uint32(data[off : off+4])
	if v > maxComradesKW {
		return nil, fmt.Errorf("Comrades kW value %d exceeds signed-int schema range", v)
	}
	return &ComradesKWData{MarkerOffset: markers[0], ValueOffset: off, Current: v, Original: v}, nil
}

func stageComradesKW(model *SaveModel, value uint32) error {
	if model == nil || model.GameMode != "Comrades" || model.ComradesKW == nil {
		return errors.New("load a supported Comrades gameplay0 save with the verified direct-kW field")
	}
	if value > maxComradesKW {
		return fmt.Errorf("kW must be 0 through %d", maxComradesKW)
	}
	model.ComradesKW.Current = value
	return nil
}

func restoreComradesKW(model *SaveModel) {
	if model == nil || model.ComradesKW == nil {
		return
	}
	model.ComradesKW.Current = model.ComradesKW.Original
}
