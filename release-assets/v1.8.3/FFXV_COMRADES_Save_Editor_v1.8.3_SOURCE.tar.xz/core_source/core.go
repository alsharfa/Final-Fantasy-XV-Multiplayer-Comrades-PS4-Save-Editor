package main

import (
	"bytes"
	"crypto/aes"
	"crypto/cipher"
	"crypto/sha256"
	"encoding/binary"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strings"
)

const (
	footerSize       = 53
	metadataSuffix   = ".ffxvmeta.json"
	metadataFormat   = "FFXV_PS4_GAMEPLAY0_META_V1"
	minimumSaveBytes = footerSize + 32
)

var (
	ps4AES192Key = []byte{
		0x4B, 0x08, 0xF4, 0x84, 0x08, 0x6C, 0x32, 0xDE,
		0x1C, 0x79, 0xC1, 0x17, 0x60, 0x15, 0x5D, 0xFF,
		0x3D, 0x53, 0x09, 0x70, 0x6A, 0xBB, 0xC4, 0x37,
	}
	gameplayMagic = [4]byte{0x65, 0x62, 0x62, 0x01}
)

type saveParts struct {
	payload []byte
	footer  []byte
	iv      []byte
	tweak   []byte
	seed    uint32
}

type sidecarMetadata struct {
	Format                 string `json:"format"`
	IntermediateFirstBlock string `json:"intermediate_first_block"`
	FooterSHA256           string `json:"footer_sha256"`
	SourceEncryptedSHA256  string `json:"source_encrypted_sha256"`
	PlainSHA256AtDecrypt   string `json:"plain_sha256_at_decrypt"`
	PayloadSize            int    `json:"payload_size,omitempty"`
	SaveKind               string `json:"save_kind,omitempty"`
}

type operationResult struct {
	OutputPath   string `json:"outputPath"`
	MetadataPath string `json:"metadataPath,omitempty"`
	SHA256       string `json:"sha256"`
	Size         int    `json:"size"`
}

func parseSave(data []byte) (*saveParts, error) {
	if len(data) < minimumSaveBytes {
		return nil, fmt.Errorf("file is too small to be an FFXV gameplay0 save")
	}

	payloadLength := len(data) - footerSize
	if payloadLength%aes.BlockSize != 0 {
		return nil, fmt.Errorf("payload length %d is not a multiple of 16", payloadLength)
	}

	footer := append([]byte(nil), data[payloadLength:]...)
	return &saveParts{
		payload: append([]byte(nil), data[:payloadLength]...),
		footer:  footer,
		iv:      append([]byte(nil), footer[0:16]...),
		tweak:   append([]byte(nil), footer[16:32]...),
		seed:    binary.LittleEndian.Uint32(footer[32:36]),
	}, nil
}

// decryptOuterLayer reproduces the FFXV AES/tweak/shuffle stage. The result is
// still PS4-chain encoded and must be passed through decodeGameplayChain.
func decryptOuterLayer(data []byte) ([]byte, error) {
	parts, err := parseSave(data)
	if err != nil {
		return nil, err
	}

	for i := range parts.payload {
		parts.payload[i] -= parts.tweak[i&0x0F]
	}
	shuffleBlocks(parts.payload, parts.seed, false)

	block, err := aes.NewCipher(ps4AES192Key)
	if err != nil {
		return nil, err
	}
	plain := make([]byte, len(parts.payload))
	cipher.NewCBCDecrypter(block, parts.iv).CryptBlocks(plain, parts.payload)
	return append(plain, parts.footer...), nil
}

// encryptOuterLayer reverses decryptOuterLayer.
func encryptOuterLayer(data []byte) ([]byte, error) {
	parts, err := parseSave(data)
	if err != nil {
		return nil, err
	}

	block, err := aes.NewCipher(ps4AES192Key)
	if err != nil {
		return nil, err
	}
	encrypted := make([]byte, len(parts.payload))
	cipher.NewCBCEncrypter(block, parts.iv).CryptBlocks(encrypted, parts.payload)
	shuffleBlocks(encrypted, parts.seed, true)
	for i := range encrypted {
		encrypted[i] += parts.tweak[i&0x0F]
	}
	return append(encrypted, parts.footer...), nil
}

// decodeGameplayChain removes the FFXV 16-byte chaining layer used by the
// campaign and Comrades save family. The encrypted stream does not preserve
// the first four EBB magic bytes. Recover the revision from the decoded schema:
// gameplay0 uses EBB01, while the verified Comrades auxiliary saves
// (avatar0/system_data/universal_data) use EBB00.
func decodeGameplayChain(intermediate []byte) ([]byte, [16]byte, error) {
	parts, err := parseSave(intermediate)
	if err != nil {
		return nil, [16]byte{}, err
	}
	if len(parts.payload) < 32 {
		return nil, [16]byte{}, errors.New("payload is too small for FFXV chaining")
	}

	var firstIntermediate [16]byte
	copy(firstIntermediate[:], parts.payload[:16])

	plain := make([]byte, len(parts.payload))
	copy(plain[:16], parts.payload[:16])
	// Use EBB00 temporarily so the schema can be decoded. The schema itself is
	// independent of byte 3; after parsing, gameplay0 is promoted to EBB01.
	copy(plain[:4], []byte{0x65, 0x62, 0x62, 0x00})

	for j := 0; j < 16; j++ {
		plain[16+j] = parts.payload[16+j] ^ parts.payload[j]
	}
	for offset := 32; offset < len(parts.payload); offset += 16 {
		for j := 0; j < 16; j++ {
			plain[offset+j] = parts.payload[offset+j] ^ plain[offset-16+j]
		}
	}

	output := append(plain, parts.footer...)
	// Schema parsing is independent of the EBB revision byte. gameplay0 is the
	// only verified member of this family that uses EBB01. Earlier v4.x builds
	// incorrectly left Comrades gameplay0 at EBB00, which could still pass a
	// decrypt->encrypt byte-for-byte test because the chaining layer does not
	// preserve the first four plaintext bytes.
	if _, types, schemaErr := parseSchema(output); schemaErr == nil {
		if schemaTypeByName(types, "Black.Save.SaveInformation") != nil &&
			schemaTypeByName(types, "Black.Save.Item.SaveItemStruct") != nil {
			output[3] = 0x01
		}
	}
	if _, err := detectFFXVPlainKind(output); err != nil {
		return nil, [16]byte{}, err
	}
	return output, firstIntermediate, nil
}

func encodeGameplayChain(plain []byte, firstIntermediate [16]byte) ([]byte, error) {
	if _, err := detectFFXVPlainKind(plain); err != nil {
		return nil, err
	}
	parts, err := parseSave(plain)
	if err != nil {
		return nil, err
	}
	if len(parts.payload) < 32 {
		return nil, errors.New("payload is too small for FFXV chaining")
	}

	if !equalBytes(parts.payload[4:16], firstIntermediate[4:16]) {
		return nil, errors.New("header bytes 4..15 do not match the metadata sidecar; use the matching sidecar created during decryption")
	}

	intermediate := make([]byte, len(parts.payload))
	copy(intermediate[:16], firstIntermediate[:])
	for j := 0; j < 16; j++ {
		intermediate[16+j] = parts.payload[16+j] ^ firstIntermediate[j]
	}
	for offset := 32; offset < len(parts.payload); offset += 16 {
		for j := 0; j < 16; j++ {
			intermediate[offset+j] = parts.payload[offset+j] ^ parts.payload[offset-16+j]
		}
	}
	return append(intermediate, parts.footer...), nil
}

func minInt(a, b int) int {
	if a < b {
		return a
	}
	return b
}

func canonicalizePlainForCrypto(data []byte) []byte {
	if len(data) < 4 || data[0] != 0x65 || data[1] != 0x62 || data[2] != 0x62 {
		return data
	}
	_, types, err := parseSchema(data)
	if err != nil {
		return data
	}
	if schemaTypeByName(types, "Black.Save.SaveInformation") == nil ||
		schemaTypeByName(types, "Black.Save.Item.SaveItemStruct") == nil || data[3] == 0x01 {
		return data
	}
	out := append([]byte(nil), data...)
	out[3] = 0x01
	return out
}

func detectFFXVPlainKind(data []byte) (string, error) {
	if len(data) < 32 {
		return "", errors.New("file is too small to be a decrypted FFXV save")
	}
	if data[0] != 0x65 || data[1] != 0x62 || data[2] != 0x62 || (data[3] != 0x00 && data[3] != 0x01) {
		return "", fmt.Errorf("plaintext header is % X; expected FFXV EBB header 65 62 62 00 or 65 62 62 01", data[:4])
	}
	if binary.LittleEndian.Uint32(data[4:8]) != 4 {
		return "", fmt.Errorf("unsupported EBB header version %d", binary.LittleEndian.Uint32(data[4:8]))
	}
	_, types, err := parseSchema(data)
	if err != nil {
		return "", fmt.Errorf("EBB schema validation failed: %w", err)
	}
	has := func(name string) bool { return schemaTypeByName(types, name) != nil }
	switch {
	case has("Black.Save.SaveInformation") && has("Black.Save.Item.SaveItemStruct"):
		limit := minInt(len(data), 1024*1024)
		if containsBytes(data[:limit], []byte("level/DLC/multi/")) || has("Black.Save.Multiplay.SavePlantMapDataStruct") && len(types) == 95 {
			return "Comrades gameplay0", nil
		}
		return "Main-game gameplay0", nil
	case has("Black.Save.Multiplay.SaveAvatarStruct"):
		return "Comrades avatar0", nil
	case has("Black.Save.Config.SaveGameConfigNoxMultiplayer"):
		return "Comrades system_data", nil
	case has("Black.Save.Universal.SaveUniversalStruct"):
		return "Universal data", nil
	case has("Black.Save.Config.SaveGameConfigMain"):
		return "Main-game system_data", nil
	default:
		return fmt.Sprintf("FFXV EBB data (%d schema types)", len(types)), nil
	}
}

func validateGameplayPlain(data []byte) error {
	kind, err := detectFFXVPlainKind(data)
	if err != nil {
		return err
	}
	if kind != "Main-game gameplay0" && kind != "Comrades gameplay0" {
		return fmt.Errorf("selected plaintext is %s, not gameplay0", kind)
	}
	return nil
}

func makeMetadata(inputEncrypted, plain []byte, firstIntermediate [16]byte) sidecarMetadata {
	inputHash := sha256.Sum256(inputEncrypted)
	plainHash := sha256.Sum256(plain)
	footerHash := sha256.Sum256(plain[len(plain)-footerSize:])
	kind, _ := detectFFXVPlainKind(plain)
	return sidecarMetadata{
		Format:                 metadataFormat,
		IntermediateFirstBlock: hex.EncodeToString(firstIntermediate[:]),
		FooterSHA256:           hex.EncodeToString(footerHash[:]),
		SourceEncryptedSHA256:  hex.EncodeToString(inputHash[:]),
		PlainSHA256AtDecrypt:   hex.EncodeToString(plainHash[:]),
		PayloadSize:            len(plain) - footerSize,
		SaveKind:               kind,
	}
}

func writeMetadataExclusive(path string, metadata sidecarMetadata) error {
	encoded, err := json.MarshalIndent(metadata, "", "  ")
	if err != nil {
		return fmt.Errorf("encode metadata: %w", err)
	}
	encoded = append(encoded, '\n')
	if err := writeFileExclusive(path, encoded, 0o600); err != nil {
		return fmt.Errorf("write metadata: %w", err)
	}
	return nil
}

func writeFileExclusive(path string, data []byte, mode os.FileMode) error {
	file, err := os.OpenFile(path, os.O_WRONLY|os.O_CREATE|os.O_EXCL, mode)
	if err != nil {
		return err
	}
	written, writeErr := file.Write(data)
	if writeErr == nil && written != len(data) {
		writeErr = fmt.Errorf("short write: wrote %d of %d bytes", written, len(data))
	}
	if writeErr == nil {
		writeErr = file.Sync()
	}
	closeErr := file.Close()
	if writeErr == nil {
		writeErr = closeErr
	}
	if writeErr != nil {
		_ = os.Remove(path)
		return writeErr
	}
	return nil
}

func cleanInputPath(path string) string {
	return strings.TrimSpace(strings.Trim(path, "\""))
}

func readRegularFile(path string) ([]byte, string, error) {
	cleaned := cleanInputPath(path)
	if cleaned == "" {
		return nil, "", errors.New("select a save file first")
	}
	info, err := os.Stat(cleaned)
	if err != nil {
		return nil, cleaned, fmt.Errorf("inspect input: %w", err)
	}
	if !info.Mode().IsRegular() {
		return nil, cleaned, errors.New("selected path is not a regular file")
	}
	data, err := os.ReadFile(cleaned)
	if err != nil {
		return nil, cleaned, fmt.Errorf("read input: %w", err)
	}
	return data, cleaned, nil
}

func readMetadata(path string, plain []byte) ([16]byte, error) {
	var first [16]byte
	if len(plain) < minimumSaveBytes {
		return first, errors.New("plaintext is too small for metadata validation")
	}
	encoded, err := os.ReadFile(path)
	if err != nil {
		if os.IsNotExist(err) {
			return first, fmt.Errorf("metadata sidecar not found: %s\nDecrypt the encrypted save with this version first, then keep the .ffxvmeta.json file beside the decrypted save", path)
		}
		return first, fmt.Errorf("read metadata: %w", err)
	}
	var metadata sidecarMetadata
	if err := json.Unmarshal(encoded, &metadata); err != nil {
		return first, fmt.Errorf("parse metadata: %w", err)
	}
	if metadata.Format != metadataFormat {
		return first, fmt.Errorf("unsupported metadata format %q", metadata.Format)
	}
	block, err := hex.DecodeString(metadata.IntermediateFirstBlock)
	if err != nil || len(block) != 16 {
		return first, errors.New("metadata contains an invalid first intermediate block")
	}
	copy(first[:], block)
	if metadata.PayloadSize != 0 && metadata.PayloadSize != len(plain)-footerSize {
		return first, fmt.Errorf("metadata payload size %d does not match selected save payload size %d", metadata.PayloadSize, len(plain)-footerSize)
	}
	footerHash := sha256.Sum256(plain[len(plain)-footerSize:])
	if !strings.EqualFold(metadata.FooterSHA256, hex.EncodeToString(footerHash[:])) {
		return first, errors.New("metadata does not belong to this save footer")
	}
	return first, nil
}

func processFile(inputPath string, decrypt bool) (*operationResult, error) {
	input, inputPath, err := readRegularFile(inputPath)
	if err != nil {
		return nil, err
	}

	outputPath, err := uniqueOutputPath(inputPath, decrypt)
	if err != nil {
		return nil, err
	}

	result := &operationResult{OutputPath: outputPath}
	var output []byte

	if decrypt {
		intermediate, err := decryptOuterLayer(input)
		if err != nil {
			return nil, err
		}
		plain, firstIntermediate, err := decodeGameplayChain(intermediate)
		if err != nil {
			return nil, err
		}

		// Verification includes the newly identified PS4 chain layer and must
		// reproduce the encrypted source byte-for-byte.
		reencoded, err := encodeGameplayChain(plain, firstIntermediate)
		if err != nil {
			return nil, fmt.Errorf("verification chain encode failed: %w", err)
		}
		roundTrip, err := encryptOuterLayer(reencoded)
		if err != nil {
			return nil, fmt.Errorf("verification encryption failed: %w", err)
		}
		if !equalBytes(roundTrip, input) {
			return nil, errors.New("verified PS4 decrypt round-trip failed; no output was written")
		}
		output = plain
		result.MetadataPath = outputPath + metadataSuffix
		metadata := makeMetadata(input, plain, firstIntermediate)

		if err := writeFileExclusive(outputPath, output, 0o644); err != nil {
			return nil, fmt.Errorf("write output: %w", err)
		}
		if err := writeMetadataExclusive(result.MetadataPath, metadata); err != nil {
			_ = os.Remove(outputPath)
			return nil, err
		}
	} else {
		if _, err := detectFFXVPlainKind(input); err != nil {
			return nil, fmt.Errorf("input is not verified FFXV plaintext: %w", err)
		}
		// v4.5 could emit Comrades gameplay0 as EBB00. The first four magic
		// bytes are not represented by the gameplay chaining layer, so normalize
		// gameplay0 to the verified EBB01 form before encryption/verification.
		cryptoPlain := canonicalizePlainForCrypto(input)
		metadataPath := inputPath + metadataSuffix
		firstIntermediate, err := readMetadata(metadataPath, input)
		if err != nil {
			return nil, err
		}
		intermediate, err := encodeGameplayChain(cryptoPlain, firstIntermediate)
		if err != nil {
			return nil, err
		}
		encrypted, err := encryptOuterLayer(intermediate)
		if err != nil {
			return nil, err
		}

		// Verify by fully decrypting back to the selected edited plaintext.
		verifyIntermediate, err := decryptOuterLayer(encrypted)
		if err != nil {
			return nil, fmt.Errorf("verification decryption failed: %w", err)
		}
		verifyPlain, recoveredFirst, err := decodeGameplayChain(verifyIntermediate)
		if err != nil {
			return nil, fmt.Errorf("verification chain decode failed: %w", err)
		}
		if recoveredFirst != firstIntermediate || !equalBytes(verifyPlain, cryptoPlain) {
			return nil, errors.New("verified PS4 encryption round-trip failed; no output was written")
		}
		output = encrypted
		if err := os.MkdirAll(filepath.Dir(outputPath), 0o755); err != nil {
			return nil, fmt.Errorf("create output folder: %w", err)
		}
		if err := writeFileExclusive(outputPath, output, 0o644); err != nil {
			return nil, fmt.Errorf("write output: %w", err)
		}
	}

	hash := sha256.Sum256(output)
	result.SHA256 = hex.EncodeToString(hash[:])
	result.Size = len(output)
	return result, nil
}

func shuffleBlocks(data []byte, seed uint32, encryptDirection bool) {
	blockCount := len(data) / aes.BlockSize
	keyStack := generateKeyStack(seed, blockCount)
	if encryptDirection {
		for i := blockCount - 1; i > 0; i-- {
			swapBlocks(data, i, keyStack[i])
		}
		return
	}
	for i := 1; i < blockCount; i++ {
		swapBlocks(data, i, keyStack[i])
	}
}

func swapBlocks(data []byte, a, b int) {
	if a == b {
		return
	}
	aStart := a * aes.BlockSize
	bStart := b * aes.BlockSize
	var temp [aes.BlockSize]byte
	copy(temp[:], data[aStart:aStart+aes.BlockSize])
	copy(data[aStart:aStart+aes.BlockSize], data[bStart:bStart+aes.BlockSize])
	copy(data[bStart:bStart+aes.BlockSize], temp[:])
}

func generateKeyStack(seed uint32, bufferSize int) []int {
	keyStack := make([]int, bufferSize)
	mt := newMersenneTwister(seed)
	for i := bufferSize - 1; i > 1; i-- {
		divisor := uint32(i)
		threshold := ^(uint32(0xFFFFFFFF) % divisor)
		for {
			value := mt.nextUInt()
			if value < threshold {
				keyStack[i] = int(value % divisor)
				break
			}
		}
	}
	return keyStack
}

type mersenneTwister struct {
	mt  [624]uint32
	mti int
}

func newMersenneTwister(seed uint32) *mersenneTwister {
	mt := &mersenneTwister{}
	mt.initialize(seed)
	return mt
}

func (m *mersenneTwister) initialize(seed uint32) {
	m.mt[0] = seed
	for m.mti = 1; m.mti < 624; m.mti++ {
		previous := m.mt[m.mti-1]
		m.mt[m.mti] = 1812433253*(previous^(previous>>30)) + uint32(m.mti)
	}
}

func (m *mersenneTwister) nextUInt() uint32 {
	const (
		n         = 624
		middle    = 397
		matrixA   = uint32(0x9908B0DF)
		upperMask = uint32(0x80000000)
		lowerMask = uint32(0x7FFFFFFF)
	)
	if m.mti >= n {
		var y uint32
		for kk := 0; kk < n-middle; kk++ {
			y = (m.mt[kk] & upperMask) | (m.mt[kk+1] & lowerMask)
			m.mt[kk] = m.mt[kk+middle] ^ (y >> 1)
			if y&1 != 0 {
				m.mt[kk] ^= matrixA
			}
		}
		for kk := n - middle; kk < n-1; kk++ {
			y = (m.mt[kk] & upperMask) | (m.mt[kk+1] & lowerMask)
			m.mt[kk] = m.mt[kk+(middle-n)] ^ (y >> 1)
			if y&1 != 0 {
				m.mt[kk] ^= matrixA
			}
		}
		y = (m.mt[n-1] & upperMask) | (m.mt[0] & lowerMask)
		m.mt[n-1] = m.mt[middle-1] ^ (y >> 1)
		if y&1 != 0 {
			m.mt[n-1] ^= matrixA
		}
		m.mti = 0
	}
	y := m.mt[m.mti]
	m.mti++
	y ^= y >> 11
	y ^= (y << 7) & 0x9D2C5680
	y ^= (y << 15) & 0xEFC60000
	y ^= y >> 18
	return y
}

func workflowSuffixKind(stem string) (string, bool) {
	idx := strings.LastIndex(stem, ".")
	if idx < 0 || idx+1 >= len(stem) {
		return "", false
	}
	token := strings.ToLower(stem[idx+1:])
	for _, kind := range []string{"decrypted", "encrypted", "edited", "backup", "modded"} {
		if token == kind {
			return kind, true
		}
		prefix := kind + "_"
		if strings.HasPrefix(token, prefix) && len(token) > len(prefix) {
			digits := true
			for _, r := range token[len(prefix):] {
				if r < '0' || r > '9' {
					digits = false
					break
				}
			}
			if digits {
				return kind, true
			}
		}
	}
	return "", false
}

func trimWorkflowSuffixes(stem string) string {
	for {
		if _, ok := workflowSuffixKind(stem); !ok {
			return stem
		}
		stem = stem[:strings.LastIndex(stem, ".")]
	}
}

func uniqueOutputPath(inputPath string, decrypt bool) (string, error) {
	extension := filepath.Ext(inputPath)
	rawStem := strings.TrimSuffix(inputPath, extension)

	// One-click editor output must keep the filename the game actually expects.
	// Putting "gameplay0.MODDED.save" beside gameplay0.save is easy to misuse: if
	// both files are copied back, the game simply continues reading gameplay0.save.
	// Keep the original basename and isolate the replacement in a MODDED folder.
	if !decrypt {
		// gameplay0 plaintext always produces a game-ready replacement named
		// gameplay0.save inside an isolated MODDED folder, regardless of whether
		// the selected plaintext uses .decrypted or .edited workflow suffixes.
		baseName := filepath.Base(trimWorkflowSuffixes(rawStem)) + extension
		if strings.EqualFold(baseName, "gameplay0"+extension) {
			parent := filepath.Dir(inputPath)
			for counter := 1; counter <= 10000; counter++ {
				dirName := "MODDED"
				if counter > 1 {
					dirName = fmt.Sprintf("MODDED_%d", counter)
				}
				candidate := filepath.Join(parent, dirName, baseName)
				_, err := os.Stat(candidate)
				if os.IsNotExist(err) {
					return candidate, nil
				}
				if err != nil {
					return "", fmt.Errorf("check output path: %w", err)
				}
			}
			return "", errors.New("could not find an unused MODDED output folder")
		}
	}

	stem := rawStem
	suffix := ".encrypted"
	if decrypt {
		stem = trimWorkflowSuffixes(rawStem)
		suffix = ".decrypted"
	} else {
		stem = trimWorkflowSuffixes(rawStem)
	}
	for counter := 1; counter <= 10000; counter++ {
		candidate := stem + suffix + extension
		if counter > 1 {
			candidate = fmt.Sprintf("%s%s_%d%s", stem, suffix, counter, extension)
		}
		pathsToCheck := []string{candidate}
		if decrypt {
			pathsToCheck = append(pathsToCheck, candidate+metadataSuffix)
		}
		available := true
		for _, path := range pathsToCheck {
			_, err := os.Stat(path)
			if err == nil {
				available = false
				break
			}
			if !os.IsNotExist(err) {
				return "", fmt.Errorf("check output path: %w", err)
			}
		}
		if available {
			return candidate, nil
		}
	}
	return "", errors.New("could not find an unused output name")
}

func containsBytes(haystack, needle []byte) bool {
	return bytes.Contains(haystack, needle)
}

func equalBytes(a, b []byte) bool {
	if len(a) != len(b) {
		return false
	}
	var different byte
	for i := range a {
		different |= a[i] ^ b[i]
	}
	return different == 0
}
