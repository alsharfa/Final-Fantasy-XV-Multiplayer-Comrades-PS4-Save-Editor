package main

import (
	"os"
	"testing"
)

func TestHiddenModdedPackOnUploadedComradesWhenPresent(t *testing.T) {
	const path = "testdata/gameplay0_decrypted(2).save"
	plain, err := os.ReadFile(path)
	if os.IsNotExist(err) {
		t.Skip("uploaded Comrades sample not present")
	}
	if err != nil {
		t.Fatal(err)
	}
	m, err := parseSaveModelBytes(plain, path)
	if err != nil {
		t.Fatal(err)
	}
	if m.GameMode != "Comrades" {
		t.Fatalf("mode=%q", m.GameMode)
	}
	want := map[int]uint32{
		77: 0x01025FF7, // Stoss Spear
		78: 0x0101AA4A, // Kotetsu
		79: 0x0103248F, // Kikuichimonji
		80: 0x0105B505, // Katana
		81: 0x0105B506, // Daggers
		82: 0x01066216, // Lucian Saber
	}
	for bank, id := range want {
		r := findMasterRecord(m, "Weapons", bank)
		if r == nil || r.FixID != id {
			t.Fatalf("bank %d: got %+v, want FixID %08X", bank, r, id)
		}
	}
	if _, err := stageComradesHiddenModdedPack(m); err != nil {
		t.Fatal(err)
	}
	for bank := range want {
		if r := findMasterRecord(m, "Weapons", bank); r == nil || !r.Exists {
			t.Fatalf("bank %d was not staged as owned", bank)
		}
	}
}

func TestModPresetPreservesExistingOver99Rank(t *testing.T) {
	const path = "testdata/gameplay0_decrypted(2).save"
	plain, err := os.ReadFile(path)
	if os.IsNotExist(err) {
		t.Skip("uploaded Comrades sample not present")
	}
	if err != nil {
		t.Fatal(err)
	}
	m, err := parseSaveModelBytes(plain, path)
	if err != nil {
		t.Fatal(err)
	}
	r := findMasterRecord(m, "Weapons", 77)
	if r == nil || r.Rank != 300 {
		t.Fatalf("bank 77 rank=%v, want 300", r)
	}
	oldRecover, oldSlots, oldRemodel, oldStatus := r.RecoverMP, r.SlotCount, r.RemodelFailCount, r.StatusAdjust
	if _, err := stageComradesWeaponModPreset(m, 77); err != nil {
		t.Fatal(err)
	}
	if r.Rank != 300 {
		t.Fatalf("mod preset changed internal rank to %d", r.Rank)
	}
	if r.Strength != comradesWeaponAttackMax || r.Vitality != comradesWeaponVitalityMax || r.Critical != comradesWeaponCriticalMax {
		t.Fatalf("safe mod preset not applied: %+v", r)
	}
	if r.RecoverMP != oldRecover || r.SlotCount != oldSlots || r.RemodelFailCount != oldRemodel || r.StatusAdjust != oldStatus {
		t.Fatalf("safe mod preset changed raw/unverified fields: %+v", r)
	}
	// The writer must accept changing stats on a weapon whose original rank is
	// already above 99, as long as that unusual rank itself is preserved.
	g := GeneralEdits{ControlledCharacter: m.Party.ControlledCharacter, Chapter: m.Party.Chapter, Gil: m.Party.Gil, ArenaMedals: m.Party.ArenaMedals, OracleCoins: m.Party.OracleCoins, AbilityPoints: m.Party.AbilityPoints}
	if _, _, _, _, err := applyModelEdits(plain, m, g); err != nil {
		t.Fatalf("writer rejected preserved rank-300 weapon: %v", err)
	}
}

func TestModAllInitializedWeaponsRoundTripsOnUploadedComrades(t *testing.T) {
	const path = "testdata/gameplay0_decrypted(2).save"
	plain, err := os.ReadFile(path)
	if os.IsNotExist(err) {
		t.Skip("uploaded Comrades sample not present")
	}
	if err != nil {
		t.Fatal(err)
	}
	m, err := parseSaveModelBytes(plain, path)
	if err != nil {
		t.Fatal(err)
	}
	count, err := stageComradesAllInitializedWeaponMods(m)
	if err != nil {
		t.Fatal(err)
	}
	if count != 83 {
		t.Fatalf("modded %d initialized weapons, want 83", count)
	}
	g := GeneralEdits{
		ControlledCharacter: m.Party.ControlledCharacter,
		Chapter:             m.Party.Chapter,
		Gil:                 m.Party.Gil,
		ArenaMedals:         m.Party.ArenaMedals,
		OracleCoins:         m.Party.OracleCoins,
		AbilityPoints:       m.Party.AbilityPoints,
	}
	out, _, _, eqChanges, err := applyModelEdits(plain, m, g)
	if err != nil {
		t.Fatalf("apply MOD ALL: %v", err)
	}
	if eqChanges < 83 {
		t.Fatalf("equipment changes=%d, want at least 83", eqChanges)
	}
	r, err := parseSaveModelBytes(out, "roundtrip.decrypted.save")
	if err != nil {
		t.Fatalf("reparse edited save: %v", err)
	}
	initialized, owned := 0, 0
	for i := range r.Equipment {
		w := &r.Equipment[i]
		if w.Category != "Weapons" || w.FixID == 0 || isPlaceholderEquipment(w.FixID) {
			continue
		}
		initialized++
		if !w.Exists {
			t.Fatalf("bank %d %s is not owned after MOD ALL", w.CategoryIndex, equipmentDisplayName(w.FixID))
		}
		owned++
		if w.Strength != comradesWeaponAttackMax || w.Vitality != comradesWeaponVitalityMax || w.Critical != comradesWeaponCriticalMax {
			t.Fatalf("bank %d safe preset did not survive reparse: %+v", w.CategoryIndex, w)
		}
		if w.SlotCount < 0 || w.SlotCount > comradesWeaponSlotMax {
			t.Fatalf("bank %d slot count=%d outside serialized range", w.CategoryIndex, w.SlotCount)
		}
	}
	if initialized != 83 || owned != 83 {
		t.Fatalf("initialized=%d owned=%d, want 83/83", initialized, owned)
	}
	if w := findMasterRecord(r, "Weapons", 77); w == nil || w.Rank != 300 {
		t.Fatalf("Stoss Spear rank after MOD ALL=%v, want 300", w)
	}
	if w := findMasterRecord(r, "Weapons", 78); w == nil || w.Rank != 200 {
		t.Fatalf("Kotetsu rank after MOD ALL=%v, want 200", w)
	}
}

func TestBasicDatabaseCoverage(t *testing.T) {
	if got, want := len(itemGameLabels), 1512; got != want {
		t.Fatalf("item database rows=%d, want %d", got, want)
	}
	if got, want := len(equipmentGameLabels), 2782; got != want {
		t.Fatalf("equipment database rows=%d, want %d", got, want)
	}
	if got, want := len(abilityCatalog), 900; got != want {
		t.Fatalf("ability database rows=%d, want %d", got, want)
	}
	if got, want := len(comradesWeaponCatalog), 83; got != want {
		t.Fatalf("verified Comrades weapon masters=%d, want %d", got, want)
	}
	if got, want := len(itemGameLabels)+len(equipmentGameLabels)+len(abilityCatalog), 5194; got != want {
		t.Fatalf("combined database rows=%d, want %d", got, want)
	}
}
