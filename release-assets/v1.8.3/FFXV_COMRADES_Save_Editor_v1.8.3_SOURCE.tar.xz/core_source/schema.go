package main

import (
	"bytes"
	"crypto/sha256"
	"encoding/binary"
	"encoding/hex"
	"errors"
	"fmt"
	"math"
	"os"
	"path/filepath"
	"strings"
	"time"
)

const (
	partyHash        uint64 = 0x7CDCF11F53AD6422
	itemStructHash   uint64 = 0x3187120C912669B2
	itemDataHash     uint64 = 0x3EC820782D61A2D8
	equipmentHash    uint64 = 0x92C24A3765D8C416
	weaponHash       uint64 = 0x925FAEEDD3B196B1
	weaponEquipHash  uint64 = 0x0F60AC781A6E276C
	clothHash        uint64 = 0xEA15229308D0331B
	clothEquipHash   uint64 = 0xC3F4F62A23AA77FD
	playerHash       uint64 = 0x5D01AC46C823F725
	statusHash       uint64 = 0x99E90B318CEEE6BC
	playerStatusHash uint64 = 0x06D945D7D35C14C6

	partyElementFireIndex      = 9
	partyElementIceIndex       = 10
	partyElementLightningIndex = 11
	maxElementEnergy           = float32(99)

	maxGil = uint32(999999999)
	maxAP  = uint32(999999)
)

type SchemaField struct {
	Name     string
	TypeName string
	Offset   uint32
	Size     uint32
	Tail     [5]byte
}

type SchemaType struct {
	Name       string
	Hash       uint64
	ParentHash uint64
	Fields     []SchemaField
}

type PartyData struct {
	MarkerOffset         int
	ControlledCharacter  uint32
	Chapter              uint32
	Gil                  uint32
	ArenaMedals          uint32
	OracleCoins          uint32
	AbilityPoints        uint32
	ElementPowerOffset   int
	ElementPower         [17]float32
	OriginalElementPower [17]float32
}

type InventorySlot struct {
	MarkerOffset   int
	Category       string
	CategoryIndex  int
	GlobalIndex    int
	FixID          uint32
	Amount         int32
	OriginalFixID  uint32
	OriginalAmount int32
}

type AbilityLink struct {
	FixID      uint32
	BankNumber int32
}

type EquipmentRecord struct {
	MarkerOffset   int
	Category       string
	CategoryIndex  int
	FixID          uint32
	Type           uint32
	OriginalFixID  uint32
	OriginalType   uint32
	OriginalNameID uint32
	Exists         bool
	OriginalExists bool
	StateRaw       [4]byte
	EquipLinkRaw   [8]byte
	PayloadPreview [48]byte

	// SaveWeaponStruct weapon-instance data. The Comrades layout serializes the
	// three bools as one packed byte, so scalar fields after them are shifted by
	// three bytes from their logical schema offsets. These physical offsets are
	// validated by the embedded array counts/type markers before parsing.
	EquipmentOwner   int32
	EquipmentBank    int32
	NameID           uint32
	Rank             int32
	Strength         int32
	Vitality         int32
	Critical         int32
	RecoverMP        int32
	SlotCount        int32
	Abilities        [2]AbilityLink
	ResidentAbility  AbilityLink
	StatusAdjust     [19]int32
	RemodelFailCount int32

	OriginalEquipmentOwner   int32
	OriginalEquipmentBank    int32
	OriginalRank             int32
	OriginalStrength         int32
	OriginalVitality         int32
	OriginalCritical         int32
	OriginalRecoverMP        int32
	OriginalSlotCount        int32
	OriginalAbilities        [2]AbilityLink
	OriginalResidentAbility  AbilityLink
	OriginalStatusAdjust     [19]int32
	OriginalRemodelFailCount int32
}

type ClothRecord struct {
	MarkerOffset        int
	BankIndex           int
	FixID               uint32
	Type                uint32
	Equipment           int32
	EquipmentBankNumber int32
	NameID              uint32
	Flags               byte
	Exists              bool
}

type EquippedSlot struct {
	MarkerOffset       int
	Character          string
	SaveIndex          uint32
	Kind               string
	SlotIndex          int
	FixID              uint32
	Type               uint32
	Category           uint32
	BankNumber         uint32
	OriginalFixID      uint32
	OriginalType       uint32
	OriginalCategory   uint32
	OriginalBankNumber uint32
}

type AttireSlot struct {
	MarkerOffset       int
	Character          string
	SaveIndex          uint32
	FixID              uint32
	Type               uint32
	BankNumber         uint32
	OriginalFixID      uint32
	OriginalType       uint32
	OriginalBankNumber uint32
}

type JobCommandSlot struct {
	MarkerOffset       int
	Character          string
	SaveIndex          uint32
	FixID              uint32
	BankNumber         int32
	OriginalFixID      uint32
	OriginalBankNumber int32
}

type EquipmentPreset struct {
	Name           string
	FixID          uint32
	Type           uint32
	Category       uint32
	BankNumber     uint32
	MasterCategory string
	MasterIndex    int
}

type CharacterRecord struct {
	MarkerOffset            int
	Index                   int
	Name                    string
	ObjectEntryID           uint32
	CharacterEntryID        uint32
	DefaultCharacterEntryID uint32
}

type ComradesStatus struct {
	SaveIndex                uint32
	Name                     string
	StatusMarkerOffset       int
	PlayerStatusMarkerOffset int
	HP                       uint32
	HPMax                    uint32
	MP                       uint32
	MPMax                    uint32
	Level                    uint32
	LevelMax                 uint32
	Strength                 uint32
	Vitality                 uint32
	Magic                    uint32
	Spirit                   uint32
	Critical                 uint32
	Exp                      uint32
	ExpTotal                 uint32
	AbilityPoints            int32

	OriginalHP            uint32
	OriginalHPMax         uint32
	OriginalMP            uint32
	OriginalMPMax         uint32
	OriginalLevel         uint32
	OriginalStrength      uint32
	OriginalVitality      uint32
	OriginalMagic         uint32
	OriginalSpirit        uint32
	OriginalCritical      uint32
	OriginalExp           uint32
	OriginalExpTotal      uint32
	OriginalAbilityPoints int32
}

type ComradesChocobo struct {
	Index           int
	RecordOffset    int
	NameID          uint32
	Personality     int32
	Rarity          int32
	Color           int32
	Stamina         int32
	Jump            int32
	Speed           float32
	SkillLevel      int16
	LimitMaxLevel   int16
	MaxLevel        int16
	Level           int16
	InjuryPercent   int16
	IsNew           bool
	IsInjured       bool
	TrainingRateCnt int16

	OriginalStamina       int32
	OriginalJump          int32
	OriginalSpeed         float32
	OriginalSkillLevel    int16
	OriginalLimitMaxLevel int16
	OriginalMaxLevel      int16
	OriginalLevel         int16
	OriginalInjuryPercent int16
}

type SaveModel struct {
	Path                string
	GameMode            string
	Comrades            *ComradesStatus
	ComradesKW          *ComradesKWData
	ComradesJob         *JobCommandSlot
	ComradesAbilities   []ComradesCharacterAbility
	ComradesAbilityTree *ComradesAbilityTreeData
	ComradesChocobos    []ComradesChocobo
	SchemaOffset        int
	Types               []SchemaType
	Party               PartyData
	Inventory           []InventorySlot
	Equipment           []EquipmentRecord
	Equipped            []EquippedSlot
	Cloth               []ClothRecord
	Attire              []AttireSlot
	Characters          []CharacterRecord
	FileSize            int
	SHA256              string
}

type GeneralEdits struct {
	ControlledCharacter uint32
	Chapter             uint32
	Gil                 uint32
	ArenaMedals         uint32
	OracleCoins         uint32
	AbilityPoints       uint32
}

type EditedSaveResult struct {
	WorkspacePath    string
	OutputPath       string
	BackupPath       string
	MetadataPath     string
	MetadataCopied   bool
	MetadataWarning  string
	SHA256           string
	ChangedBytes     int
	InventoryChanges int
	EquipmentChanges int
}

var verifiedEquipmentPresets = map[string]EquipmentPreset{
	"Engine Blade":      {Name: "Engine Blade", FixID: 0x010365FD, Type: 0, Category: 0, BankNumber: 73, MasterCategory: "Weapons", MasterIndex: 73},
	"Ragnarok":          {Name: "Ragnarok", FixID: 0x0104CFD3, Type: 0, Category: 0, BankNumber: 9, MasterCategory: "Weapons", MasterIndex: 9},
	"Magitek Suit V2":   {Name: "Magitek Suit V2", FixID: 0x0103783D, Type: 48, Category: 5, BankNumber: 33, MasterCategory: "Accessories", MasterIndex: 33},
	"Tech Turbocharger": {Name: "Tech Turbocharger", FixID: 0x0104CFB6, Type: 49, Category: 5, BankNumber: 5, MasterCategory: "Accessories", MasterIndex: 5},
}

type CategoryDef struct {
	Name  string
	Count int
}

var inventoryDefs = []CategoryDef{
	{"Battle Items", 64},
	{"Event / Key Items", 256},
	{"Food / Ingredients", 256},
	{"Treasures", 256},
	{"Car / Regalia Items", 256},
	{"Leisure Items", 256},
	{"Reinforcement Items", 16},
	{"Trunk Items", 256},
}

var equipmentDefs = []CategoryDef{
	{"Weapons", 1049},
	{"Phantom Swords", 26},
	{"Accessories", 1012},
}

func schemaTypeByName(types []SchemaType, name string) *SchemaType {
	for i := range types {
		if types[i].Name == name {
			return &types[i]
		}
	}
	return nil
}

func schemaFieldByName(st *SchemaType, name string) *SchemaField {
	if st == nil {
		return nil
	}
	for i := range st.Fields {
		if st.Fields[i].Name == name {
			return &st.Fields[i]
		}
	}
	return nil
}

func schemaStructSize(st *SchemaType) int {
	if st == nil {
		return 0
	}
	max := uint32(0)
	for _, f := range st.Fields {
		if end := f.Offset + f.Size; end > max {
			max = end
		}
	}
	return int(max)
}

func inventoryLayoutFromSchema(types []SchemaType) ([]CategoryDef, error) {
	item := schemaTypeByName(types, "Black.Save.Item.SaveItemStruct")
	dataType := schemaTypeByName(types, "Black.Save.Item.SaveItemDataStruct")
	itemSize := schemaStructSize(dataType)
	if item == nil || itemSize <= 0 {
		return nil, errors.New("item schema layout is missing")
	}
	fields := []struct{ field, name string }{
		{"battle_item", "Battle Items"},
		{"event_item", "Event / Key Items"},
		{"food_item", "Food / Ingredients"},
		{"treasure_item", "Treasures"},
		{"car_item", "Car / Regalia Items"},
		{"leisure_item", "Leisure Items"},
		{"reinforcement_item", "Reinforcement Items"},
		{"trunk_item", "Trunk Items"},
	}
	out := make([]CategoryDef, 0, len(fields))
	for _, spec := range fields {
		f := schemaFieldByName(item, spec.field)
		if f == nil || int(f.Size)%itemSize != 0 {
			return nil, fmt.Errorf("invalid %s inventory schema field", spec.field)
		}
		out = append(out, CategoryDef{Name: spec.name, Count: int(f.Size) / itemSize})
	}
	return out, nil
}

func equipmentLayoutFromSchema(types []SchemaType) ([]CategoryDef, int, error) {
	eq := schemaTypeByName(types, "Black.Save.Equipment.SaveEquipmentStruct")
	weapon := schemaTypeByName(types, "Black.Save.Equipment.SaveWeaponStruct")
	cloth := schemaTypeByName(types, "Black.Save.Equipment.SaveClothStruct")
	weaponSize := schemaStructSize(weapon)
	clothSize := schemaStructSize(cloth)
	if eq == nil || weaponSize <= 0 || clothSize <= 0 {
		return nil, 0, errors.New("equipment schema layout is missing")
	}
	fields := []struct{ field, name string }{
		{"weapon", "Weapons"},
		{"phantom_sword", "Phantom Swords"},
		{"accessory", "Accessories"},
	}
	out := make([]CategoryDef, 0, len(fields))
	for _, spec := range fields {
		f := schemaFieldByName(eq, spec.field)
		if f == nil || int(f.Size)%weaponSize != 0 {
			return nil, 0, fmt.Errorf("invalid %s equipment schema field", spec.field)
		}
		out = append(out, CategoryDef{Name: spec.name, Count: int(f.Size) / weaponSize})
	}
	clothField := schemaFieldByName(eq, "cloth")
	if clothField == nil || int(clothField.Size)%clothSize != 0 {
		return nil, 0, errors.New("invalid cloth equipment schema field")
	}
	return out, int(clothField.Size) / clothSize, nil
}

func schemaReadU16(data []byte, pos *int, limit int) (uint16, error) {
	if *pos < 0 || *pos+2 > limit {
		return 0, errors.New("schema truncated while reading uint16")
	}
	v := binary.LittleEndian.Uint16(data[*pos : *pos+2])
	*pos += 2
	return v, nil
}
func schemaReadU32(data []byte, pos *int, limit int) (uint32, error) {
	if *pos < 0 || *pos+4 > limit {
		return 0, errors.New("schema truncated while reading uint32")
	}
	v := binary.LittleEndian.Uint32(data[*pos : *pos+4])
	*pos += 4
	return v, nil
}
func schemaReadU64(data []byte, pos *int, limit int) (uint64, error) {
	if *pos < 0 || *pos+8 > limit {
		return 0, errors.New("schema truncated while reading uint64")
	}
	v := binary.LittleEndian.Uint64(data[*pos : *pos+8])
	*pos += 8
	return v, nil
}
func schemaReadString(data []byte, pos *int, limit int) (string, error) {
	n, err := schemaReadU32(data, pos, limit)
	if err != nil {
		return "", err
	}
	if n > 1<<20 || *pos+int(n) > limit {
		return "", errors.New("schema contains invalid string length")
	}
	s := string(data[*pos : *pos+int(n)])
	*pos += int(n)
	return s, nil
}

func parseSchema(data []byte) (int, []SchemaType, error) {
	if len(data) < 16 {
		return 0, nil, errors.New("save header is too small")
	}
	schemaOffset := int(binary.LittleEndian.Uint32(data[12:16]))
	if schemaOffset < 16 || schemaOffset+4 > len(data) {
		return 0, nil, fmt.Errorf("invalid schema offset 0x%X", schemaOffset)
	}
	pos := schemaOffset
	countU, err := schemaReadU32(data, &pos, len(data))
	if err != nil {
		return 0, nil, err
	}
	if countU == 0 || countU > 4096 {
		return 0, nil, fmt.Errorf("unreasonable schema type count %d", countU)
	}
	out := make([]SchemaType, 0, countU)
	for i := uint32(0); i < countU; i++ {
		name, err := schemaReadString(data, &pos, len(data))
		if err != nil {
			return 0, nil, fmt.Errorf("type %d name: %w", i, err)
		}
		h, err := schemaReadU64(data, &pos, len(data))
		if err != nil {
			return 0, nil, err
		}
		parent, err := schemaReadU64(data, &pos, len(data))
		if err != nil {
			return 0, nil, err
		}
		fc, err := schemaReadU16(data, &pos, len(data))
		if err != nil {
			return 0, nil, err
		}
		if fc > 4096 {
			return 0, nil, fmt.Errorf("type %q has unreasonable field count %d", name, fc)
		}
		st := SchemaType{Name: name, Hash: h, ParentHash: parent, Fields: make([]SchemaField, 0, fc)}
		for j := uint16(0); j < fc; j++ {
			fn, err := schemaReadString(data, &pos, len(data))
			if err != nil {
				return 0, nil, err
			}
			tn, err := schemaReadString(data, &pos, len(data))
			if err != nil {
				return 0, nil, err
			}
			off, err := schemaReadU32(data, &pos, len(data))
			if err != nil {
				return 0, nil, err
			}
			sz, err := schemaReadU32(data, &pos, len(data))
			if err != nil {
				return 0, nil, err
			}
			if pos+5 > len(data) {
				return 0, nil, errors.New("schema truncated at field tail")
			}
			var tail [5]byte
			copy(tail[:], data[pos:pos+5])
			pos += 5
			st.Fields = append(st.Fields, SchemaField{Name: fn, TypeName: tn, Offset: off, Size: sz, Tail: tail})
		}
		out = append(out, st)
	}
	return schemaOffset, out, nil
}

func findMarkers(data []byte, hash uint64, end int) []int {
	if end <= 0 || end > len(data) {
		end = len(data)
	}
	var sig [8]byte
	binary.LittleEndian.PutUint64(sig[:], hash)
	result := make([]int, 0)
	from := 0
	for from+8 <= end {
		rel := bytes.Index(data[from:end], sig[:])
		if rel < 0 {
			break
		}
		at := from + rel
		result = append(result, at)
		from = at + 1
	}
	return result
}

func parsePartyElementPower(data []byte, base, schemaOffset int) (int, [17]float32, error) {
	var values [17]float32
	pos := base + 24 // six direct scalar fields already parsed
	if pos+4 > schemaOffset {
		return 0, values, errors.New("party reward-count array is truncated")
	}
	rewardCount := int(binary.LittleEndian.Uint32(data[pos : pos+4]))
	if rewardCount < 0 || rewardCount > 256 {
		return 0, values, fmt.Errorf("invalid party reward-count array length %d", rewardCount)
	}
	pos += 4 + rewardCount*4
	if pos+4 > schemaOffset {
		return 0, values, errors.New("party clear-count array is truncated")
	}
	clearCount := int(binary.LittleEndian.Uint32(data[pos : pos+4]))
	if clearCount < 0 || clearCount > 64 {
		return 0, values, fmt.Errorf("invalid party clear-count array length %d", clearCount)
	}
	pos += 4 + clearCount*4
	// newgame_plus / premium_camera_status / premium_camera_equipment are three
	// booleans packed into one serialized byte.
	if pos+1+4 > schemaOffset {
		return 0, values, errors.New("party element-power header is truncated")
	}
	pos++
	elementCount := int(binary.LittleEndian.Uint32(data[pos : pos+4]))
	pos += 4
	if elementCount != len(values) || pos+elementCount*4 > schemaOffset {
		return 0, values, fmt.Errorf("expected %d party element-power entries, found %d", len(values), elementCount)
	}
	for i := range values {
		values[i] = math.Float32frombits(binary.LittleEndian.Uint32(data[pos+i*4 : pos+i*4+4]))
	}
	return pos, values, nil
}

func parseParty(data []byte, schemaOffset int) (PartyData, error) {
	markers := findMarkers(data, partyHash, schemaOffset)
	var candidates []PartyData
	for _, at := range markers {
		base := at + 8
		if base+24 > schemaOffset {
			continue
		}
		p := PartyData{
			MarkerOffset:        at,
			ControlledCharacter: binary.LittleEndian.Uint32(data[base : base+4]),
			Chapter:             binary.LittleEndian.Uint32(data[base+4 : base+8]),
			Gil:                 binary.LittleEndian.Uint32(data[base+8 : base+12]),
			ArenaMedals:         binary.LittleEndian.Uint32(data[base+12 : base+16]),
			OracleCoins:         binary.LittleEndian.Uint32(data[base+16 : base+20]),
			AbilityPoints:       binary.LittleEndian.Uint32(data[base+20 : base+24]),
		}
		if p.ControlledCharacter <= 31 && p.Chapter <= 99 {
			elementOffset, elements, elementErr := parsePartyElementPower(data, base, schemaOffset)
			if elementErr != nil {
				continue
			}
			p.ElementPowerOffset = elementOffset
			p.ElementPower = elements
			p.OriginalElementPower = elements
			candidates = append(candidates, p)
		}
	}
	if len(candidates) != 1 {
		return PartyData{}, fmt.Errorf("expected one live SavePartyDataStruct, found %d", len(candidates))
	}
	return candidates[0], nil
}

func parseInventory(data []byte, schemaOffset int, types []SchemaType) ([]InventorySlot, error) {
	defs, err := inventoryLayoutFromSchema(types)
	if err != nil {
		return nil, err
	}
	markers := findMarkers(data, itemDataHash, schemaOffset)
	total := 0
	for _, d := range defs {
		total += d.Count
	}
	if len(markers) != total {
		return nil, fmt.Errorf("expected %d SaveItemDataStruct slots from schema, found %d", total, len(markers))
	}
	out := make([]InventorySlot, 0, total)
	global := 0
	markerIndex := 0
	for _, def := range defs {
		for i := 0; i < def.Count; i++ {
			at := markers[markerIndex]
			markerIndex++
			base := at + 8
			if base+8 > schemaOffset {
				return nil, errors.New("inventory slot crosses schema boundary")
			}
			amount := int32(binary.LittleEndian.Uint32(data[base+4 : base+8]))
			fixID := binary.LittleEndian.Uint32(data[base : base+4])
			out = append(out, InventorySlot{MarkerOffset: at, Category: def.Name, CategoryIndex: i, GlobalIndex: global, FixID: fixID, Amount: amount, OriginalFixID: fixID, OriginalAmount: amount})
			global++
		}
	}
	return out, nil
}

func parseEquipment(data []byte, schemaOffset int, types []SchemaType) ([]EquipmentRecord, error) {
	defs, _, err := equipmentLayoutFromSchema(types)
	if err != nil {
		return nil, err
	}
	markers := findMarkers(data, weaponHash, schemaOffset)
	total := 0
	for _, d := range defs {
		total += d.Count
	}
	if len(markers) != total {
		return nil, fmt.Errorf("expected %d SaveWeaponStruct records from schema, found %d", total, len(markers))
	}
	abilityType := schemaTypeByName(types, "Black.Save.Ability.SaveAbilityEquipmentStruct")
	if abilityType == nil {
		return nil, errors.New("SaveAbilityEquipmentStruct schema type is missing")
	}
	abilityHash := abilityType.Hash
	var abilityMarker [8]byte
	binary.LittleEndian.PutUint64(abilityMarker[:], abilityHash)

	out := make([]EquipmentRecord, 0, total)
	mi := 0
	for _, def := range defs {
		for i := 0; i < def.Count; i++ {
			at := markers[mi]
			mi++
			base := at + 8
			// Physical serialized payload is 185 bytes for this schema: packed bools,
			// scalar fields, 2 ability structs, 1 resident ability, 19 status values.
			if base+185 > schemaOffset {
				return nil, errors.New("equipment record crosses schema boundary")
			}
			if binary.LittleEndian.Uint32(data[base+45:base+49]) != 2 ||
				!bytes.Equal(data[base+49:base+57], abilityMarker[:]) ||
				!bytes.Equal(data[base+65:base+73], abilityMarker[:]) ||
				binary.LittleEndian.Uint32(data[base+81:base+85]) != 1 ||
				!bytes.Equal(data[base+85:base+93], abilityMarker[:]) ||
				binary.LittleEndian.Uint32(data[base+101:base+105]) != 19 {
				return nil, fmt.Errorf("equipment record %d has an unexpected packed SaveWeaponStruct layout", mi-1)
			}
			var state [4]byte
			copy(state[:], data[base+4:base+8])
			var link [8]byte
			copy(link[:], data[base+5:base+13])
			var preview [48]byte
			copy(preview[:], data[base:base+48])
			typ := binary.LittleEndian.Uint32(data[base+17 : base+21])
			exists := data[base+4]&0x02 != 0
			r := EquipmentRecord{
				MarkerOffset: at, Category: def.Name, CategoryIndex: i,
				FixID: binary.LittleEndian.Uint32(data[base : base+4]), Type: typ,
				Exists: exists, OriginalExists: exists, StateRaw: state, EquipLinkRaw: link, PayloadPreview: preview,
				EquipmentOwner: int32(binary.LittleEndian.Uint32(data[base+5 : base+9])),
				EquipmentBank:  int32(binary.LittleEndian.Uint32(data[base+9 : base+13])),
				NameID:         binary.LittleEndian.Uint32(data[base+13 : base+17]),
				Rank:           int32(binary.LittleEndian.Uint32(data[base+21 : base+25])),
				Strength:       int32(binary.LittleEndian.Uint32(data[base+25 : base+29])),
				Vitality:       int32(binary.LittleEndian.Uint32(data[base+29 : base+33])),
				Critical:       int32(binary.LittleEndian.Uint32(data[base+33 : base+37])),
				RecoverMP:      int32(binary.LittleEndian.Uint32(data[base+37 : base+41])),
				SlotCount:      int32(binary.LittleEndian.Uint32(data[base+41 : base+45])),
				Abilities: [2]AbilityLink{
					{FixID: binary.LittleEndian.Uint32(data[base+57 : base+61]), BankNumber: int32(binary.LittleEndian.Uint32(data[base+61 : base+65]))},
					{FixID: binary.LittleEndian.Uint32(data[base+73 : base+77]), BankNumber: int32(binary.LittleEndian.Uint32(data[base+77 : base+81]))},
				},
				ResidentAbility:  AbilityLink{FixID: binary.LittleEndian.Uint32(data[base+93 : base+97]), BankNumber: int32(binary.LittleEndian.Uint32(data[base+97 : base+101]))},
				RemodelFailCount: int32(binary.LittleEndian.Uint32(data[base+181 : base+185])),
			}
			for n := 0; n < 19; n++ {
				r.StatusAdjust[n] = int32(binary.LittleEndian.Uint32(data[base+105+n*4 : base+109+n*4]))
			}
			r.OriginalFixID = r.FixID
			r.OriginalType = r.Type
			r.OriginalNameID = r.NameID
			r.OriginalEquipmentOwner = r.EquipmentOwner
			r.OriginalEquipmentBank = r.EquipmentBank
			r.OriginalRank = r.Rank
			r.OriginalStrength = r.Strength
			r.OriginalVitality = r.Vitality
			r.OriginalCritical = r.Critical
			r.OriginalRecoverMP = r.RecoverMP
			r.OriginalSlotCount = r.SlotCount
			r.OriginalAbilities = r.Abilities
			r.OriginalResidentAbility = r.ResidentAbility
			r.OriginalStatusAdjust = r.StatusAdjust
			r.OriginalRemodelFailCount = r.RemodelFailCount
			out = append(out, r)
		}
	}
	return out, nil
}

func parseEquipped(data []byte, schemaOffset int, chars []CharacterRecord) ([]EquippedSlot, error) {
	out := make([]EquippedSlot, 0, len(chars)*7)
	for _, c := range chars {
		end := c.MarkerOffset + 0x1000
		if end > schemaOffset {
			end = schemaOffset
		}
		markers := findMarkers(data[c.MarkerOffset:end], weaponEquipHash, end-c.MarkerOffset)
		if len(markers) != 7 {
			return nil, fmt.Errorf("%s: expected 7 equipped-slot records near player structure, found %d", c.Name, len(markers))
		}
		for i, rel := range markers {
			at := c.MarkerOffset + rel
			base := at + 8
			if base+16 > schemaOffset {
				return nil, errors.New("equipped-slot record crosses schema boundary")
			}
			kind := "Weapon"
			slotIndex := i + 1
			if i >= 4 {
				kind = "Accessory"
				slotIndex = i - 3
			}
			id := binary.LittleEndian.Uint32(data[base : base+4])
			typ := binary.LittleEndian.Uint32(data[base+4 : base+8])
			cat := binary.LittleEndian.Uint32(data[base+8 : base+12])
			bank := binary.LittleEndian.Uint32(data[base+12 : base+16])
			out = append(out, EquippedSlot{MarkerOffset: at, Character: c.Name, SaveIndex: uint32(c.Index), Kind: kind, SlotIndex: slotIndex, FixID: id, Type: typ, Category: cat, BankNumber: bank, OriginalFixID: id, OriginalType: typ, OriginalCategory: cat, OriginalBankNumber: bank})
		}
	}
	return out, nil
}

func parseCloth(data []byte, schemaOffset int, types []SchemaType) ([]ClothRecord, error) {
	_, expected, err := equipmentLayoutFromSchema(types)
	if err != nil {
		return nil, err
	}
	markers := findMarkers(data, clothHash, schemaOffset)
	if len(markers) != expected {
		return nil, fmt.Errorf("expected %d SaveClothStruct records from schema, found %d", expected, len(markers))
	}
	out := make([]ClothRecord, 0, expected)
	for i, at := range markers {
		base := at + 8
		if base+24 > schemaOffset {
			return nil, errors.New("cloth record crosses schema boundary")
		}
		flags := data[base+20]
		out = append(out, ClothRecord{
			MarkerOffset: at, BankIndex: i,
			FixID:               binary.LittleEndian.Uint32(data[base : base+4]),
			Type:                binary.LittleEndian.Uint32(data[base+4 : base+8]),
			Equipment:           int32(binary.LittleEndian.Uint32(data[base+8 : base+12])),
			EquipmentBankNumber: int32(binary.LittleEndian.Uint32(data[base+12 : base+16])),
			NameID:              binary.LittleEndian.Uint32(data[base+16 : base+20]), Flags: flags, Exists: flags&0x01 != 0,
		})
	}
	return out, nil
}

func parseAttire(data []byte, schemaOffset int, chars []CharacterRecord) ([]AttireSlot, error) {
	out := make([]AttireSlot, 0, len(chars))
	for _, c := range chars {
		end := c.MarkerOffset + 0x1000
		if end > schemaOffset {
			end = schemaOffset
		}
		markers := findMarkers(data[c.MarkerOffset:end], clothEquipHash, end-c.MarkerOffset)
		if len(markers) != 1 {
			return nil, fmt.Errorf("%s: expected 1 attire equipment record near player structure, found %d", c.Name, len(markers))
		}
		at := c.MarkerOffset + markers[0]
		base := at + 8
		if base+12 > schemaOffset {
			return nil, errors.New("attire equipment record crosses schema boundary")
		}
		id := binary.LittleEndian.Uint32(data[base : base+4])
		typ := binary.LittleEndian.Uint32(data[base+4 : base+8])
		bank := binary.LittleEndian.Uint32(data[base+8 : base+12])
		out = append(out, AttireSlot{MarkerOffset: at, Character: c.Name, SaveIndex: uint32(c.Index), FixID: id, Type: typ, BankNumber: bank, OriginalFixID: id, OriginalType: typ, OriginalBankNumber: bank})
	}
	return out, nil
}

func parseCharacters(data []byte, schemaOffset int) []CharacterRecord {
	markers := findMarkers(data, playerHash, schemaOffset)
	out := make([]CharacterRecord, 0, 4)
	for i, at := range markers {
		if len(out) >= 4 {
			break
		}
		base := at + 8
		if base+16+128 > schemaOffset {
			continue
		}
		rawName := data[base+16 : base+16+128]
		if z := bytes.IndexByte(rawName, 0); z >= 0 {
			rawName = rawName[:z]
		}
		name := strings.TrimSpace(string(rawName))
		if name == "" {
			continue
		}
		// Keep the four permanent party members only; guests/DLC records follow.
		switch name {
		case "Noctis", "Gladiolus", "Ignis", "Prompto":
		default:
			continue
		}
		out = append(out, CharacterRecord{MarkerOffset: at, Index: i, Name: name, ObjectEntryID: binary.LittleEndian.Uint32(data[base : base+4]), CharacterEntryID: binary.LittleEndian.Uint32(data[base+4 : base+8]), DefaultCharacterEntryID: binary.LittleEndian.Uint32(data[base+8 : base+12])})
	}
	return out
}

func isComradesGameplay(data []byte, schemaOffset int, types []SchemaType) bool {
	limit := schemaOffset
	if limit > 1024*1024 {
		limit = 1024 * 1024
	}
	if limit > len(data) {
		limit = len(data)
	}
	return (limit > 0 && bytes.Contains(data[:limit], []byte("level/DLC/multi/"))) || (len(types) == 95 && schemaTypeByName(types, "Black.Save.Multiplay.SavePlantMapDataStruct") != nil)
}

func parseComradesStatus(data []byte, schemaOffset int, saveIndex uint32) (*ComradesStatus, error) {
	players := findMarkers(data, playerHash, schemaOffset)
	statuses := findMarkers(data, statusHash, schemaOffset)
	playerStatuses := findMarkers(data, playerStatusHash, schemaOffset)
	idx := int(saveIndex)
	if idx < 0 || idx >= len(players) || idx >= len(statuses) || idx >= len(playerStatuses) {
		return nil, fmt.Errorf("Comrades avatar save index %d is outside detected player arrays", saveIndex)
	}
	pb := players[idx] + 8
	if pb+16+128 > schemaOffset {
		return nil, errors.New("Comrades player record is truncated")
	}
	rawName := data[pb+16 : pb+16+128]
	if z := bytes.IndexByte(rawName, 0); z >= 0 {
		rawName = rawName[:z]
	}
	name := strings.TrimSpace(string(rawName))

	// SaveStatusStruct is serialized densely: consecutive bools are bit-packed
	// into one byte. These offsets are derived from the supplied 95-type
	// Comrades schema and independently match the duplicate status in avatar0.
	sb := statuses[idx] + 8
	psb := playerStatuses[idx] + 8
	if sb+167 > schemaOffset || psb+12 > schemaOffset {
		return nil, errors.New("Comrades status record is truncated")
	}
	read := func(off int) uint32 { return binary.LittleEndian.Uint32(data[sb+off : sb+off+4]) }
	c := &ComradesStatus{
		SaveIndex: saveIndex, Name: name, StatusMarkerOffset: statuses[idx], PlayerStatusMarkerOffset: playerStatuses[idx],
		HP: read(27), HPMax: read(31), MP: read(111), MPMax: read(115),
		Level: read(135), LevelMax: read(143), Strength: read(147), Vitality: read(151),
		Magic: read(155), Spirit: read(159), Critical: read(163),
		Exp:           binary.LittleEndian.Uint32(data[psb : psb+4]),
		ExpTotal:      binary.LittleEndian.Uint32(data[psb+4 : psb+8]),
		AbilityPoints: int32(binary.LittleEndian.Uint32(data[psb+8 : psb+12])),
	}
	c.OriginalHP, c.OriginalHPMax = c.HP, c.HPMax
	c.OriginalMP, c.OriginalMPMax = c.MP, c.MPMax
	c.OriginalLevel = c.Level
	c.OriginalStrength, c.OriginalVitality, c.OriginalMagic, c.OriginalSpirit, c.OriginalCritical = c.Strength, c.Vitality, c.Magic, c.Spirit, c.Critical
	c.OriginalExp, c.OriginalExpTotal, c.OriginalAbilityPoints = c.Exp, c.ExpTotal, c.AbilityPoints
	return c, nil
}

func parseComradesChocobos(data []byte, schemaOffset int, types []SchemaType) ([]ComradesChocobo, error) {
	parent := schemaTypeByName(types, "Black.Save.Multiplay.SaveChocoboDataStruct")
	child := schemaTypeByName(types, "Black.Save.Multiplay.SaveChocoboDataStruct.ChocoboDataStruct")
	if parent == nil || child == nil {
		return nil, errors.New("Comrades chocobo schema types were not found")
	}
	parents := findMarkers(data, parent.Hash, schemaOffset)
	if len(parents) != 1 {
		return nil, fmt.Errorf("expected one Comrades chocobo container, found %d", len(parents))
	}
	base := parents[0] + 8
	if base+4 > schemaOffset {
		return nil, errors.New("Comrades chocobo container is truncated")
	}
	count := int(binary.LittleEndian.Uint32(data[base : base+4]))
	allChildren := findMarkers(data, child.Hash, schemaOffset)
	children := make([]int, 0, len(allChildren))
	for _, marker := range allChildren {
		if marker > parents[0] && marker < schemaOffset {
			children = append(children, marker)
		}
	}
	if count < 0 || count > len(children) {
		return nil, fmt.Errorf("Comrades chocobo count %d exceeds serialized record capacity %d", count, len(children))
	}
	out := make([]ComradesChocobo, 0, count)
	for i := 0; i < count; i++ {
		rb := children[i] + 8
		// ChocoboDataStruct contains three fixed-size arrays. Each array is
		// serialized with a 4-byte element count before its elements, so scalar
		// fields after specialTrainingNum_ are physically shifted by +0x0C from
		// their logical schema offsets. Consecutive isNew_/isInjured_ bools are
		// bit-packed into one byte at +0x52. The final trainingRateCnt_ int16
		// occupies +0x61..+0x62, so the physical record is 0x63 bytes.
		if rb+0x63 > schemaOffset || rb+0x63 > len(data) {
			return nil, fmt.Errorf("Comrades chocobo record %d is truncated", i)
		}
		readI32 := func(off int) int32 { return int32(binary.LittleEndian.Uint32(data[rb+off : rb+off+4])) }
		readI16 := func(off int) int16 { return int16(binary.LittleEndian.Uint16(data[rb+off : rb+off+2])) }
		c := ComradesChocobo{
			Index: i, RecordOffset: rb,
			NameID:      binary.LittleEndian.Uint32(data[rb : rb+4]),
			Personality: readI32(0x04), Rarity: readI32(0x08), Color: readI32(0x0C),
			Stamina: readI32(0x10), Jump: readI32(0x14), Speed: math.Float32frombits(binary.LittleEndian.Uint32(data[rb+0x18 : rb+0x1C])),
			SkillLevel: readI16(0x48), LimitMaxLevel: readI16(0x4A), MaxLevel: readI16(0x4C), Level: readI16(0x4E),
			InjuryPercent: readI16(0x50), IsNew: data[rb+0x52]&0x01 != 0, IsInjured: data[rb+0x52]&0x02 != 0,
			TrainingRateCnt: readI16(0x61),
		}
		c.OriginalStamina, c.OriginalJump, c.OriginalSpeed = c.Stamina, c.Jump, c.Speed
		c.OriginalSkillLevel, c.OriginalLimitMaxLevel, c.OriginalMaxLevel = c.SkillLevel, c.LimitMaxLevel, c.MaxLevel
		c.OriginalLevel, c.OriginalInjuryPercent = c.Level, c.InjuryPercent
		out = append(out, c)
	}
	return out, nil
}

func stageComradesChocobo(model *SaveModel, index int, level, maxLevel, limitMaxLevel, skillLevel int16, stamina, jump int32, speed float32, injuryPercent int16) error {
	if model == nil || model.GameMode != "Comrades" {
		return errors.New("load a Comrades gameplay0 save first")
	}
	if index < 0 || index >= len(model.ComradesChocobos) {
		return fmt.Errorf("chocobo index %d was not found", index)
	}
	if level < 1 || level > 999 || maxLevel < 1 || maxLevel > 999 || limitMaxLevel < 1 || limitMaxLevel > 999 {
		return errors.New("chocobo levels must be 1 through 999")
	}
	if level > maxLevel {
		return errors.New("chocobo current level cannot exceed level cap")
	}
	if maxLevel > limitMaxLevel {
		return errors.New("chocobo level cap cannot exceed limit max level")
	}
	if skillLevel < 0 || skillLevel > 999 {
		return errors.New("chocobo skill level must be 0 through 999")
	}
	if stamina < 0 || stamina > 9999 || jump < 0 || jump > 9999 {
		return errors.New("chocobo stamina and jump must be 0 through 9,999")
	}
	if math.IsNaN(float64(speed)) || math.IsInf(float64(speed), 0) || speed < 0 || speed > 999.9 {
		return errors.New("chocobo top speed must be between 0 and 999.9")
	}
	if injuryPercent < 0 || injuryPercent > 100 {
		return errors.New("chocobo injury percent must be 0 through 100")
	}
	c := &model.ComradesChocobos[index]
	c.Level, c.MaxLevel, c.LimitMaxLevel, c.SkillLevel = level, maxLevel, limitMaxLevel, skillLevel
	c.Stamina, c.Jump, c.Speed, c.InjuryPercent = stamina, jump, speed, injuryPercent
	return nil
}

func parseComradesGlaiveLoadout(data []byte, schemaOffset int, types []SchemaType, status *ComradesStatus) ([]EquippedSlot, *JobCommandSlot, *AttireSlot, error) {
	if status == nil {
		return nil, nil, nil, errors.New("Comrades status is required to locate the active Glaive loadout")
	}
	players := findMarkers(data, playerHash, schemaOffset)
	idx := int(status.SaveIndex)
	if idx < 0 || idx >= len(players) {
		return nil, nil, nil, fmt.Errorf("Comrades avatar save index %d is outside detected player records", status.SaveIndex)
	}
	at := players[idx]
	end := at + 0x1000
	if end > schemaOffset {
		end = schemaOffset
	}
	weaponMarkers := findMarkers(data[at:end], weaponEquipHash, end-at)
	if len(weaponMarkers) != 7 {
		return nil, nil, nil, fmt.Errorf("active Glaive: expected 7 equipment slots, found %d", len(weaponMarkers))
	}
	name := strings.TrimSpace(status.Name)
	if name == "" {
		name = "Glaive"
	}
	slots := make([]EquippedSlot, 0, 7)
	for i, rel := range weaponMarkers {
		pos := at + rel
		base := pos + 8
		if base+16 > schemaOffset {
			return nil, nil, nil, errors.New("active Glaive equipment slot crosses schema boundary")
		}
		kind := "Weapon"
		slotIndex := i + 1
		if i >= 4 {
			kind = "Accessory"
			slotIndex = i - 3
		}
		id := binary.LittleEndian.Uint32(data[base : base+4])
		typ := binary.LittleEndian.Uint32(data[base+4 : base+8])
		cat := binary.LittleEndian.Uint32(data[base+8 : base+12])
		bank := binary.LittleEndian.Uint32(data[base+12 : base+16])
		slots = append(slots, EquippedSlot{MarkerOffset: pos, Character: name, SaveIndex: status.SaveIndex, Kind: kind, SlotIndex: slotIndex, FixID: id, Type: typ, Category: cat, BankNumber: bank, OriginalFixID: id, OriginalType: typ, OriginalCategory: cat, OriginalBankNumber: bank})
	}
	jobType := schemaTypeByName(types, "Black.Save.Ability.SaveJobCommandEquipmentStruct")
	if jobType == nil {
		return nil, nil, nil, errors.New("Comrades job-command equipment schema is missing")
	}
	jobMarkers := findMarkers(data[at:end], jobType.Hash, end-at)
	if len(jobMarkers) != 1 {
		return nil, nil, nil, fmt.Errorf("active Glaive: expected 1 job-command equipment record, found %d", len(jobMarkers))
	}
	jb := at + jobMarkers[0] + 8
	if jb+8 > schemaOffset {
		return nil, nil, nil, errors.New("active Glaive job-command record crosses schema boundary")
	}
	jobID := binary.LittleEndian.Uint32(data[jb : jb+4])
	jobBank := int32(binary.LittleEndian.Uint32(data[jb+4 : jb+8]))
	job := &JobCommandSlot{MarkerOffset: at + jobMarkers[0], Character: name, SaveIndex: status.SaveIndex, FixID: jobID, BankNumber: jobBank, OriginalFixID: jobID, OriginalBankNumber: jobBank}

	clothMarkers := findMarkers(data[at:end], clothEquipHash, end-at)
	if len(clothMarkers) != 1 {
		return nil, nil, nil, fmt.Errorf("active Glaive: expected 1 clothing equipment record, found %d", len(clothMarkers))
	}
	cb := at + clothMarkers[0] + 8
	if cb+12 > schemaOffset {
		return nil, nil, nil, errors.New("active Glaive clothing record crosses schema boundary")
	}
	clothID := binary.LittleEndian.Uint32(data[cb : cb+4])
	clothType := binary.LittleEndian.Uint32(data[cb+4 : cb+8])
	clothBank := binary.LittleEndian.Uint32(data[cb+8 : cb+12])
	cloth := &AttireSlot{MarkerOffset: at + clothMarkers[0], Character: name, SaveIndex: status.SaveIndex, FixID: clothID, Type: clothType, BankNumber: clothBank, OriginalFixID: clothID, OriginalType: clothType, OriginalBankNumber: clothBank}
	return slots, job, cloth, nil
}

func parseSaveModelBytes(data []byte, path string) (*SaveModel, error) {
	if err := validateGameplayPlain(data); err != nil {
		return nil, fmt.Errorf("not a supported decrypted gameplay0 save: %w", err)
	}
	schemaOffset, types, err := parseSchema(data)
	if err != nil {
		return nil, err
	}
	// Confirm the expected schema identities are present before editing.
	required := map[uint64]bool{partyHash: false, itemDataHash: false, equipmentHash: false, weaponHash: false, weaponEquipHash: false, clothHash: false, clothEquipHash: false, playerHash: false}
	for _, t := range types {
		if _, ok := required[t.Hash]; ok {
			required[t.Hash] = true
		}
	}
	for h, ok := range required {
		if !ok {
			return nil, fmt.Errorf("required schema type 0x%016X is missing", h)
		}
	}
	if schemaTypeByName(types, "Black.Save.Item.SaveItemStruct") == nil {
		return nil, errors.New("required SaveItemStruct schema type is missing")
	}
	comradesMode := isComradesGameplay(data, schemaOffset, types)
	party, err := parseParty(data, schemaOffset)
	if err != nil {
		return nil, err
	}
	inv, err := parseInventory(data, schemaOffset, types)
	if err != nil {
		return nil, err
	}
	eq, err := parseEquipment(data, schemaOffset, types)
	if err != nil {
		return nil, err
	}
	cloth, err := parseCloth(data, schemaOffset, types)
	if err != nil {
		return nil, err
	}
	chars := parseCharacters(data, schemaOffset)
	equipped, err := parseEquipped(data, schemaOffset, chars)
	if err != nil {
		return nil, err
	}
	attire, err := parseAttire(data, schemaOffset, chars)
	if err != nil {
		return nil, err
	}
	mode := "Main Game"
	var comrades *ComradesStatus
	var comradesKW *ComradesKWData
	var comradesJob *JobCommandSlot
	var comradesAbilities []ComradesCharacterAbility
	var comradesAbilityTree *ComradesAbilityTreeData
	var comradesChocobos []ComradesChocobo
	if comradesMode {
		mode = "Comrades"
		comrades, _ = parseComradesStatus(data, schemaOffset, party.ControlledCharacter)
		comradesKW, _ = parseComradesKW(data, schemaOffset, types)
		if comrades != nil {
			glaiveSlots, job, glaiveCloth, loadoutErr := parseComradesGlaiveLoadout(data, schemaOffset, types, comrades)
			if loadoutErr != nil {
				return nil, loadoutErr
			}
			equipped = append(equipped, glaiveSlots...)
			attire = append(attire, *glaiveCloth)
			comradesJob = job
			comradesAbilities, loadoutErr = parseComradesCharacterAbilities(data, schemaOffset, types, comrades)
			if loadoutErr != nil {
				return nil, loadoutErr
			}
		}
		comradesAbilityTree, _ = parseComradesAbilityTree(data, schemaOffset, types)
		comradesChocobos, _ = parseComradesChocobos(data, schemaOffset, types)
	}
	sum := sha256.Sum256(data)
	return &SaveModel{Path: path, GameMode: mode, Comrades: comrades, ComradesKW: comradesKW, ComradesJob: comradesJob, ComradesAbilities: comradesAbilities, ComradesAbilityTree: comradesAbilityTree, ComradesChocobos: comradesChocobos, SchemaOffset: schemaOffset, Types: types, Party: party, Inventory: inv, Equipment: eq, Equipped: equipped, Cloth: cloth, Attire: attire, Characters: chars, FileSize: len(data), SHA256: hex.EncodeToString(sum[:])}, nil
}

func loadSaveModel(path string) (*SaveModel, []byte, string, error) {
	data, cleaned, err := readRegularFile(path)
	if err != nil {
		return nil, nil, cleaned, err
	}
	model, err := parseSaveModelBytes(data, cleaned)
	if err != nil {
		return nil, nil, cleaned, err
	}
	return model, data, cleaned, nil
}

func inventoryByCategory(model *SaveModel, category string) []*InventorySlot {
	out := make([]*InventorySlot, 0)
	for i := range model.Inventory {
		if model.Inventory[i].Category == category {
			out = append(out, &model.Inventory[i])
		}
	}
	return out
}

func equipmentByCategory(model *SaveModel, category string, ownedOnly bool) []*EquipmentRecord {
	out := make([]*EquipmentRecord, 0)
	for i := range model.Equipment {
		r := &model.Equipment[i]
		if r.Category != category {
			continue
		}
		if ownedOnly && !r.Exists {
			continue
		}
		out = append(out, r)
	}
	return out
}

func equippedSlot(model *SaveModel, character, kind string, slotIndex int) *EquippedSlot {
	for i := range model.Equipped {
		s := &model.Equipped[i]
		if s.Character == character && s.Kind == kind && s.SlotIndex == slotIndex {
			return s
		}
	}
	return nil
}

func equippedSlotBySaveIndex(model *SaveModel, saveIndex uint32, kind string, slotIndex int) *EquippedSlot {
	if model == nil {
		return nil
	}
	for i := range model.Equipped {
		s := &model.Equipped[i]
		if s.SaveIndex == saveIndex && s.Kind == kind && s.SlotIndex == slotIndex {
			return s
		}
	}
	return nil
}

func characterSaveIndex(character string) (uint32, bool) {
	switch character {
	case "Noctis":
		return 0, true
	case "Gladiolus":
		return 1, true
	case "Ignis":
		return 2, true
	case "Prompto":
		return 3, true
	default:
		return 0, false
	}
}

func attireSlot(model *SaveModel, character string) *AttireSlot {
	for i := range model.Attire {
		if model.Attire[i].Character == character {
			return &model.Attire[i]
		}
	}
	return nil
}

func findClothRecord(model *SaveModel, bank int) *ClothRecord {
	if bank < 0 || bank >= len(model.Cloth) {
		return nil
	}
	r := &model.Cloth[bank]
	if r.BankIndex != bank {
		return nil
	}
	return r
}

func masterCategoryForTuple(kind string, category uint32) string {
	if kind == "Accessory" || category == 5 {
		return "Accessories"
	}
	if kind == "Weapon" && category == 1 {
		return "Phantom Swords"
	}
	return "Weapons"
}

func categoryCodeForMaster(category string) (uint32, bool) {
	switch category {
	case "Weapons":
		return 0, true
	case "Phantom Swords":
		return 1, true
	case "Accessories":
		return 5, true
	default:
		return 0, false
	}
}

func equipmentRecordAssignedTo(model *SaveModel, category string, bank uint32) (string, string, int, bool) {
	for i := range model.Equipped {
		s := &model.Equipped[i]
		if s.BankNumber == ^uint32(0) {
			continue
		}
		if masterCategoryForTuple(s.Kind, s.Category) == category && s.BankNumber == bank && s.FixID != 0 {
			return s.Character, s.Kind, s.SlotIndex, true
		}
	}
	return "", "", 0, false
}

func stageComradesStatus(model *SaveModel, hp, hpMax, mp, mpMax, level, strength, vitality, magicValue, spirit, critical, exp, expTotal uint32, abilityPoints int32) error {
	if model == nil || model.GameMode != "Comrades" || model.Comrades == nil {
		return errors.New("load a Comrades gameplay0 save with a decoded avatar first")
	}
	c := model.Comrades
	if level < 1 || level > c.LevelMax || c.LevelMax == 0 || c.LevelMax > 999 {
		return fmt.Errorf("level must be 1 through %d", c.LevelMax)
	}
	if hpMax == 0 || hp > hpMax || hpMax > 9999999 {
		return errors.New("HP must be between 0 and Max HP; Max HP must be 1 through 9,999,999")
	}
	if mpMax == 0 || mp > mpMax || mpMax > 9999999 {
		return errors.New("MP must be between 0 and Max MP; Max MP must be 1 through 9,999,999")
	}
	for name, v := range map[string]uint32{"Strength": strength, "Vitality": vitality, "Magic": magicValue, "Spirit": spirit, "Critical": critical} {
		if v > 999999 {
			return fmt.Errorf("%s must be 0 through 999,999", name)
		}
	}
	if abilityPoints < 0 || abilityPoints > 9999999 {
		return errors.New("avatar AP must be 0 through 9,999,999")
	}
	c.HP, c.HPMax, c.MP, c.MPMax = hp, hpMax, mp, mpMax
	c.Level = level
	c.Strength, c.Vitality, c.Magic, c.Spirit, c.Critical = strength, vitality, magicValue, spirit, critical
	c.Exp, c.ExpTotal, c.AbilityPoints = exp, expTotal, abilityPoints
	return nil
}

func maxComradesStatus(model *SaveModel) error {
	if model == nil || model.Comrades == nil {
		return errors.New("load a decoded Comrades avatar first")
	}
	c := model.Comrades
	return stageComradesStatus(model, 99999, 99999, 9999, 9999, c.LevelMax, 9999, 9999, 9999, 9999, 9999, 99999999, 99999999, 999999)
}

func restoreComradesStatus(model *SaveModel) {
	if model == nil || model.Comrades == nil {
		return
	}
	c := model.Comrades
	c.HP, c.HPMax = c.OriginalHP, c.OriginalHPMax
	c.MP, c.MPMax = c.OriginalMP, c.OriginalMPMax
	c.Level = c.OriginalLevel
	c.Strength, c.Vitality, c.Magic, c.Spirit, c.Critical = c.OriginalStrength, c.OriginalVitality, c.OriginalMagic, c.OriginalSpirit, c.OriginalCritical
	c.Exp, c.ExpTotal, c.AbilityPoints = c.OriginalExp, c.OriginalExpTotal, c.OriginalAbilityPoints
}

func stageComradesEquipmentOwnershipState(model *SaveModel, category string, bank int, owned bool) (*EquipmentRecord, error) {
	if model == nil || model.GameMode != "Comrades" {
		return nil, errors.New("load a Comrades gameplay0 save first")
	}
	if category != "Weapons" && category != "Accessories" {
		return nil, errors.New("Comrades ownership editing supports weapons and accessories")
	}
	target := findMasterRecord(model, category, bank)
	if target == nil {
		return nil, fmt.Errorf("selected Comrades %s record was not found", strings.ToLower(category))
	}
	if target.FixID == 0 || isPlaceholderEquipment(target.FixID) {
		return nil, errors.New("selected record is not initialized equipment")
	}
	if !owned {
		if target.EquipmentOwner >= 0 {
			who := fmt.Sprintf("avatar save %d", target.EquipmentOwner)
			if model.Comrades != nil && target.EquipmentOwner == int32(model.Comrades.SaveIndex) {
				who = strings.TrimSpace(model.Comrades.Name)
				if who == "" {
					who = "the active Glaive"
				}
			}
			return nil, fmt.Errorf("%s bank %d is currently equipped by %s (slot %d); unequip or replace it on the Equipment page before removing it", map[string]string{"Weapons": "weapon", "Accessories": "accessory"}[category], bank, who, target.EquipmentBank+1)
		}
		if character, kind, slot, assigned := equipmentRecordAssignedTo(model, category, uint32(bank)); assigned {
			return nil, fmt.Errorf("%s bank %d is equipped by %s (%s slot %d); unequip it before removing it", map[string]string{"Weapons": "weapon", "Accessories": "accessory"}[category], bank, character, kind, slot)
		}
	}
	target.Exists = owned
	return target, nil
}

func stageComradesEquipmentOwnership(model *SaveModel, category string, bank int) (*EquipmentRecord, error) {
	return stageComradesEquipmentOwnershipState(model, category, bank, true)
}

func stageComradesAccessoryOwnership(model *SaveModel, bank int) (*EquipmentRecord, error) {
	return stageComradesEquipmentOwnership(model, "Accessories", bank)
}

func stageComradesGlaiveEquipmentSlot(model *SaveModel, kind string, slotIndex int, bank int) error {
	if model == nil || model.GameMode != "Comrades" || model.Comrades == nil {
		return errors.New("load a Comrades gameplay0 save with a decoded avatar first")
	}
	category := ""
	categoryCode := uint32(0)
	maxSlots := 0
	switch kind {
	case "Weapon":
		category = "Weapons"
		categoryCode = 0
		maxSlots = 4
	case "Accessory":
		category = "Accessories"
		categoryCode = 5
		maxSlots = 3
	default:
		return fmt.Errorf("unsupported equipment kind %q", kind)
	}
	if slotIndex < 1 || slotIndex > maxSlots {
		return fmt.Errorf("Comrades %s slot must be 1 through %d", strings.ToLower(kind), maxSlots)
	}
	if kind == "Weapon" && slotIndex == 1 && bank < 0 {
		return errors.New("the primary weapon slot cannot be empty")
	}
	slot := equippedSlotBySaveIndex(model, model.Comrades.SaveIndex, kind, slotIndex)
	if slot == nil {
		return fmt.Errorf("verified active Glaive %s slot %d was not found", strings.ToLower(kind), slotIndex)
	}
	owner := int32(model.Comrades.SaveIndex)
	equipBank := int32(slotIndex - 1)

	// Clear the master-record link for the equipment currently occupying this slot.
	if slot.BankNumber != ^uint32(0) {
		old := findMasterRecord(model, category, int(slot.BankNumber))
		if old != nil && old.FixID == slot.FixID && old.EquipmentOwner == owner && old.EquipmentBank == equipBank {
			old.EquipmentOwner = -1
			old.EquipmentBank = -1
		}
	}

	if bank < 0 {
		slot.FixID = 0
		slot.Type = ^uint32(0)
		slot.Category = ^uint32(0)
		slot.BankNumber = ^uint32(0)
		return nil
	}
	if kind == "Accessory" && bank >= 32 {
		return errors.New("Royal Sigils are not normal accessory-slot records; use the dedicated Sigil field after its job-command mapping is verified")
	}
	target := findMasterRecord(model, category, bank)
	if target == nil || target.FixID == 0 || isPlaceholderEquipment(target.FixID) {
		return fmt.Errorf("selected Comrades %s record is invalid", strings.ToLower(kind))
	}
	if target.EquipmentOwner >= 0 && (target.EquipmentOwner != owner || target.EquipmentBank != equipBank) {
		return fmt.Errorf("selected %s bank %d is already equipped by save %d in slot %d", strings.ToLower(kind), bank, target.EquipmentOwner, target.EquipmentBank+1)
	}
	target.Exists = true
	target.EquipmentOwner = owner
	target.EquipmentBank = equipBank
	slot.FixID = target.FixID
	slot.Type = target.Type
	slot.Category = categoryCode
	slot.BankNumber = uint32(bank)
	return nil
}

func stageComradesAccessoryEquipLink(model *SaveModel, bank int, slotIndex int) (*EquipmentRecord, error) {
	if err := stageComradesGlaiveEquipmentSlot(model, "Accessory", slotIndex, bank); err != nil {
		return nil, err
	}
	if bank < 0 {
		return nil, nil
	}
	return findMasterRecord(model, "Accessories", bank), nil
}

func stageComradesWeaponOwnershipState(model *SaveModel, bank int, owned bool) (*EquipmentRecord, error) {
	return stageComradesEquipmentOwnershipState(model, "Weapons", bank, owned)
}

func stageComradesWeaponOwnership(model *SaveModel, bank int) (*EquipmentRecord, error) {
	return stageComradesWeaponOwnershipState(model, bank, true)
}

type ComradesWeaponEdits struct {
	Rank             int32
	Attack           int32
	Vitality         int32
	Critical         int32
	RecoverMP        int32
	SlotCount        int32
	Ability1         uint32
	Ability2         uint32
	StatusAdjust     [19]int32
	RemodelFailCount int32
}

func stageComradesWeaponDetails(model *SaveModel, bank int, e ComradesWeaponEdits) (*EquipmentRecord, error) {
	if model == nil || model.GameMode != "Comrades" {
		return nil, errors.New("load a Comrades gameplay0 save first")
	}
	r := findMasterRecord(model, "Weapons", bank)
	if r == nil || r.FixID == 0 || isPlaceholderEquipment(r.FixID) {
		return nil, errors.New("selected Comrades weapon record is invalid")
	}
	if e.Rank < 0 || e.Rank > 99 {
		return nil, errors.New("weapon rank must be 0 through 99")
	}
	limits := map[string]struct{ value, max int32 }{
		"Attack": {e.Attack, comradesWeaponAttackMax}, "Vitality": {e.Vitality, comradesWeaponVitalityMax},
		"Critical": {e.Critical, comradesWeaponCriticalMax},
	}
	for name, lim := range limits {
		if lim.value < 0 || lim.value > lim.max {
			return nil, fmt.Errorf("%s must be 0 through %d", name, lim.max)
		}
	}
	if e.RecoverMP < 0 || e.RecoverMP > 9999 {
		return nil, errors.New("MP recovery must be 0 through 9999")
	}
	if e.SlotCount < 0 || e.SlotCount > comradesWeaponSlotMax {
		return nil, fmt.Errorf("ability slot count must be 0 through %d", comradesWeaponSlotMax)
	}
	if e.RemodelFailCount < 0 || e.RemodelFailCount > 9999 {
		return nil, errors.New("remodel fail count must be 0 through 9999")
	}
	if !abilityCatalogContains(e.Ability1) || !abilityCatalogContains(e.Ability2) {
		return nil, errors.New("selected ability is not present in the supplied ability database")
	}
	all9999 := true
	for i, v := range e.StatusAdjust {
		if v < -9999 || v > 9999 {
			return nil, fmt.Errorf("status adjustment %d must be -9999 through 9999", i+1)
		}
		if v != 9999 {
			all9999 = false
		}
	}
	if all9999 {
		return nil, errors.New("the all-9999 raw status profile is blocked")
	}
	r.Rank = e.Rank
	r.Strength = e.Attack
	r.Vitality = e.Vitality
	r.Critical = e.Critical
	r.RecoverMP = e.RecoverMP
	r.SlotCount = e.SlotCount
	if r.Abilities[0].FixID != e.Ability1 {
		r.Abilities[0] = AbilityLink{FixID: e.Ability1, BankNumber: -1}
	}
	if r.Abilities[1].FixID != e.Ability2 {
		r.Abilities[1] = AbilityLink{FixID: e.Ability2, BankNumber: -1}
	}
	r.StatusAdjust = e.StatusAdjust
	r.RemodelFailCount = e.RemodelFailCount
	return r, nil
}

func stageComradesWeaponEquipLink(model *SaveModel, bank int, slotIndex int) (*EquipmentRecord, error) {
	if err := stageComradesGlaiveEquipmentSlot(model, "Weapon", slotIndex, bank); err != nil {
		return nil, err
	}
	if bank < 0 {
		return nil, nil
	}
	return findMasterRecord(model, "Weapons", bank), nil
}

func restoreComradesWeaponDetails(r *EquipmentRecord) {
	if r == nil {
		return
	}
	r.Rank = r.OriginalRank
	r.Strength = r.OriginalStrength
	r.Vitality = r.OriginalVitality
	r.Critical = r.OriginalCritical
	r.RecoverMP = r.OriginalRecoverMP
	r.SlotCount = r.OriginalSlotCount
	r.Abilities = r.OriginalAbilities
	r.ResidentAbility = r.OriginalResidentAbility
	r.StatusAdjust = r.OriginalStatusAdjust
	r.RemodelFailCount = r.OriginalRemodelFailCount
}

func restoreComradesWeaponOwnership(model *SaveModel) {
	if model == nil || model.GameMode != "Comrades" {
		return
	}
	for i := range model.Equipment {
		r := &model.Equipment[i]
		if r.Category == "Weapons" {
			r.Exists = r.OriginalExists
			r.EquipmentOwner = r.OriginalEquipmentOwner
			r.EquipmentBank = r.OriginalEquipmentBank
			restoreComradesWeaponDetails(r)
		}
	}
}

func restoreComradesAccessoryOwnership(model *SaveModel) {
	if model == nil || model.GameMode != "Comrades" {
		return
	}
	for i := range model.Equipment {
		r := &model.Equipment[i]
		if r.Category == "Accessories" {
			r.FixID = r.OriginalFixID
			r.Type = r.OriginalType
			r.NameID = r.OriginalNameID
			r.Exists = r.OriginalExists
			r.EquipmentOwner = r.OriginalEquipmentOwner
			r.EquipmentBank = r.OriginalEquipmentBank
			restoreComradesWeaponDetails(r)
		}
	}
}

func maxComradesOwnedMaterials(model *SaveModel) int {
	if model == nil || model.GameMode != "Comrades" {
		return 0
	}
	changed := 0
	for i := range model.Inventory {
		s := &model.Inventory[i]
		if (s.Category == "Food / Ingredients" || s.Category == "Treasures") && s.FixID != 0 && s.Amount != 99 {
			s.Amount = 99
			changed++
		}
	}
	return changed
}

var comradesMeteorshardVoucherFixIDs = []uint32{0x01062E8F, 0x01069AB6, 0x01069AB7, 0x01069AB8, 0x01069AB9, 0x01069ABA}

func addComradesMeteorshardVouchers(model *SaveModel, quantity int32) (int, error) {
	if model == nil || model.GameMode != "Comrades" {
		return 0, errors.New("load a Comrades gameplay0 save first")
	}
	added := 0
	for _, id := range comradesMeteorshardVoucherFixIDs {
		if _, err := addGameItemToInventory(model, id, quantity); err != nil {
			return added, err
		}
		added++
	}
	return added, nil
}

func stageEquipmentSelection(model *SaveModel, character, kind string, slotIndex int, category string, bank int) error {
	if _, ok := characterSaveIndex(character); !ok {
		return errors.New("unsupported permanent party character")
	}
	if kind == "Weapon" {
		if slotIndex < 1 || slotIndex > 4 || (category != "Weapons" && category != "Phantom Swords") {
			return errors.New("weapon slot/category is invalid")
		}
		if category == "Phantom Swords" && character != "Noctis" {
			return errors.New("Royal Arms are only offered for Noctis")
		}
	} else if kind == "Accessory" {
		if slotIndex < 1 || slotIndex > 3 || category != "Accessories" {
			return errors.New("accessory slot/category is invalid")
		}
	} else {
		return errors.New("unsupported equipment kind")
	}
	target := findMasterRecord(model, category, bank)
	if target == nil {
		return errors.New("target equipment master record was not found")
	}
	if target.FixID == 0 {
		return errors.New("target equipment record is empty")
	}
	target.Exists = true
	slot := equippedSlot(model, character, kind, slotIndex)
	if slot == nil {
		return errors.New("selected equipped slot was not found")
	}
	if slot.OriginalBankNumber == ^uint32(0) || slot.OriginalFixID == 0 {
		return errors.New("this gear slot is empty/unavailable in the loaded save; writing it is disabled for safety")
	}
	if kind == "Weapon" && character != "Noctis" && target.Type != slot.OriginalType {
		return fmt.Errorf("%s is not compatible with %s Weapon Slot %d", equipmentDisplayName(target.FixID), character, slotIndex)
	}
	if c, k, si, assigned := equipmentRecordAssignedTo(model, category, uint32(bank)); assigned {
		if c != character || k != kind || si != slotIndex {
			return fmt.Errorf("%s is already equipped by %s %s Slot %d", equipmentDisplayName(target.FixID), c, k, si)
		}
	}
	slot.FixID = target.FixID
	slot.Type = target.Type
	code, ok := categoryCodeForMaster(category)
	if !ok {
		return errors.New("unsupported equipment master category")
	}
	slot.Category = code
	slot.BankNumber = uint32(bank)
	return nil
}

func stageAttireSelection(model *SaveModel, character string, bank int) error {
	if _, ok := characterSaveIndex(character); !ok {
		return errors.New("unsupported permanent party character")
	}
	slot := attireSlot(model, character)
	if slot == nil {
		return errors.New("attire slot was not found")
	}
	target := findClothRecord(model, bank)
	if target == nil {
		return errors.New("target attire record was not found")
	}
	if target.Type != slot.OriginalType {
		return fmt.Errorf("%s is not compatible with %s", clothDisplayName(target.FixID), character)
	}
	for i := range model.Attire {
		other := &model.Attire[i]
		if other.BankNumber == uint32(bank) && other.FixID != 0 && other.Character != character {
			return fmt.Errorf("%s is already equipped by %s", clothDisplayName(target.FixID), other.Character)
		}
	}
	slot.FixID = target.FixID
	slot.Type = target.Type
	slot.BankNumber = uint32(bank)
	return nil
}

func stageVerifiedEquipmentPreset(model *SaveModel, character, kind string, slotIndex int, preset EquipmentPreset) error {
	if character != "Noctis" || slotIndex != 1 || (kind != "Weapon" && kind != "Accessory") {
		return errors.New("v2.3 write support is verified only for Noctis Weapon Slot 1 and Accessory Slot 1")
	}
	if kind == "Weapon" && preset.MasterCategory != "Weapons" {
		return errors.New("selected preset is not a weapon")
	}
	if kind == "Accessory" && preset.MasterCategory != "Accessories" {
		return errors.New("selected preset is not an accessory")
	}
	if preset.MasterIndex < 0 || preset.MasterIndex >= len(model.Equipment) {
		return errors.New("verified equipment preset has an invalid master index")
	}
	var master *EquipmentRecord
	for i := range model.Equipment {
		r := &model.Equipment[i]
		if r.Category == preset.MasterCategory && r.CategoryIndex == preset.MasterIndex {
			master = r
			break
		}
	}
	if master == nil || master.FixID != preset.FixID {
		return fmt.Errorf("%s is not present in the expected verified equipment record", preset.Name)
	}
	s := equippedSlot(model, character, kind, slotIndex)
	if s == nil {
		return errors.New("verified equipped slot was not found")
	}
	s.FixID = preset.FixID
	s.Type = preset.Type
	s.Category = preset.Category
	s.BankNumber = preset.BankNumber
	return nil
}

func findMasterRecord(model *SaveModel, category string, index int) *EquipmentRecord {
	for i := range model.Equipment {
		r := &model.Equipment[i]
		if r.Category == category && r.CategoryIndex == index {
			return r
		}
	}
	return nil
}

func slotMasterCategory(kind string) string {
	if kind == "Accessory" {
		return "Accessories"
	}
	return "Weapons"
}

func applyModelEdits(input []byte, model *SaveModel, general GeneralEdits) ([]byte, int, int, int, error) {
	if general.ControlledCharacter > 31 {
		return nil, 0, 0, 0, errors.New("controlled save index must be 0 through 31")
	}
	if general.Chapter > 99 {
		return nil, 0, 0, 0, errors.New("chapter must be 0 through 99")
	}
	if general.Gil > maxGil {
		return nil, 0, 0, 0, fmt.Errorf("Gil must be 0 through %d", maxGil)
	}
	if general.AbilityPoints > maxAP {
		return nil, 0, 0, 0, fmt.Errorf("AP must be 0 through %d", maxAP)
	}
	out := append([]byte(nil), input...)
	allowed := make(map[int]bool)
	writeU32 := func(offset int, v uint32) {
		binary.LittleEndian.PutUint32(out[offset:offset+4], v)
		for i := 0; i < 4; i++ {
			allowed[offset+i] = true
		}
	}
	base := model.Party.MarkerOffset + 8
	writeU32(base+0, general.ControlledCharacter)
	writeU32(base+4, general.Chapter)
	writeU32(base+8, general.Gil)
	writeU32(base+12, general.ArenaMedals)
	writeU32(base+16, general.OracleCoins)
	writeU32(base+20, general.AbilityPoints)
	if model.GameMode == "Comrades" && model.Comrades != nil {
		c := model.Comrades
		if c.Level < 1 || c.Level > c.LevelMax || c.HP > c.HPMax || c.MP > c.MPMax || c.HPMax == 0 || c.MPMax == 0 {
			return nil, 0, 0, 0, errors.New("invalid staged Comrades avatar status values")
		}
		if c.AbilityPoints < 0 || c.AbilityPoints > 9999999 {
			return nil, 0, 0, 0, errors.New("Comrades avatar AP must be 0 through 9,999,999")
		}
		sb := c.StatusMarkerOffset + 8
		psb := c.PlayerStatusMarkerOffset + 8
		writeU32(sb+27, c.HP)
		writeU32(sb+31, c.HPMax)
		writeU32(sb+111, c.MP)
		writeU32(sb+115, c.MPMax)
		writeU32(sb+135, c.Level)
		writeU32(sb+147, c.Strength)
		writeU32(sb+151, c.Vitality)
		writeU32(sb+155, c.Magic)
		writeU32(sb+159, c.Spirit)
		writeU32(sb+163, c.Critical)
		writeU32(psb+0, c.Exp)
		writeU32(psb+4, c.ExpTotal)
		writeU32(psb+8, uint32(c.AbilityPoints))
	}
	if model.GameMode == "Comrades" {
		for i := range model.ComradesAbilities {
			a := &model.ComradesAbilities[i]
			if a.Level < 0 || a.Level > 99 {
				return nil, 0, 0, 0, fmt.Errorf("character ability %s level must be 0 through 99", abilityDisplayName(a.FixID))
			}
			if a.Count != a.OriginalCount {
				return nil, 0, 0, 0, fmt.Errorf("character ability %s count is not writable in this build", abilityDisplayName(a.FixID))
			}
			if (a.Flags^a.OriginalFlags)&^byte(0x01) != 0 {
				return nil, 0, 0, 0, fmt.Errorf("character ability %s has an unverified flag change", abilityDisplayName(a.FixID))
			}
			if a.Level == a.OriginalLevel && a.Flags == a.OriginalFlags {
				continue
			}
			base := a.MarkerOffset + 8
			writeU32(base+8, uint32(a.Level))
			if out[base+16] != a.Flags {
				out[base+16] = a.Flags
				allowed[base+16] = true
			}
		}
	}
	if model.GameMode == "Comrades" && model.ComradesKW != nil {
		if model.ComradesKW.Current > maxComradesKW {
			return nil, 0, 0, 0, fmt.Errorf("Comrades kW must be 0 through %d", maxComradesKW)
		}
		writeU32(model.ComradesKW.ValueOffset, model.ComradesKW.Current)
	}
	if model.GameMode == "Comrades" {
		writeI16 := func(offset int, v int16) {
			binary.LittleEndian.PutUint16(out[offset:offset+2], uint16(v))
			allowed[offset] = true
			allowed[offset+1] = true
		}
		for i := range model.ComradesChocobos {
			c := &model.ComradesChocobos[i]
			if c.Level < 1 || c.Level > c.MaxLevel || c.MaxLevel < 1 || c.MaxLevel > c.LimitMaxLevel || c.LimitMaxLevel > 999 {
				return nil, 0, 0, 0, fmt.Errorf("chocobo %d has invalid level/cap values", i+1)
			}
			if c.Stamina < 0 || c.Stamina > 9999 || c.Jump < 0 || c.Jump > 9999 || c.SkillLevel < 0 || c.SkillLevel > 999 || c.InjuryPercent < 0 || c.InjuryPercent > 100 {
				return nil, 0, 0, 0, fmt.Errorf("chocobo %d has an out-of-range stat", i+1)
			}
			if math.IsNaN(float64(c.Speed)) || math.IsInf(float64(c.Speed), 0) || c.Speed < 0 || c.Speed > 999.9 {
				return nil, 0, 0, 0, fmt.Errorf("chocobo %d has an invalid speed", i+1)
			}
			rb := c.RecordOffset
			writeU32(rb+0x10, uint32(c.Stamina))
			writeU32(rb+0x14, uint32(c.Jump))
			writeU32(rb+0x18, math.Float32bits(c.Speed))
			writeI16(rb+0x48, c.SkillLevel)
			writeI16(rb+0x4A, c.LimitMaxLevel)
			writeI16(rb+0x4C, c.MaxLevel)
			writeI16(rb+0x4E, c.Level)
			writeI16(rb+0x50, c.InjuryPercent)
		}
	}
	writeF32 := func(offset int, v float32) {
		binary.LittleEndian.PutUint32(out[offset:offset+4], math.Float32bits(v))
		for i := 0; i < 4; i++ {
			allowed[offset+i] = true
		}
	}
	for _, idx := range []int{partyElementFireIndex, partyElementIceIndex, partyElementLightningIndex} {
		v := model.Party.ElementPower[idx]
		if float32(math.Trunc(float64(v))) != v || v < 0 || v > maxElementEnergy {
			return nil, 0, 0, 0, fmt.Errorf("elemental energy must be whole values from 0 through %.0f", maxElementEnergy)
		}
	}
	for i, v := range model.Party.ElementPower {
		writeF32(model.Party.ElementPowerOffset+i*4, v)
	}
	invChanges := 0
	for i := range model.Inventory {
		slot := &model.Inventory[i]
		amountMax := int32(99)
		if slot.FixID == timedQuestQPFixID {
			amountMax = maxTimedQuestQP
		}
		if slot.Amount < 0 || slot.Amount > amountMax {
			return nil, 0, 0, 0, fmt.Errorf("%s slot %d amount must be 0 through %d", slot.Category, slot.CategoryIndex, amountMax)
		}
		if slot.FixID != slot.OriginalFixID && slot.FixID != 0 {
			entry, ok := catalogEntryByFixID(slot.FixID)
			if !ok {
				return nil, 0, 0, 0, fmt.Errorf("%s slot %d contains an unrecognized new FixID 0x%08X", slot.Category, slot.CategoryIndex, slot.FixID)
			}
			targetCategory, ok := catalogInventoryCategory(entry.GameCategory)
			if !ok || targetCategory != slot.Category {
				return nil, 0, 0, 0, fmt.Errorf("%s cannot be inserted into %s", itemDisplayName(slot.FixID), slot.Category)
			}
		}
		if slot.FixID != slot.OriginalFixID || slot.Amount != slot.OriginalAmount {
			invChanges++
		}
		off := slot.MarkerOffset + 8
		binary.LittleEndian.PutUint32(out[off:off+4], slot.FixID)
		binary.LittleEndian.PutUint32(out[off+4:off+8], uint32(slot.Amount))
		for j := 0; j < 8; j++ {
			allowed[off+j] = true
		}
	}
	eqChanges := 0
	writeBytes := func(offset int, values []byte) {
		copy(out[offset:offset+len(values)], values)
		for i := range values {
			allowed[offset+i] = true
		}
	}

	// Write explicitly staged master-record ownership changes. This is used by
	// Comrades to add a weapon to the player's owned weapon pool without
	// touching its preinitialized rank/stats/crafting payload or equip link.
	for i := range model.Equipment {
		r := &model.Equipment[i]
		if r.Exists == r.OriginalExists {
			continue
		}
		if model.GameMode != "Comrades" {
			// Main-game unowned records are unlocked by the verified equipped-slot
			// writer below. Standalone ownership changes are not exposed there.
			continue
		}
		if r.Category != "Weapons" && r.Category != "Accessories" {
			return nil, 0, 0, 0, errors.New("standalone Comrades ownership editing is only enabled for weapons/accessories")
		}
		stateOffset := r.MarkerOffset + 8 + 4
		state := out[stateOffset]
		if r.Exists {
			state |= 0x02
		} else {
			state &^= 0x02
		}
		if out[stateOffset] != state {
			out[stateOffset] = state
			allowed[stateOffset] = true
			eqChanges++
		}
	}

	// Comrades weapon-instance editor. These fields come directly from the
	// SaveWeaponStruct schema and the physical packed layout validated in parseEquipment.
	if model.GameMode == "Comrades" {
		for i := range model.Equipment {
			r := &model.Equipment[i]
			if (r.Category != "Weapons" && r.Category != "Accessories") || r.FixID == 0 || isPlaceholderEquipment(r.FixID) {
				continue
			}
			changedRecord := r.FixID != r.OriginalFixID || r.NameID != r.OriginalNameID || r.Type != r.OriginalType || r.EquipmentOwner != r.OriginalEquipmentOwner || r.EquipmentBank != r.OriginalEquipmentBank || r.Rank != r.OriginalRank || r.Strength != r.OriginalStrength || r.Vitality != r.OriginalVitality || r.Critical != r.OriginalCritical || r.RecoverMP != r.OriginalRecoverMP || r.SlotCount != r.OriginalSlotCount || r.Abilities != r.OriginalAbilities || r.ResidentAbility != r.OriginalResidentAbility || r.StatusAdjust != r.OriginalStatusAdjust || r.RemodelFailCount != r.OriginalRemodelFailCount
			if !changedRecord {
				continue
			}
			if r.Category == "Accessories" {
				base := r.MarkerOffset + 8
				if isPlaceholderEquipment(r.OriginalFixID) && !isPlaceholderEquipment(r.FixID) {
					sg := comradesSigilCatalogByBank(r.CategoryIndex)
					if sg == nil || sg.FixID != r.FixID || sg.NameID != r.NameID || sg.Type != r.Type || sg.JobIndex != r.Rank {
						return nil, 0, 0, 0, fmt.Errorf("unverified synthesized Comrades accessory at bank %d", r.CategoryIndex)
					}
					writeU32(base, r.FixID)
					stateOffset := base + 4
					state := out[stateOffset] | 0x03 // initialized + owned
					if out[stateOffset] != state {
						out[stateOffset] = state
						allowed[stateOffset] = true
					}
					writeU32(base+5, uint32(r.EquipmentOwner))
					writeU32(base+9, uint32(r.EquipmentBank))
					writeU32(base+13, r.NameID)
					writeU32(base+17, r.Type)
					writeU32(base+21, uint32(r.Rank))
					writeU32(base+25, uint32(r.Strength))
					writeU32(base+29, uint32(r.Vitality))
					writeU32(base+33, uint32(r.Critical))
					writeU32(base+37, uint32(r.RecoverMP))
					writeU32(base+41, uint32(r.SlotCount))
					writeU32(base+57, r.Abilities[0].FixID)
					writeU32(base+61, uint32(r.Abilities[0].BankNumber))
					writeU32(base+73, r.Abilities[1].FixID)
					writeU32(base+77, uint32(r.Abilities[1].BankNumber))
					writeU32(base+93, r.ResidentAbility.FixID)
					writeU32(base+97, uint32(r.ResidentAbility.BankNumber))
					for n, v := range r.StatusAdjust {
						writeU32(base+105+n*4, uint32(v))
					}
					writeU32(base+181, uint32(r.RemodelFailCount))
					eqChanges++
					continue
				}
				// Initialized retail accessories preserve all non-link payload fields.
				writeU32(base+5, uint32(r.EquipmentOwner))
				writeU32(base+9, uint32(r.EquipmentBank))
				eqChanges++
				continue
			}
			// Most retail Comrades weapons use ranks 0..99, but the supplied game
			// database contains initialized internal weapons with preexisting ranks
			// 200 and 300. Permit those only when the unusual rank itself is left
			// unchanged; this allows safe ownership/stat edits without normalizing or
			// inventing a high rank.
			invalidRank := r.Rank < 0 || (r.Rank > 99 && r.Rank != r.OriginalRank)
			if invalidRank || r.SlotCount < 0 || r.SlotCount > comradesWeaponSlotMax || r.RemodelFailCount < 0 || r.RemodelFailCount > 9999 {
				return nil, 0, 0, 0, fmt.Errorf("invalid staged equipment data for %s", equipmentDisplayName(r.FixID))
			}
			if !weaponDirectStatsWithinTestedRanges(r.Strength, r.Vitality, r.Critical) {
				return nil, 0, 0, 0, fmt.Errorf("equipment direct stat outside tested editor range for %s", equipmentDisplayName(r.FixID))
			}
			if r.RecoverMP < 0 || r.RecoverMP > 9999 {
				return nil, 0, 0, 0, fmt.Errorf("MP Recovery outside manual editor range for %s", equipmentDisplayName(r.FixID))
			}
			if (r.Abilities[0] != r.OriginalAbilities[0] && !abilityCatalogContains(r.Abilities[0].FixID)) || (r.Abilities[1] != r.OriginalAbilities[1] && !abilityCatalogContains(r.Abilities[1].FixID)) {
				return nil, 0, 0, 0, fmt.Errorf("unknown staged ability on %s", equipmentDisplayName(r.FixID))
			}
			if r.ResidentAbility != r.OriginalResidentAbility {
				validResident := false
				for _, p := range comradesResidentPresets {
					if p.FixID == r.ResidentAbility.FixID && p.Bank == r.ResidentAbility.BankNumber {
						validResident = true
						break
					}
				}
				if !validResident {
					return nil, 0, 0, 0, fmt.Errorf("unverified resident/passive pair on %s", equipmentDisplayName(r.FixID))
				}
			}
			for i, v := range r.StatusAdjust {
				// Legitimate evolved weapons may contain opaque values outside the
				// manual-edit range. Allow those only when preserved exactly from
				// the loaded record; newly introduced out-of-range values remain
				// blocked.
				if (v < -9999 || v > 9999) && v != r.OriginalStatusAdjust[i] {
					return nil, 0, 0, 0, fmt.Errorf("crafting adjustment outside safe range for %s", equipmentDisplayName(r.FixID))
				}
			}
			allRaw9999 := true
			for _, v := range r.StatusAdjust {
				if v != 9999 {
					allRaw9999 = false
					break
				}
			}
			if allRaw9999 {
				return nil, 0, 0, 0, fmt.Errorf("known destructive all-9999 raw status profile blocked for %s", equipmentDisplayName(r.FixID))
			}
			base := r.MarkerOffset + 8
			writeU32(base+5, uint32(r.EquipmentOwner))
			writeU32(base+9, uint32(r.EquipmentBank))
			writeU32(base+21, uint32(r.Rank))
			writeU32(base+25, uint32(r.Strength))
			writeU32(base+29, uint32(r.Vitality))
			writeU32(base+33, uint32(r.Critical))
			writeU32(base+37, uint32(r.RecoverMP))
			writeU32(base+41, uint32(r.SlotCount))
			writeU32(base+57, r.Abilities[0].FixID)
			writeU32(base+61, uint32(r.Abilities[0].BankNumber))
			writeU32(base+73, r.Abilities[1].FixID)
			writeU32(base+77, uint32(r.Abilities[1].BankNumber))
			// Resident/passive uses its own local bank semantics. Only verified
			// FixID/bank pairs can be staged by the Comrades weapon editor.
			writeU32(base+93, r.ResidentAbility.FixID)
			writeU32(base+97, uint32(r.ResidentAbility.BankNumber))
			for n, v := range r.StatusAdjust {
				writeU32(base+105+n*4, uint32(v))
			}
			writeU32(base+181, uint32(r.RemodelFailCount))
			eqChanges++
		}
	}

	// Every SaveWeaponStruct master record stores two serialized int32 links:
	// SAVE_PLAYER and the weapon/accessory slot index. The supplied saves prove
	// 0/1/2/3 for Noctis/Gladiolus/Ignis/Prompto and slotIndex-1 for the second
	// integer (including Ignis Weapon Slot 2). -1,-1 means unequipped.
	finalAssignments := make(map[string]string)
	for i := range model.Equipped {
		slot := &model.Equipped[i]
		if slot.FixID == 0 || slot.BankNumber == ^uint32(0) {
			continue
		}
		key := fmt.Sprintf("%s:%d", masterCategoryForTuple(slot.Kind, slot.Category), slot.BankNumber)
		owner := fmt.Sprintf("%s %s %d", slot.Character, slot.Kind, slot.SlotIndex)
		if prev, exists := finalAssignments[key]; exists && prev != owner {
			return nil, 0, 0, 0, fmt.Errorf("equipment master record is assigned twice: %s and %s", prev, owner)
		}
		finalAssignments[key] = owner
	}
	for i := range model.Equipped {
		slot := &model.Equipped[i]
		changedSlot := slot.FixID != slot.OriginalFixID || slot.Type != slot.OriginalType || slot.Category != slot.OriginalCategory || slot.BankNumber != slot.OriginalBankNumber
		if !changedSlot {
			continue
		}
		charIndex := slot.SaveIndex
		if (slot.Kind == "Weapon" && (slot.SlotIndex < 1 || slot.SlotIndex > 4)) || (slot.Kind == "Accessory" && (slot.SlotIndex < 1 || slot.SlotIndex > 3)) {
			return nil, 0, 0, 0, errors.New("attempted equipment write outside supported verified slots")
		}
		if slot.FixID == 0 && slot.BankNumber == ^uint32(0) {
			if slot.OriginalFixID != 0 && slot.OriginalBankNumber != ^uint32(0) {
				oldCategory := masterCategoryForTuple(slot.Kind, slot.OriginalCategory)
				oldMaster := findMasterRecord(model, oldCategory, int(slot.OriginalBankNumber))
				if oldMaster == nil || oldMaster.FixID != slot.OriginalFixID {
					return nil, 0, 0, 0, fmt.Errorf("could not validate original %s master record", slot.Kind)
				}
				writeBytes(oldMaster.MarkerOffset+8+5, []byte{0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF})
			}
			base := slot.MarkerOffset + 8
			writeU32(base+0, 0)
			writeU32(base+4, ^uint32(0))
			writeU32(base+8, ^uint32(0))
			writeU32(base+12, ^uint32(0))
			eqChanges++
			continue
		}
		category := masterCategoryForTuple(slot.Kind, slot.Category)
		newMaster := findMasterRecord(model, category, int(slot.BankNumber))
		if newMaster == nil || newMaster.FixID != slot.FixID || newMaster.Type != slot.Type {
			return nil, 0, 0, 0, fmt.Errorf("could not validate target %s master record", slot.Kind)
		}
		// SaveWeaponStruct state byte uses bit 0x02 for ownership. Preserve
		// other game flags while unlocking a database record that was not owned.
		stateOffset := newMaster.MarkerOffset + 8 + 4
		newState := out[stateOffset] | 0x02
		if out[stateOffset] != newState {
			out[stateOffset] = newState
			allowed[stateOffset] = true
		}
		if slot.Kind == "Weapon" && slot.Category != 0 && slot.Category != 1 {
			return nil, 0, 0, 0, errors.New("weapon category tuple is invalid")
		}
		if slot.Kind == "Accessory" && slot.Category != 5 {
			return nil, 0, 0, 0, errors.New("accessory category tuple is invalid")
		}
		if slot.OriginalFixID != 0 && slot.OriginalBankNumber != ^uint32(0) && slot.OriginalBankNumber != slot.BankNumber {
			oldCategory := masterCategoryForTuple(slot.Kind, slot.OriginalCategory)
			oldMaster := findMasterRecord(model, oldCategory, int(slot.OriginalBankNumber))
			if oldMaster == nil || oldMaster.FixID != slot.OriginalFixID {
				return nil, 0, 0, 0, fmt.Errorf("could not validate original %s master record", slot.Kind)
			}
			writeBytes(oldMaster.MarkerOffset+8+5, []byte{0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF})
		}
		link := make([]byte, 8)
		binary.LittleEndian.PutUint32(link[0:4], charIndex)
		binary.LittleEndian.PutUint32(link[4:8], uint32(slot.SlotIndex-1))
		writeBytes(newMaster.MarkerOffset+8+5, link)
		base := slot.MarkerOffset + 8
		writeU32(base+0, slot.FixID)
		writeU32(base+4, slot.Type)
		writeU32(base+8, slot.Category)
		writeU32(base+12, slot.BankNumber)
		eqChanges++
	}

	// Attire uses SaveClothEquipmentStruct (id, character cloth type, bank).
	// SaveClothStruct keeps direct int32 equipment/equipment_cloth_bank_number
	// links at +8/+12. One attire slot exists per permanent party character.
	clothAssignments := make(map[uint32]string)
	for i := range model.Attire {
		slot := &model.Attire[i]
		if slot.FixID == 0 || slot.BankNumber == ^uint32(0) {
			continue
		}
		if prev, exists := clothAssignments[slot.BankNumber]; exists && prev != slot.Character {
			return nil, 0, 0, 0, fmt.Errorf("attire master record is assigned twice: %s and %s", prev, slot.Character)
		}
		clothAssignments[slot.BankNumber] = slot.Character
	}
	for i := range model.Attire {
		slot := &model.Attire[i]
		changedSlot := slot.FixID != slot.OriginalFixID || slot.Type != slot.OriginalType || slot.BankNumber != slot.OriginalBankNumber
		if !changedSlot {
			continue
		}
		charIndex := slot.SaveIndex
		newMaster := findClothRecord(model, int(slot.BankNumber))
		if newMaster == nil || newMaster.FixID != slot.FixID || newMaster.Type != slot.Type {
			return nil, 0, 0, 0, errors.New("could not validate target attire master record")
		}
		// SaveClothStruct flags use bit 0x01 for ownership. Preserve the
		// remaining attire flags when adding an unowned database entry.
		flagsOffset := newMaster.MarkerOffset + 8 + 20
		newFlags := out[flagsOffset] | 0x01
		if out[flagsOffset] != newFlags {
			out[flagsOffset] = newFlags
			allowed[flagsOffset] = true
		}
		if newMaster.Type != slot.OriginalType {
			return nil, 0, 0, 0, fmt.Errorf("target attire is not compatible with %s", slot.Character)
		}
		if slot.OriginalFixID != 0 && slot.OriginalBankNumber != ^uint32(0) && slot.OriginalBankNumber != slot.BankNumber {
			oldMaster := findClothRecord(model, int(slot.OriginalBankNumber))
			if oldMaster == nil || oldMaster.FixID != slot.OriginalFixID {
				return nil, 0, 0, 0, errors.New("could not validate original attire master record")
			}
			writeU32(oldMaster.MarkerOffset+8+8, ^uint32(0))
			writeU32(oldMaster.MarkerOffset+8+12, ^uint32(0))
		}
		writeU32(newMaster.MarkerOffset+8+8, charIndex)
		writeU32(newMaster.MarkerOffset+8+12, 0)
		base := slot.MarkerOffset + 8
		writeU32(base+0, slot.FixID)
		writeU32(base+4, slot.Type)
		writeU32(base+8, slot.BankNumber)
		eqChanges++
	}

	if len(out) != len(input) {
		return nil, 0, 0, 0, errors.New("internal edit changed save size")
	}
	changed := 0
	for i := range input {
		if input[i] != out[i] {
			changed++
			if !allowed[i] {
				return nil, 0, 0, 0, fmt.Errorf("unexpected byte change at 0x%X", i)
			}
		}
	}
	if !equalBytes(out[len(out)-footerSize:], input[len(input)-footerSize:]) {
		return nil, 0, 0, 0, errors.New("edit changed FFXV footer")
	}
	verified, err := parseSaveModelBytes(out, model.Path)
	if err != nil {
		return nil, 0, 0, 0, fmt.Errorf("edited save validation failed: %w", err)
	}
	if verified.Party.Gil != general.Gil || verified.Party.AbilityPoints != general.AbilityPoints || verified.Party.Chapter != general.Chapter {
		return nil, 0, 0, 0, errors.New("general values failed read-back validation")
	}
	if model.GameMode == "Comrades" && model.Comrades != nil {
		want, got := model.Comrades, verified.Comrades
		if got == nil || got.HP != want.HP || got.HPMax != want.HPMax || got.MP != want.MP || got.MPMax != want.MPMax || got.Level != want.Level || got.Strength != want.Strength || got.Vitality != want.Vitality || got.Magic != want.Magic || got.Spirit != want.Spirit || got.Critical != want.Critical || got.Exp != want.Exp || got.ExpTotal != want.ExpTotal || got.AbilityPoints != want.AbilityPoints {
			return nil, 0, 0, 0, errors.New("Comrades avatar status failed read-back validation")
		}
	}
	if model.GameMode == "Comrades" && model.ComradesKW != nil {
		if verified.ComradesKW == nil || verified.ComradesKW.Current != model.ComradesKW.Current {
			return nil, 0, 0, 0, errors.New("Comrades direct kW failed read-back validation")
		}
	}
	if model.GameMode == "Comrades" {
		if len(verified.ComradesChocobos) != len(model.ComradesChocobos) {
			return nil, 0, 0, 0, errors.New("Comrades chocobo count changed after edit")
		}
		for i := range model.ComradesChocobos {
			want, got := model.ComradesChocobos[i], verified.ComradesChocobos[i]
			if got.NameID != want.NameID || got.Personality != want.Personality || got.Rarity != want.Rarity || got.Color != want.Color || got.Stamina != want.Stamina || got.Jump != want.Jump || math.Float32bits(got.Speed) != math.Float32bits(want.Speed) || got.SkillLevel != want.SkillLevel || got.LimitMaxLevel != want.LimitMaxLevel || got.MaxLevel != want.MaxLevel || got.Level != want.Level || got.InjuryPercent != want.InjuryPercent || got.IsNew != want.IsNew || got.IsInjured != want.IsInjured || got.TrainingRateCnt != want.TrainingRateCnt {
				return nil, 0, 0, 0, fmt.Errorf("Comrades chocobo %d failed read-back validation", i+1)
			}
		}
	}
	if model.GameMode == "Comrades" {
		if len(verified.ComradesAbilities) != len(model.ComradesAbilities) {
			return nil, 0, 0, 0, errors.New("Comrades character ability count changed after edit")
		}
		for i := range model.ComradesAbilities {
			want, got := model.ComradesAbilities[i], verified.ComradesAbilities[i]
			if got.FixID != want.FixID || got.AbilityID != want.AbilityID || got.WeaponBankNumber != want.WeaponBankNumber || got.Level != want.Level || got.Flags != want.Flags || got.Count != want.Count {
				return nil, 0, 0, 0, fmt.Errorf("Comrades character ability %d failed read-back validation", i)
			}
		}
	}
	for i := range model.Party.ElementPower {
		if math.Float32bits(verified.Party.ElementPower[i]) != math.Float32bits(model.Party.ElementPower[i]) {
			return nil, 0, 0, 0, fmt.Errorf("element-power slot %d failed read-back validation", i)
		}
	}
	if len(verified.Inventory) != len(model.Inventory) {
		return nil, 0, 0, 0, errors.New("inventory count changed after edit")
	}
	for i := range model.Inventory {
		if verified.Inventory[i].FixID != model.Inventory[i].FixID || verified.Inventory[i].Amount != model.Inventory[i].Amount {
			return nil, 0, 0, 0, fmt.Errorf("inventory slot %d failed read-back validation", i)
		}
	}
	if len(verified.Equipment) != len(model.Equipment) {
		return nil, 0, 0, 0, errors.New("equipment master count changed after edit")
	}
	for i := range model.Equipment {
		want, got := model.Equipment[i], verified.Equipment[i]
		if got.FixID != want.FixID || got.Exists != want.Exists {
			return nil, 0, 0, 0, fmt.Errorf("equipment master record %d failed ownership read-back validation", i)
		}
		if model.GameMode == "Comrades" && (want.Category == "Weapons" || want.Category == "Accessories") {
			if got.NameID != want.NameID || got.Type != want.Type || got.EquipmentOwner != want.EquipmentOwner || got.EquipmentBank != want.EquipmentBank || got.Rank != want.Rank || got.Strength != want.Strength || got.Vitality != want.Vitality || got.Critical != want.Critical || got.RecoverMP != want.RecoverMP || got.SlotCount != want.SlotCount || got.Abilities != want.Abilities || got.ResidentAbility != want.ResidentAbility || got.StatusAdjust != want.StatusAdjust || got.RemodelFailCount != want.RemodelFailCount {
				return nil, 0, 0, 0, fmt.Errorf("Comrades equipment record %d failed detailed read-back validation", i)
			}
		}
	}
	for i := range model.Equipped {
		want := model.Equipped[i]
		got := verified.Equipped[i]
		if got.Character != want.Character || got.SaveIndex != want.SaveIndex || got.Kind != want.Kind || got.SlotIndex != want.SlotIndex || got.FixID != want.FixID || got.Type != want.Type || got.Category != want.Category || got.BankNumber != want.BankNumber {
			return nil, 0, 0, 0, fmt.Errorf("equipped slot %d failed read-back validation", i)
		}
		if want.FixID != 0 && want.BankNumber != ^uint32(0) {
			master := findMasterRecord(verified, masterCategoryForTuple(want.Kind, want.Category), int(want.BankNumber))
			charIndex := want.SaveIndex
			var expected [8]byte
			binary.LittleEndian.PutUint32(expected[0:4], charIndex)
			binary.LittleEndian.PutUint32(expected[4:8], uint32(want.SlotIndex-1))
			if master == nil || !master.Exists || master.EquipLinkRaw != expected {
				return nil, 0, 0, 0, fmt.Errorf("equipped slot %d master ownership/link failed read-back validation", i)
			}
		}
	}
	if len(verified.Attire) != len(model.Attire) {
		return nil, 0, 0, 0, errors.New("attire slot count changed after edit")
	}
	for i := range model.Attire {
		want := model.Attire[i]
		got := verified.Attire[i]
		if got.Character != want.Character || got.SaveIndex != want.SaveIndex || got.FixID != want.FixID || got.Type != want.Type || got.BankNumber != want.BankNumber {
			return nil, 0, 0, 0, fmt.Errorf("attire slot %d failed read-back validation", i)
		}
		if want.FixID != 0 && want.BankNumber != ^uint32(0) {
			master := findClothRecord(verified, int(want.BankNumber))
			charIndex := want.SaveIndex
			if master == nil || !master.Exists || master.Equipment != int32(charIndex) || master.EquipmentBankNumber != 0 {
				return nil, 0, 0, 0, fmt.Errorf("attire slot %d master ownership/link failed read-back validation", i)
			}
		}
	}
	return out, changed, invChanges, eqChanges, nil
}

func saveEditedModel(inputPath string, input []byte, model *SaveModel, general GeneralEdits) (*EditedSaveResult, error) {
	output, changed, invChanges, eqChanges, err := applyModelEdits(input, model, general)
	if err != nil {
		return nil, err
	}
	workspacePath, err := createForgeWorkspace(inputPath)
	if err != nil {
		return nil, err
	}
	ext := filepath.Ext(inputPath)
	baseStem := filepath.Base(trimWorkflowSuffixes(strings.TrimSuffix(inputPath, ext)))
	backupPath := filepath.Join(workspacePath, baseStem+".backup"+ext)
	outputPath := filepath.Join(workspacePath, baseStem+".edited"+ext)
	if err := writeFileExclusive(backupPath, input, 0o644); err != nil {
		return nil, fmt.Errorf("write backup: %w", err)
	}
	if err := writeFileExclusive(outputPath, output, 0o644); err != nil {
		return nil, fmt.Errorf("write edited copy: %w", err)
	}
	result := &EditedSaveResult{WorkspacePath: workspacePath, OutputPath: outputPath, BackupPath: backupPath, ChangedBytes: changed, InventoryChanges: invChanges, EquipmentChanges: eqChanges}
	sourceMeta := inputPath + metadataSuffix
	if _, statErr := os.Stat(sourceMeta); statErr == nil {
		if _, metaErr := readMetadata(sourceMeta, input); metaErr != nil {
			result.MetadataWarning = "A sidecar exists but failed validation and was not copied: " + metaErr.Error()
		} else {
			b, readErr := os.ReadFile(sourceMeta)
			if readErr != nil {
				result.MetadataWarning = "Edited plaintext is valid, but the source sidecar could not be read: " + readErr.Error()
			} else {
				result.MetadataPath = outputPath + metadataSuffix
				if err := writeFileExclusive(result.MetadataPath, b, 0o600); err != nil {
					result.MetadataWarning = "Edited plaintext is valid, but the sidecar could not be copied: " + err.Error()
					result.MetadataPath = ""
				} else {
					result.MetadataCopied = true
				}
			}
		}
	} else if !os.IsNotExist(statErr) {
		result.MetadataWarning = "Could not inspect sidecar: " + statErr.Error()
	} else {
		result.MetadataWarning = "No .ffxvmeta.json sidecar was present. The edited plaintext is valid; built-in Encrypt requires a matching sidecar."
	}
	h := sha256.Sum256(output)
	result.SHA256 = hex.EncodeToString(h[:])
	return result, nil
}

func forgeOutputRoot(inputPath string) string {
	dir := filepath.Dir(inputPath)
	for probe := dir; ; {
		if strings.EqualFold(filepath.Base(probe), "Forge_Output") {
			return probe
		}
		parent := filepath.Dir(probe)
		if parent == probe {
			break
		}
		probe = parent
	}
	return filepath.Join(dir, "Forge_Output")
}

func createForgeWorkspace(inputPath string) (string, error) {
	root := forgeOutputRoot(inputPath)
	if err := os.MkdirAll(root, 0o755); err != nil {
		return "", fmt.Errorf("create Forge_Output folder: %w", err)
	}
	stamp := time.Now().Format("20060102-150405")
	for n := 1; n <= 10000; n++ {
		name := stamp
		if n > 1 {
			name = fmt.Sprintf("%s_%d", stamp, n)
		}
		candidate := filepath.Join(root, name)
		err := os.Mkdir(candidate, 0o755)
		if err == nil {
			return candidate, nil
		}
		if !os.IsExist(err) {
			return "", fmt.Errorf("create output workspace: %w", err)
		}
	}
	return "", errors.New("could not create a unique Forge_Output workspace")
}

func uniqueVariantPathV2(inputPath, suffix string) (string, error) {
	ext := filepath.Ext(inputPath)
	stem := trimWorkflowSuffixes(strings.TrimSuffix(inputPath, ext))
	for n := 1; n <= 10000; n++ {
		candidate := stem + suffix + ext
		if n > 1 {
			candidate = fmt.Sprintf("%s%s_%d%s", stem, suffix, n, ext)
		}
		paths := []string{candidate}
		if suffix == ".edited" {
			paths = append(paths, candidate+metadataSuffix)
		}
		ok := true
		for _, p := range paths {
			_, e := os.Stat(p)
			if e == nil {
				ok = false
				break
			}
			if !os.IsNotExist(e) {
				return "", e
			}
		}
		if ok {
			return candidate, nil
		}
	}
	return "", errors.New("could not find unused output path")
}

func stageComradesWeaponMaxCore(model *SaveModel, bank int) (*EquipmentRecord, error) {
	if model == nil || model.GameMode != "Comrades" {
		return nil, errors.New("load a Comrades gameplay0 save first")
	}
	r := findMasterRecord(model, "Weapons", bank)
	if r == nil || r.FixID == 0 || isPlaceholderEquipment(r.FixID) {
		return nil, errors.New("selected Comrades weapon record is invalid")
	}
	r.Exists = true
	if r.Rank < 99 {
		r.Rank = 99
	}
	r.Strength = comradesWeaponAttackMax
	r.Vitality = comradesWeaponVitalityMax
	r.Critical = comradesWeaponCriticalMax
	return r, nil
}

func stageComradesAllWeaponsMaxCore(model *SaveModel) (int, error) {
	if model == nil || model.GameMode != "Comrades" {
		return 0, errors.New("load a Comrades gameplay0 save first")
	}
	n := 0
	for i := range model.Equipment {
		r := &model.Equipment[i]
		if r.Category != "Weapons" || r.FixID == 0 || isPlaceholderEquipment(r.FixID) {
			continue
		}
		r.Exists = true
		if r.Rank < 99 {
			r.Rank = 99
		}
		r.Strength = comradesWeaponAttackMax
		r.Vitality = comradesWeaponVitalityMax
		r.Critical = comradesWeaponCriticalMax
		n++
	}
	return n, nil
}

func stageComradesWeaponResidentPreset(model *SaveModel, bank int, p ComradesResidentPreset) (*EquipmentRecord, error) {
	if model == nil || model.GameMode != "Comrades" {
		return nil, errors.New("load a Comrades gameplay0 save first")
	}
	valid := false
	for _, q := range comradesResidentPresets {
		if q.FixID == p.FixID && q.Bank == p.Bank {
			valid = true
			break
		}
	}
	if !valid {
		return nil, errors.New("resident/passive pair is not a verified Comrades preset")
	}
	r := findMasterRecord(model, "Weapons", bank)
	if r == nil || r.FixID == 0 || isPlaceholderEquipment(r.FixID) {
		return nil, errors.New("selected Comrades weapon record is invalid")
	}
	r.ResidentAbility = AbilityLink{FixID: p.FixID, BankNumber: p.Bank}
	return r, nil
}

func stageComradesRoyalSigilUnlock(model *SaveModel, entry ComradesSigilCatalogEntry) (*EquipmentRecord, error) {
	if model == nil || model.GameMode != "Comrades" {
		return nil, errors.New("load a Comrades gameplay0 save first")
	}
	r := findMasterRecord(model, "Accessories", entry.Bank)
	if r == nil {
		return nil, fmt.Errorf("Royal Sigil target bank %d is not present", entry.Bank)
	}
	if r.FixID != entry.FixID {
		return nil, errors.New("Royal Sigil synthesis is disabled until an in-game verified initialized record is available")
	}
	r.Exists = true
	return r, nil
}

func stageComradesAllRoyalSigils(model *SaveModel) (int, error) {
	n := 0
	for _, e := range comradesSigilCatalog {
		if _, err := stageComradesRoyalSigilUnlock(model, e); err != nil {
			return n, err
		}
		n++
	}
	return n, nil
}
