package main

import (
	"encoding/binary"
	"fmt"
)

func comradesGameplayProgressSummary(data []byte, model *SaveModel) string {
	if model == nil || model.GameMode != "Comrades" || len(data) == 0 {
		return "Load Comrades gameplay0 for quest/chocobo progress."
	}
	questRecords := 0
	chocoboCount := uint32(0)
	lesta := false
	if qt := schemaTypeByName(model.Types, "Black.Save.Quest.SaveQuestGameInformationStruct"); qt != nil {
		questRecords = len(findMarkers(data, qt.Hash, model.SchemaOffset))
	}
	if ct := schemaTypeByName(model.Types, "Black.Save.Multiplay.SaveChocoboDataStruct"); ct != nil {
		ms := findMarkers(data, ct.Hash, model.SchemaOffset)
		if len(ms) == 1 && ms[0]+12 <= model.SchemaOffset {
			chocoboCount = binary.LittleEndian.Uint32(data[ms[0]+8 : ms[0]+12])
		}
	}
	if pt := schemaTypeByName(model.Types, "Black.Save.Multiplay.SavePlantMapDataStruct"); pt != nil {
		ms := findMarkers(data, pt.Hash, model.SchemaOffset)
		if len(ms) == 1 && ms[0]+9 <= model.SchemaOffset {
			lesta = data[ms[0]+8]&1 != 0
		}
	}
	return fmt.Sprintf("Quest records: %d  |  Registered chocobos: %d  |  Lestallum plant-map completion: %t\r\nRegistered chocobo scalar stats are editable; quest flags and empty/unregistered chocobo slots remain view-only until their unlock semantics are verified.", questRecords, chocoboCount, lesta)
}

func knownSigilItemFixIDs() []uint32 { return []uint32{0x0105C532, 0x01064770} }
func addKnownComradesSigilItems(model *SaveModel) (int, error) {
	if model == nil || model.GameMode != "Comrades" {
		return 0, fmt.Errorf("load a Comrades gameplay0 save first")
	}
	n := 0
	for _, id := range knownSigilItemFixIDs() {
		if _, err := addGameItemToInventory(model, id, 1); err != nil {
			return n, err
		}
		n++
	}
	return n, nil
}
