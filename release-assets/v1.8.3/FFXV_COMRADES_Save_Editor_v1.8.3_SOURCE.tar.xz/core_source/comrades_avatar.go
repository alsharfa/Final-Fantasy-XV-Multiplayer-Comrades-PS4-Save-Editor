package main

import (
	"crypto/sha256"
	"encoding/binary"
	"encoding/hex"
	"errors"
	"fmt"
	"math"
	"os"
)

type ComradesAvatarFile struct {
	Path                                                                                                                                                                                                          string
	SchemaOffset                                                                                                                                                                                                  int
	StatusMarker                                                                                                                                                                                                  int
	AvatarDataMarker                                                                                                                                                                                              int
	HP, HPMax, MP, MPMax                                                                                                                                                                                          uint32
	Level, LevelMax                                                                                                                                                                                               uint32
	Strength, Vitality, Magic, Spirit, Critical                                                                                                                                                                   uint32
	OriginalHP, OriginalHPMax, OriginalMP, OriginalMPMax                                                                                                                                                          uint32
	OriginalLevel                                                                                                                                                                                                 uint32
	OriginalStrength, OriginalVitality, OriginalMagic, OriginalSpirit, OriginalCritical                                                                                                                           uint32
	BaseModelType                                                                                                                                                                                                 uint8
	BaseScale, HeadScale, FaceBlendWeight, FaceBlendWeightMaterial, BodyBlendWeight                                                                                                                               float32
	FaceA, FaceB, Tops, Bottoms, Shoes, Gloves, Hair, Beard, Wear, Eyebrow, Accessory, Eyelash, VoiceType                                                                                                         uint32
	OriginalBaseModelType                                                                                                                                                                                         uint8
	OriginalBaseScale, OriginalHeadScale, OriginalFaceBlendWeight, OriginalFaceBlendWeightMaterial, OriginalBodyBlendWeight                                                                                       float32
	OriginalFaceA, OriginalFaceB, OriginalTops, OriginalBottoms, OriginalShoes, OriginalGloves, OriginalHair, OriginalBeard, OriginalWear, OriginalEyebrow, OriginalAccessory, OriginalEyelash, OriginalVoiceType uint32
	SHA256                                                                                                                                                                                                        string
}

func parseComradesAvatarFile(data []byte, path string) (*ComradesAvatarFile, error) {
	kind, err := detectFFXVPlainKind(data)
	if err != nil {
		return nil, err
	}
	if kind != "Comrades avatar0" {
		return nil, fmt.Errorf("expected Comrades avatar0 plaintext, got %s", kind)
	}
	so, types, err := parseSchema(data)
	if err != nil {
		return nil, err
	}
	st := schemaTypeByName(types, "Black.Save.Player.SaveStatusStruct")
	av := schemaTypeByName(types, "Black.Save.Multiplay.SaveAvatarDataStruct")
	color := schemaTypeByName(types, "Black.Save.Multiplay.SaveAvatarColor")
	if st == nil || av == nil || color == nil {
		return nil, errors.New("Comrades avatar0 schema is incomplete")
	}
	sm := findMarkers(data, st.Hash, so)
	am := findMarkers(data, av.Hash, so)
	if len(sm) != 1 || len(am) != 1 {
		return nil, fmt.Errorf("expected one avatar status/data record, found %d/%d", len(sm), len(am))
	}
	sb := sm[0] + 8
	if sb+167 > so {
		return nil, errors.New("avatar status record is truncated")
	}
	read := func(off int) uint32 { return binary.LittleEndian.Uint32(data[sb+off : sb+off+4]) }
	ab := am[0] + 8
	if ab+81 > so {
		return nil, errors.New("avatar customization record is truncated")
	}
	// Serialized AvatarData is packed: BaseModelType occupies one byte and the
	// following direct scalars begin immediately. Validate that the first nested
	// SaveAvatarColor marker begins at +73 before exposing these offsets.
	var cm [8]byte
	binary.LittleEndian.PutUint64(cm[:], color.Hash)
	if string(data[ab+73:ab+81]) != string(cm[:]) {
		return nil, errors.New("unexpected packed avatar customization layout")
	}
	f32 := func(off int) float32 {
		return math.Float32frombits(binary.LittleEndian.Uint32(data[ab+off : ab+off+4]))
	}
	u32 := func(off int) uint32 { return binary.LittleEndian.Uint32(data[ab+off : ab+off+4]) }
	m := &ComradesAvatarFile{Path: path, SchemaOffset: so, StatusMarker: sm[0], AvatarDataMarker: am[0],
		HP: read(27), HPMax: read(31), MP: read(111), MPMax: read(115), Level: read(135), LevelMax: read(143), Strength: read(147), Vitality: read(151), Magic: read(155), Spirit: read(159), Critical: read(163),
		BaseModelType: data[ab], BaseScale: f32(1), HeadScale: f32(5), FaceA: u32(9), FaceB: u32(13), FaceBlendWeight: f32(17), FaceBlendWeightMaterial: f32(21), BodyBlendWeight: f32(25),
		Tops: u32(29), Bottoms: u32(33), Shoes: u32(37), Gloves: u32(41), Hair: u32(45), Beard: u32(49), Wear: u32(53), Eyebrow: u32(57), Accessory: u32(61), Eyelash: u32(65), VoiceType: u32(69)}
	m.OriginalHP, m.OriginalHPMax, m.OriginalMP, m.OriginalMPMax = m.HP, m.HPMax, m.MP, m.MPMax
	m.OriginalLevel = m.Level
	m.OriginalStrength, m.OriginalVitality, m.OriginalMagic, m.OriginalSpirit, m.OriginalCritical = m.Strength, m.Vitality, m.Magic, m.Spirit, m.Critical
	m.OriginalBaseModelType = m.BaseModelType
	m.OriginalBaseScale, m.OriginalHeadScale = m.BaseScale, m.HeadScale
	m.OriginalFaceBlendWeight, m.OriginalFaceBlendWeightMaterial, m.OriginalBodyBlendWeight = m.FaceBlendWeight, m.FaceBlendWeightMaterial, m.BodyBlendWeight
	m.OriginalFaceA, m.OriginalFaceB = m.FaceA, m.FaceB
	m.OriginalTops, m.OriginalBottoms, m.OriginalShoes, m.OriginalGloves = m.Tops, m.Bottoms, m.Shoes, m.Gloves
	m.OriginalHair, m.OriginalBeard, m.OriginalWear, m.OriginalEyebrow = m.Hair, m.Beard, m.Wear, m.Eyebrow
	m.OriginalAccessory, m.OriginalEyelash, m.OriginalVoiceType = m.Accessory, m.Eyelash, m.VoiceType
	h := sha256.Sum256(data)
	m.SHA256 = hex.EncodeToString(h[:])
	return m, nil
}

func loadComradesAvatarFile(path string) (*ComradesAvatarFile, []byte, string, error) {
	data, clean, err := readRegularFile(path)
	if err != nil {
		return nil, nil, clean, err
	}
	m, err := parseComradesAvatarFile(data, clean)
	if err != nil {
		return nil, nil, clean, err
	}
	return m, data, clean, nil
}

func stageComradesAvatarStatus(m *ComradesAvatarFile, hp, hpMax, mp, mpMax, level, strength, vitality, magicValue, spirit, critical uint32) error {
	if m == nil {
		return errors.New("load a decrypted Comrades avatar0 save first")
	}
	if level < 1 || level > m.LevelMax {
		return fmt.Errorf("level must be 1 through %d", m.LevelMax)
	}
	if hpMax == 0 || hp > hpMax || hpMax > 9999999 {
		return errors.New("HP must be between 0 and Max HP")
	}
	if mpMax == 0 || mp > mpMax || mpMax > 9999999 {
		return errors.New("MP must be between 0 and Max MP")
	}
	for name, v := range map[string]uint32{"Strength": strength, "Vitality": vitality, "Magic": magicValue, "Spirit": spirit, "Critical": critical} {
		if v > 999999 {
			return fmt.Errorf("%s must be 0 through 999,999", name)
		}
	}
	m.HP, m.HPMax, m.MP, m.MPMax = hp, hpMax, mp, mpMax
	m.Level = level
	m.Strength, m.Vitality, m.Magic, m.Spirit, m.Critical = strength, vitality, magicValue, spirit, critical
	return nil
}
func maxComradesAvatarStatus(m *ComradesAvatarFile) error {
	if m == nil {
		return errors.New("load avatar0 first")
	}
	return stageComradesAvatarStatus(m, 99999, 99999, 9999, 9999, m.LevelMax, 9999, 9999, 9999, 9999, 9999)
}
func restoreComradesAvatarStatus(m *ComradesAvatarFile) {
	if m == nil {
		return
	}
	m.HP, m.HPMax, m.MP, m.MPMax = m.OriginalHP, m.OriginalHPMax, m.OriginalMP, m.OriginalMPMax
	m.Level = m.OriginalLevel
	m.Strength, m.Vitality, m.Magic, m.Spirit, m.Critical = m.OriginalStrength, m.OriginalVitality, m.OriginalMagic, m.OriginalSpirit, m.OriginalCritical
}

func copyComradesAvatarAppearance(dst, src *ComradesAvatarFile) error {
	if dst == nil || src == nil {
		return errors.New("load both destination and source avatar0 saves first")
	}
	for name, v := range map[string]float32{"Base scale": src.BaseScale, "Head scale": src.HeadScale, "Face blend": src.FaceBlendWeight, "Material blend": src.FaceBlendWeightMaterial, "Body blend": src.BodyBlendWeight} {
		if float32(math.Abs(float64(v))) > 100 || math.IsNaN(float64(v)) || math.IsInf(float64(v), 0) {
			return fmt.Errorf("source %s value is not a sane finite avatar scale", name)
		}
	}
	dst.BaseModelType = src.BaseModelType
	dst.BaseScale, dst.HeadScale = src.BaseScale, src.HeadScale
	dst.FaceA, dst.FaceB = src.FaceA, src.FaceB
	dst.FaceBlendWeight, dst.FaceBlendWeightMaterial, dst.BodyBlendWeight = src.FaceBlendWeight, src.FaceBlendWeightMaterial, src.BodyBlendWeight
	dst.Tops, dst.Bottoms, dst.Shoes, dst.Gloves = src.Tops, src.Bottoms, src.Shoes, src.Gloves
	dst.Hair, dst.Beard, dst.Wear, dst.Eyebrow = src.Hair, src.Beard, src.Wear, src.Eyebrow
	dst.Accessory, dst.Eyelash, dst.VoiceType = src.Accessory, src.Eyelash, src.VoiceType
	return nil
}

func restoreComradesAvatarAppearance(m *ComradesAvatarFile) {
	if m == nil {
		return
	}
	m.BaseModelType = m.OriginalBaseModelType
	m.BaseScale, m.HeadScale = m.OriginalBaseScale, m.OriginalHeadScale
	m.FaceBlendWeight, m.FaceBlendWeightMaterial, m.BodyBlendWeight = m.OriginalFaceBlendWeight, m.OriginalFaceBlendWeightMaterial, m.OriginalBodyBlendWeight
	m.FaceA, m.FaceB = m.OriginalFaceA, m.OriginalFaceB
	m.Tops, m.Bottoms, m.Shoes, m.Gloves = m.OriginalTops, m.OriginalBottoms, m.OriginalShoes, m.OriginalGloves
	m.Hair, m.Beard, m.Wear, m.Eyebrow = m.OriginalHair, m.OriginalBeard, m.OriginalWear, m.OriginalEyebrow
	m.Accessory, m.Eyelash, m.VoiceType = m.OriginalAccessory, m.OriginalEyelash, m.OriginalVoiceType
}

func applyComradesAvatarEdits(input []byte, m *ComradesAvatarFile) ([]byte, int, error) {
	if m == nil {
		return nil, 0, errors.New("no Comrades avatar0 model loaded")
	}
	out := append([]byte(nil), input...)
	allowed := map[int]bool{}
	write := func(off int, v uint32) {
		binary.LittleEndian.PutUint32(out[off:off+4], v)
		for i := 0; i < 4; i++ {
			allowed[off+i] = true
		}
	}
	if m.Level < 1 || m.Level > m.LevelMax || m.HP > m.HPMax || m.MP > m.MPMax {
		return nil, 0, errors.New("invalid staged avatar0 status")
	}
	b := m.StatusMarker + 8
	write(b+27, m.HP)
	write(b+31, m.HPMax)
	write(b+111, m.MP)
	write(b+115, m.MPMax)
	write(b+135, m.Level)
	write(b+147, m.Strength)
	write(b+151, m.Vitality)
	write(b+155, m.Magic)
	write(b+159, m.Spirit)
	write(b+163, m.Critical)
	ab := m.AvatarDataMarker + 8
	if ab+73 > m.SchemaOffset {
		return nil, 0, errors.New("avatar appearance record is truncated")
	}
	out[ab] = m.BaseModelType
	allowed[ab] = true
	writeF32 := func(off int, v float32) { write(off, math.Float32bits(v)) }
	writeF32(ab+1, m.BaseScale)
	writeF32(ab+5, m.HeadScale)
	write(ab+9, m.FaceA)
	write(ab+13, m.FaceB)
	writeF32(ab+17, m.FaceBlendWeight)
	writeF32(ab+21, m.FaceBlendWeightMaterial)
	writeF32(ab+25, m.BodyBlendWeight)
	write(ab+29, m.Tops)
	write(ab+33, m.Bottoms)
	write(ab+37, m.Shoes)
	write(ab+41, m.Gloves)
	write(ab+45, m.Hair)
	write(ab+49, m.Beard)
	write(ab+53, m.Wear)
	write(ab+57, m.Eyebrow)
	write(ab+61, m.Accessory)
	write(ab+65, m.Eyelash)
	write(ab+69, m.VoiceType)
	changed := 0
	for i := range input {
		if input[i] != out[i] {
			changed++
			if !allowed[i] {
				return nil, 0, fmt.Errorf("unexpected avatar0 byte change at 0x%X", i)
			}
		}
	}
	if !equalBytes(out[len(out)-footerSize:], input[len(input)-footerSize:]) {
		return nil, 0, errors.New("avatar0 edit changed FFXV footer")
	}
	v, err := parseComradesAvatarFile(out, m.Path)
	if err != nil {
		return nil, 0, fmt.Errorf("edited avatar0 validation failed: %w", err)
	}
	if v.HP != m.HP || v.HPMax != m.HPMax || v.MP != m.MP || v.MPMax != m.MPMax || v.Level != m.Level || v.Strength != m.Strength || v.Vitality != m.Vitality || v.Magic != m.Magic || v.Spirit != m.Spirit || v.Critical != m.Critical {
		return nil, 0, errors.New("avatar0 status failed read-back validation")
	}
	if v.BaseModelType != m.BaseModelType || v.BaseScale != m.BaseScale || v.HeadScale != m.HeadScale || v.FaceA != m.FaceA || v.FaceB != m.FaceB || v.FaceBlendWeight != m.FaceBlendWeight || v.FaceBlendWeightMaterial != m.FaceBlendWeightMaterial || v.BodyBlendWeight != m.BodyBlendWeight || v.Tops != m.Tops || v.Bottoms != m.Bottoms || v.Shoes != m.Shoes || v.Gloves != m.Gloves || v.Hair != m.Hair || v.Beard != m.Beard || v.Wear != m.Wear || v.Eyebrow != m.Eyebrow || v.Accessory != m.Accessory || v.Eyelash != m.Eyelash || v.VoiceType != m.VoiceType {
		return nil, 0, errors.New("avatar0 appearance failed read-back validation")
	}
	return out, changed, nil
}

func saveEditedComradesAvatar(inputPath string, input []byte, m *ComradesAvatarFile) (*EditedSaveResult, error) {
	out, changed, err := applyComradesAvatarEdits(input, m)
	if err != nil {
		return nil, err
	}
	backup, err := uniqueVariantPathV2(inputPath, ".backup")
	if err != nil {
		return nil, err
	}
	output, err := uniqueVariantPathV2(inputPath, ".edited")
	if err != nil {
		return nil, err
	}
	if err = writeFileExclusive(backup, input, 0o644); err != nil {
		return nil, err
	}
	if err = writeFileExclusive(output, out, 0o644); err != nil {
		return nil, err
	}
	r := &EditedSaveResult{OutputPath: output, BackupPath: backup, ChangedBytes: changed}
	sourceMeta := inputPath + metadataSuffix
	if _, e := os.Stat(sourceMeta); e == nil {
		if _, me := readMetadata(sourceMeta, input); me == nil {
			b, re := os.ReadFile(sourceMeta)
			if re != nil {
				return nil, re
			}
			r.MetadataPath = output + metadataSuffix
			if we := writeFileExclusive(r.MetadataPath, b, 0o600); we != nil {
				return nil, we
			}
			r.MetadataCopied = true
		} else {
			r.MetadataWarning = "Matching sidecar exists but failed validation; it was not copied."
		}
	} else if os.IsNotExist(e) {
		r.MetadataWarning = "No matching .ffxvmeta.json sidecar was present; Encrypt requires one created by Decrypt."
	}
	h := sha256.Sum256(out)
	r.SHA256 = hex.EncodeToString(h[:])
	return r, nil
}
