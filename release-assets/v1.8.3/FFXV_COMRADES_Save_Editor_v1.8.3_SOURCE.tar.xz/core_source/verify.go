package main

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
)

type verificationResult struct {
	Mode    string
	SHA256  string
	Size    int
	Details string
}

func verifyFile(inputPath string) (*verificationResult, error) {
	input, inputPath, err := readRegularFile(inputPath)
	if err != nil {
		return nil, err
	}
	h := sha256.Sum256(input)
	result := &verificationResult{SHA256: hex.EncodeToString(h[:]), Size: len(input)}
	if kind, plainErr := detectFFXVPlainKind(input); plainErr == nil {
		result.Mode = "Decrypted " + kind + " plaintext"
		if kind == "Main-game gameplay0" || kind == "Comrades gameplay0" {
			if model, err := parseSaveModelBytes(input, inputPath); err == nil {
				result.Mode += " (schema-aware)"
				result.Details = fmt.Sprintf("EBB schema parsed: %d types; %d inventory slots; %d equipment records. Mode: %s.", len(model.Types), len(model.Inventory), len(model.Equipment), model.GameMode)
			} else {
				result.Details = "Plaintext EBB structure is valid, but the gameplay editor rejected some structure: " + err.Error()
			}
		} else {
			_, types, _ := parseSchema(input)
			result.Details = fmt.Sprintf("EBB schema parsed: %d types. Auxiliary Comrades/FFXV save files can be decrypted and re-encrypted with a matching sidecar.", len(types))
		}
		meta := inputPath + metadataSuffix
		if first, e := readMetadata(meta, input); e == nil {
			cryptoPlain := canonicalizePlainForCrypto(input)
			intermediate, e1 := encodeGameplayChain(cryptoPlain, first)
			if e1 != nil {
				return nil, e1
			}
			encrypted, e2 := encryptOuterLayer(intermediate)
			if e2 != nil {
				return nil, e2
			}
			backInter, e3 := decryptOuterLayer(encrypted)
			if e3 != nil {
				return nil, e3
			}
			back, recovered, e4 := decodeGameplayChain(backInter)
			if e4 != nil {
				return nil, e4
			}
			if recovered != first || !equalBytes(back, cryptoPlain) {
				return nil, fmt.Errorf("plaintext sidecar round-trip failed")
			}
			result.Mode += " + valid encryption sidecar"
			result.Details += " Full encrypt/decrypt round-trip passed."
		}
		return result, nil
	}

	intermediate, err := decryptOuterLayer(input)
	if err != nil {
		return nil, fmt.Errorf("not valid plaintext and encrypted decode failed: %w", err)
	}
	plain, first, err := decodeGameplayChain(intermediate)
	if err != nil {
		return nil, err
	}
	kind, err := detectFFXVPlainKind(plain)
	if err != nil {
		return nil, err
	}
	encoded, err := encodeGameplayChain(plain, first)
	if err != nil {
		return nil, err
	}
	round, err := encryptOuterLayer(encoded)
	if err != nil {
		return nil, err
	}
	if !equalBytes(round, input) {
		return nil, fmt.Errorf("encrypted round-trip mismatch")
	}
	result.Mode = "Encrypted FFXV PS4 " + kind + " save"
	result.Details = "AES/tweak/shuffle/FFXV-chain decrypt and byte-for-byte re-encrypt round-trip passed."
	return result, nil
}
