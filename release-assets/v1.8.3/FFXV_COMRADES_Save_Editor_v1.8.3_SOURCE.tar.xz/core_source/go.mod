module ffxv-save-editor

go 1.23
