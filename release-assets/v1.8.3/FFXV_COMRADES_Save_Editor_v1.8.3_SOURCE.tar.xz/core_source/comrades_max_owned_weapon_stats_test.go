package main

import (
	"os"
	"testing"
)

// Mirrors the WPF v2.8 MAX TESTED-RANGE STATS — OWNED WEAPONS profile. Only
// bounded direct combat values are raised; raw status_adjust, rank, MP
// recovery, remodel state and ability identity are preserved.
func TestMaxAllOwnedWeaponStatsProfileRoundTrips(t *testing.T) {
	const path = "testdata/gameplay0_decrypted(2).save"
	plain, err := os.ReadFile(path)
	if os.IsNotExist(err) {
		t.Skip("uploaded Comrades sample not present")
	}
	if err != nil {
		t.Fatal(err)
	}
	m, err := parseSaveModelBytes(plain, path)
	if err != nil {
		t.Fatal(err)
	}

	type snapshot struct {
		owned                        bool
		fixID                        uint32
		rank                         int32
		recover                      int32
		slot                         int32
		remodel                      int32
		ability1, ability2, resident AbilityLink
		status                       [19]int32
	}
	before := map[int]snapshot{}
	touched := 0
	for i := range m.Equipment {
		w := &m.Equipment[i]
		if w.Category != "Weapons" || w.FixID == 0 || isPlaceholderEquipment(w.FixID) {
			continue
		}
		before[w.CategoryIndex] = snapshot{
			owned: w.Exists, fixID: w.FixID, rank: w.Rank, recover: w.RecoverMP,
			slot: w.SlotCount, remodel: w.RemodelFailCount,
			ability1: w.Abilities[0], ability2: w.Abilities[1], resident: w.ResidentAbility,
			status: w.StatusAdjust,
		}
		if !w.Exists {
			continue
		}
		slot := w.SlotCount
		if slot > comradesWeaponSlotMax {
			slot = comradesWeaponSlotMax
		}
		if _, err := stageComradesWeaponCustomStats(m, w.CategoryIndex, comradesWeaponEditableStats{
			Rank: w.Rank, Strength: comradesWeaponAttackMax, Vitality: comradesWeaponVitalityMax,
			Critical: comradesWeaponCriticalMax, RecoverMP: w.RecoverMP, SlotCount: slot,
			RemodelFailCount: w.RemodelFailCount,
		}); err != nil {
			t.Fatalf("bank %d core stats: %v", w.CategoryIndex, err)
		}
		touched++
	}
	if touched == 0 {
		t.Fatal("sample has no owned initialized weapons")
	}

	g := GeneralEdits{ControlledCharacter: m.Party.ControlledCharacter, Chapter: m.Party.Chapter, Gil: m.Party.Gil, ArenaMedals: m.Party.ArenaMedals, OracleCoins: m.Party.OracleCoins, AbilityPoints: m.Party.AbilityPoints}
	out, _, _, _, err := applyModelEdits(plain, m, g)
	if err != nil {
		t.Fatal(err)
	}
	got, err := parseSaveModelBytes(out, "max-owned-safe-roundtrip.decrypted.save")
	if err != nil {
		t.Fatal(err)
	}

	verified := 0
	for i := range got.Equipment {
		w := &got.Equipment[i]
		if w.Category != "Weapons" || w.FixID == 0 || isPlaceholderEquipment(w.FixID) {
			continue
		}
		old, ok := before[w.CategoryIndex]
		if !ok {
			continue
		}
		if w.FixID != old.fixID || w.Abilities[0] != old.ability1 || w.Abilities[1] != old.ability2 || w.ResidentAbility != old.resident {
			t.Fatalf("bank %d identity/ability link changed", w.CategoryIndex)
		}
		if !old.owned {
			if w.Exists {
				t.Fatalf("bank %d was unowned but became owned", w.CategoryIndex)
			}
			continue
		}
		if !w.Exists || w.Strength != comradesWeaponAttackMax || w.Vitality != comradesWeaponVitalityMax || w.Critical != comradesWeaponCriticalMax {
			t.Fatalf("bank %d safe max did not survive: %+v", w.CategoryIndex, w)
		}
		if w.Rank != old.rank || w.RecoverMP != old.recover || w.RemodelFailCount != old.remodel || w.StatusAdjust != old.status {
			t.Fatalf("bank %d unsafe/raw field changed", w.CategoryIndex)
		}
		wantSlot := old.slot
		if wantSlot > comradesWeaponSlotMax {
			wantSlot = comradesWeaponSlotMax
		}
		if w.SlotCount != wantSlot {
			t.Fatalf("bank %d slot=%d want %d", w.CategoryIndex, w.SlotCount, wantSlot)
		}
		verified++
	}
	if verified != touched {
		t.Fatalf("verified %d owned weapons, touched %d", verified, touched)
	}
}

func TestWeaponEditorAllowsUnlockedAttackThrough99999(t *testing.T) {
	m := &SaveModel{GameMode: "Comrades", Equipment: []EquipmentRecord{{Category: "Weapons", CategoryIndex: 1, FixID: 0x01000001, OriginalRank: 1}}}
	_, err := stageComradesWeaponCustomStats(m, 1, comradesWeaponEditableStats{Rank: 1, Strength: 99999, Vitality: 1, Critical: 1, RecoverMP: 0, SlotCount: 1})
	if err != nil {
		t.Fatalf("99,999 Attack should be accepted: %v", err)
	}
	_, err = stageComradesWeaponCustomStats(m, 1, comradesWeaponEditableStats{Rank: 1, Strength: 100000, Vitality: 1, Critical: 1, RecoverMP: 0, SlotCount: 1})
	if err == nil {
		t.Fatal("100,000 Attack must be rejected")
	}
	_, err = stageComradesWeaponCustomStats(m, 1, comradesWeaponEditableStats{Rank: 1, Strength: 999, Vitality: 999, Critical: 100, RecoverMP: 0, SlotCount: 4})
	if err == nil {
		t.Fatal("slot count 4 must be rejected")
	}
}

func TestUnsafeV262ProfileDetector(t *testing.T) {
	status := [19]int32{}
	for i := range status {
		status[i] = 9999
	}
	m := &SaveModel{GameMode: "Comrades", Equipment: []EquipmentRecord{
		{Category: "Weapons", CategoryIndex: 1, FixID: 0x01000001, Exists: true, Strength: 9999, Vitality: 9999, Critical: 9999, RecoverMP: 9999, SlotCount: 4, StatusAdjust: status},
		{Category: "Weapons", CategoryIndex: 2, FixID: 0x01000002, Exists: true, Strength: comradesWeaponAttackMax, Vitality: comradesWeaponVitalityMax, Critical: comradesWeaponCriticalMax, RecoverMP: 0, SlotCount: 2},
	}}
	if got := countUnsafeV262MaxProfiles(m); got != 1 {
		t.Fatalf("unsafe v2.6.2 profiles=%d, want 1", got)
	}
}

func TestUnsafeV262ProfileDetectorCatchesPartiallyRepairedRawBlock(t *testing.T) {
	status := [19]int32{}
	for i := range status {
		status[i] = 9999
	}
	m := &SaveModel{GameMode: "Comrades", Equipment: []EquipmentRecord{
		{Category: "Weapons", CategoryIndex: 3, FixID: 0x01000003, Exists: true, Strength: 999, Vitality: 999, Critical: 100, RecoverMP: 0, SlotCount: 2, StatusAdjust: status},
	}}
	if got := countUnsafeV262MaxProfiles(m); got != 1 {
		t.Fatalf("partially repaired unsafe raw block count=%d, want 1", got)
	}
}

func TestWeaponEditorAllowsBoundedManualMPRecoveryAndRawStatus(t *testing.T) {
	status := [19]int32{}
	status[0] = 12
	status[4] = -3
	m := &SaveModel{GameMode: "Comrades", Equipment: []EquipmentRecord{{
		Category: "Weapons", CategoryIndex: 1, FixID: 0x01000001, OriginalRank: 1, Rank: 1,
		Strength: 100, Vitality: 20, Critical: 5, RecoverMP: 7, SlotCount: 1, StatusAdjust: status,
	}}}
	if _, err := stageComradesWeaponCustomStats(m, 1, comradesWeaponEditableStats{Rank: 1, Strength: 101, Vitality: 20, Critical: 5, RecoverMP: 8, SlotCount: 1}); err != nil {
		t.Fatalf("bounded MP Recovery change rejected: %v", err)
	}
	if m.Equipment[0].RecoverMP != 8 {
		t.Fatalf("MP Recovery=%d, want 8", m.Equipment[0].RecoverMP)
	}
	changed := status
	changed[0]++
	if _, err := stageComradesWeaponAdvanced(m, 1, comradesWeaponAdvancedEdits{
		Ability1: m.Equipment[0].Abilities[0].FixID, Ability2: m.Equipment[0].Abilities[1].FixID,
		ResidentAbility: m.Equipment[0].ResidentAbility.FixID, ResidentAbilityBank: m.Equipment[0].ResidentAbility.BankNumber,
		StatusAdjust: changed,
	}); err != nil {
		t.Fatalf("bounded raw status_adjust change rejected: %v", err)
	}
	if m.Equipment[0].StatusAdjust != changed {
		t.Fatalf("raw status_adjust not staged: %+v", m.Equipment[0].StatusAdjust)
	}
}

func TestWeaponEditorBlocksKnownAll9999RawPattern(t *testing.T) {
	status := [19]int32{}
	for i := range status {
		status[i] = 9999
	}
	m := &SaveModel{GameMode: "Comrades", Equipment: []EquipmentRecord{{
		Category: "Weapons", CategoryIndex: 1, FixID: 0x01000001,
	}}}
	if _, err := stageComradesWeaponAdvanced(m, 1, comradesWeaponAdvancedEdits{StatusAdjust: status}); err == nil {
		t.Fatal("known all-9999 raw status profile must be rejected")
	}
}
