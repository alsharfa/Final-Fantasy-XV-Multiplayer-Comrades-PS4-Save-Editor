package main

import (
	"errors"
	"fmt"
	"strings"
)

const (
	collectionTreasures   = "Treasures"
	collectionBarter      = "Barter Items"
	collectionPhrasebooks = "Phrasebooks"
	collectionAvatar      = "Avatar"
	collectionClothing    = "Clothing"
	collectionKeyItems    = "Key Items"
)

var comradesCollectionKinds = []string{
	collectionTreasures,
	collectionBarter,
	collectionPhrasebooks,
	collectionAvatar,
	collectionClothing,
	collectionKeyItems,
}

// These are the 27 documented COMRADES key-item records. Keeping this list
// explicit prevents the editor from bulk-inserting unrelated EVENT records,
// quest internals, or the MP_ITEM_BUFF_* pseudo-items that share the same
// serialized inventory array.

// These 52 records are the non-weapon rewards offered by the COMRADES barter
// shops covered by the embedded catalog: Kimya's Post o' Potions, INGEM,
// Cauthess Depot Item Trading Post, and Kurt's Item Trading Post. Weapon
// barter rewards are intentionally excluded because weapon ownership uses a
// separate fixed-record save structure and must be handled by the Weapons UI.
var comradesBarterItemFixIDs = []uint32{
	// Kimya's Post o' Potions.
	0x01066173, // Fire Elemental Stone
	0x01066174, // Ice Elemental Stone
	0x01066175, // Lightning Elemental Stone
	0x01066765, // Attack Boost (Level 1)
	0x01066766, // Attack Boost (Level 2)
	0x01066769, // Attack Boost (Level 5)
	0x0106676C, // Defense Boost (Level 1)
	0x0106676D, // Defense Boost (Level 2)
	0x01066770, // Defense Boost (Level 5)
	0x01066773, // HP Boost (Level 1)
	0x01066774, // HP Boost (Level 2)
	0x01066776, // HP Boost (Level 4)
	0x0106677A, // Poisonproof
	0x0106677B, // Death-Defying
	0x0106677C, // Immune
	0x0106677D, // Resistance Boost
	0x0106675B, // Perception Boost (Level 1)
	0x0106675C, // Perception Boost (Level 2)
	0x0106675D, // Perception Boost (Level 3)
	0x01066760, // Crafting Boost (Level 1)
	0x01066761, // Crafting Boost (Level 2)
	0x01066762, // Crafting Boost (Level 3)

	// INGEM.
	0x01075281, // Biggs's Ensemble
	0x01075282, // Wedge's Ensemble
	0x01075289, // Café Manager's Ensemble
	0x0107528A, // Coctura's Ensemble
	0x01075288, // Glauca's Ensemble
	0x01075E61, // Warrior's Armor
	0x01075E62, // Street Attire
	0x0107528B, // Omega Visor
	0x0107528C, // Item Token
	0x0105C4E4, // Behemoth Tears
	0x0105C4F2, // Treant Trunk (COMRADES record)
	0x0105C492, // Gorgeous Pelt
	0x0105EDC1, // Cactuar Nectar
	0x0106655D, // Elemental Shard

	// Cauthess Depot Item Trading Post.
	0x0105B829, // Men's Hair Monthly, Vol. 5
	0x0105B82B, // Women's Hair Monthly, Vol. 2
	0x0105B61E, // Beat That Mug, Vol. 9
	0x0105B61F, // Beat That Mug, Vol. 10
	0x0105B64D, // Coernix Uniform
	0x0105B657, // Chino Pants
	0x0105B660, // Standard Boots
	0x0105B66D, // Chocobo Suit
	0x0106154C, // The Casual Conversationalist, Vol. 14
	0x0106476E, // Unaddressed Letter

	// Kurt's Item Trading Post.
	0x0105C52C, // Grenade Fragment
	0x0105C52E, // Cryonade Fragment
	0x0105C530, // Galvanade Fragment
	0x0105C4E1, // Shield Spike (COMRADES record)
	0x0105EDB8, // Treant Sap
	0x0105C528, // Octolegs
}

func isComradesBarterItemFixID(id uint32) bool {
	for _, barterID := range comradesBarterItemFixIDs {
		if id == barterID {
			return true
		}
	}
	return false
}

var comradesKeyItemFixIDs = []uint32{
	0x010699E8, // Pure Adamantite
	0x0106498D, // Crown City Smartphone (locked)
	0x0106498E, // Crown City Smartphone (unlocked)
	0x0106476E, // Unaddressed Letter
	0x01055A59, // Kingsglaive Crest
	0x01055A5A, // Well-used Daggers - Galahd
	0x01062E86, // Well-used Daggers - Insomnia
	0x01062E87, // Well-used Daggers - Lestallum
	0x01062E88, // Well-used Daggers - Altissia
	0x01062E89, // Well-used Daggers - Tenebrae
	0x01062E8A, // Well-used Daggers - Niflheim
	0x01055A5B, // Radio Transceiver
	0x010580FA, // Publicity Contract
	0x0106155C, // Hunting License
	0x0106155D, // Coernix Oil Key
	0x01064770, // Crownsguard Sigil
	0x010639E2, // Arms Schematics
	0x01063A15, // Fashion Sketchbook
	0x01069916, // Engine Schematics
	0x0105C532, // The Bladekeeper's Sigil
	0x01066173, // Fire Elemental Stone
	0x01066174, // Ice Elemental Stone
	0x01066175, // Lightning Elemental Stone
	0x0106655D, // Elemental Shard
	0x010699EA, // Letter to Ezma
	0x0107528C, // Item Token
	0x01075378, // Gold Item Token
}

func isComradesCollectionEntry(kind string, e ItemCatalogEntry) bool {
	label := gameItemLabel(e.FixID)
	switch kind {
	case collectionTreasures:
		// The common database also contains hundreds of main-game/Episode
		// treasure records. MULTI marks the COMRADES/multiplayer material set.
		return e.GameCategory == "TREASURE" && strings.Contains(label, "MULTI")
	case collectionBarter:
		return isComradesBarterItemFixID(e.FixID)
	case collectionPhrasebooks:
		return e.GameCategory == "BATTLE" && strings.HasPrefix(label, "CHAT_")
	case collectionAvatar:
		if e.GameCategory != "CAR" {
			return false
		}
		return strings.HasPrefix(label, "AVATAR_FACEPAINT_") ||
			strings.HasPrefix(label, "AVATAR_BODYPAINT_") ||
			strings.HasPrefix(label, "AVATAR_HAIRMEN_") ||
			strings.HasPrefix(label, "AVATAR_HAIRWOMEN_") ||
			strings.HasPrefix(label, "AVATAR_FACE_") ||
			strings.HasPrefix(label, "AVATAR_EYEBROW_")
	case collectionClothing:
		if e.GameCategory != "LEISURE" {
			return false
		}
		return strings.HasPrefix(label, "AVATAR_CLOTH") || strings.HasPrefix(label, "AVATAR_ACCESSORY_")
	case collectionKeyItems:
		for _, id := range comradesKeyItemFixIDs {
			if e.FixID == id {
				return e.GameCategory == "EVENT"
			}
		}
		return false
	default:
		return false
	}
}

func comradesCollectionEntries(kind string) []ItemCatalogEntry {
	out := make([]ItemCatalogEntry, 0)
	for _, e := range allGameItemCatalog {
		if isComradesCollectionEntry(kind, e) {
			out = append(out, e)
		}
	}
	return out
}

func comradesCollectionRecommendedQuantity(kind string) int32 {
	if kind == collectionTreasures {
		return 99
	}
	if kind == collectionBarter {
		return 1
	}
	// Phrasebooks, avatar unlock books, clothing ownership and key items are
	// normally one-copy unlock/ownership records. Users may still set a
	// selected record up to 99 manually when the game supports a quantity.
	return 1
}

func comradesCollectionInventorySlot(model *SaveModel, fixID uint32) *InventorySlot {
	if model == nil {
		return nil
	}
	for i := range model.Inventory {
		if model.Inventory[i].FixID == fixID {
			return &model.Inventory[i]
		}
	}
	return nil
}

func stageComradesCollectionItem(model *SaveModel, kind string, fixID uint32, quantity int32) (*InventorySlot, error) {
	if model == nil || model.GameMode != "Comrades" {
		return nil, errors.New("load a COMRADES gameplay0 save first")
	}
	entry, ok := catalogEntryByFixID(fixID)
	if !ok || !isComradesCollectionEntry(kind, entry) {
		return nil, fmt.Errorf("0x%08X is not a verified %s entry", fixID, kind)
	}
	return addGameItemToInventory(model, fixID, quantity)
}

func stageComradesCollectionAll(model *SaveModel, kind string) (int, error) {
	if model == nil || model.GameMode != "Comrades" {
		return 0, errors.New("load a COMRADES gameplay0 save first")
	}
	entries := comradesCollectionEntries(kind)
	if len(entries) == 0 {
		return 0, fmt.Errorf("no verified %s entries are available", kind)
	}
	snapshot := append([]InventorySlot(nil), model.Inventory...)
	qty := comradesCollectionRecommendedQuantity(kind)
	changed := 0
	for _, e := range entries {
		before := comradesCollectionInventorySlot(model, e.FixID)
		beforeQty := int32(-1)
		if before != nil {
			beforeQty = before.Amount
		}

		// Barter Items overlaps several normal collection groups. ADD ALL is
		// ownership-oriented: do not reduce an existing stack (for example a
		// Treasure already at 99) just because the barter default is one copy.
		if kind == collectionBarter && before != nil && before.Amount > 0 {
			continue
		}

		if _, err := addGameItemToInventory(model, e.FixID, qty); err != nil {
			model.Inventory = snapshot
			return 0, fmt.Errorf("%s bulk operation rolled back: %w", kind, err)
		}
		after := comradesCollectionInventorySlot(model, e.FixID)
		if before == nil || after == nil || beforeQty != after.Amount {
			changed++
		}
	}
	return changed, nil
}

func maxOwnedComradesCollection(model *SaveModel, kind string) int {
	if model == nil || model.GameMode != "Comrades" {
		return 0
	}
	ids := make(map[uint32]struct{})
	for _, e := range comradesCollectionEntries(kind) {
		ids[e.FixID] = struct{}{}
	}
	qty := comradesCollectionRecommendedQuantity(kind)
	changed := 0
	for i := range model.Inventory {
		s := &model.Inventory[i]
		if _, ok := ids[s.FixID]; !ok || s.FixID == 0 {
			continue
		}
		if kind == collectionBarter && s.Amount > 0 {
			continue
		}
		if s.Amount != qty {
			s.Amount = qty
			changed++
		}
	}
	return changed
}

func restoreComradesCollection(model *SaveModel, kind string) int {
	if model == nil || model.GameMode != "Comrades" {
		return 0
	}
	ids := make(map[uint32]struct{})
	for _, e := range comradesCollectionEntries(kind) {
		ids[e.FixID] = struct{}{}
	}
	changed := 0
	for i := range model.Inventory {
		s := &model.Inventory[i]
		_, currentMatch := ids[s.FixID]
		_, originalMatch := ids[s.OriginalFixID]
		if !currentMatch && !originalMatch {
			continue
		}
		if s.FixID != s.OriginalFixID || s.Amount != s.OriginalAmount {
			s.FixID = s.OriginalFixID
			s.Amount = s.OriginalAmount
			changed++
		}
	}
	return changed
}

func comradesCollectionOwnedCount(model *SaveModel, kind string) (owned, total int) {
	entries := comradesCollectionEntries(kind)
	total = len(entries)
	if model == nil {
		return 0, total
	}
	for _, e := range entries {
		if s := comradesCollectionInventorySlot(model, e.FixID); s != nil && s.Amount > 0 {
			owned++
		}
	}
	return owned, total
}
