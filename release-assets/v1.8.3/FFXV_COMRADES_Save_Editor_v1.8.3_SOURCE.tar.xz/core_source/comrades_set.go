package main

import (
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"
)

type ComradesSetFile struct {
	Kind         string
	Path         string
	Verification string
}

type ComradesSaveSet struct {
	Dir   string
	Files []ComradesSetFile
}

var comradesSetKinds = []struct{ key, prefix string }{
	{"gameplay0", "gameplay0"},
	{"system_data", "system_data"},
	{"avatar0", "avatar0"},
	{"universal_data", "universal_data"},
}

func scanComradesSaveSet(dir string) (*ComradesSaveSet, error) {
	dir = filepath.Clean(strings.TrimSpace(dir))
	if dir == "" {
		return nil, fmt.Errorf("Comrades set folder is empty")
	}
	entries, err := os.ReadDir(dir)
	if err != nil {
		return nil, fmt.Errorf("read Comrades set folder: %w", err)
	}
	s := &ComradesSaveSet{Dir: dir}
	// Prefer decrypted/edited plaintext variants when both they and encrypted originals exist.
	for _, k := range comradesSetKinds {
		var candidates []string
		for _, e := range entries {
			if e.IsDir() {
				continue
			}
			name := strings.ToLower(e.Name())
			if !strings.HasPrefix(name, k.prefix) || !strings.Contains(name, ".save") {
				continue
			}
			candidates = append(candidates, filepath.Join(dir, e.Name()))
		}
		if len(candidates) == 0 {
			continue
		}
		sort.SliceStable(candidates, func(i, j int) bool {
			score := func(p string) int {
				n := strings.ToLower(filepath.Base(p))
				if strings.Contains(n, ".edited") {
					return 3
				}
				if strings.Contains(n, ".decrypted") {
					return 2
				}
				return 1
			}
			si, sj := score(candidates[i]), score(candidates[j])
			if si != sj {
				return si > sj
			}
			return candidates[i] < candidates[j]
		})
		s.Files = append(s.Files, ComradesSetFile{Kind: k.key, Path: candidates[0]})
	}
	if len(s.Files) == 0 {
		return nil, fmt.Errorf("no Comrades save files were found in %s", dir)
	}
	return s, nil
}

func (s *ComradesSaveSet) pathFor(kind string) string {
	if s == nil {
		return ""
	}
	for _, f := range s.Files {
		if f.Kind == kind {
			return f.Path
		}
	}
	return ""
}

func verifyComradesSaveSet(s *ComradesSaveSet) (string, error) {
	if s == nil {
		return "", fmt.Errorf("no Comrades save set loaded")
	}
	var b strings.Builder
	fmt.Fprintf(&b, "Folder: %s\n\n", s.Dir)
	ok := 0
	for i := range s.Files {
		v, err := verifyFile(s.Files[i].Path)
		if err != nil {
			fmt.Fprintf(&b, "%s: FAILED - %v\n", s.Files[i].Kind, err)
			continue
		}
		s.Files[i].Verification = v.Mode
		fmt.Fprintf(&b, "%s: OK - %s\n", s.Files[i].Kind, v.Mode)
		ok++
	}
	if ok != len(s.Files) {
		return b.String(), fmt.Errorf("%d of %d Comrades set files failed verification", len(s.Files)-ok, len(s.Files))
	}
	return b.String(), nil
}

func comradesSaveSetSummary(s *ComradesSaveSet) string {
	if s == nil {
		return "No Comrades save set loaded."
	}
	var b strings.Builder
	fmt.Fprintf(&b, "COMRADES SAVE SET\r\n%s\r\n\r\n", s.Dir)
	for _, k := range comradesSetKinds {
		p := s.pathFor(k.key)
		if p == "" {
			fmt.Fprintf(&b, "%-14s MISSING\r\n", k.key)
			continue
		}
		mode := "detected"
		for _, f := range s.Files {
			if f.Kind == k.key && f.Verification != "" {
				mode = f.Verification
				break
			}
		}
		fmt.Fprintf(&b, "%-14s %s\r\n  %s\r\n", k.key, mode, filepath.Base(p))
	}
	b.WriteString("\r\nUse Open gameplay0 / system_data / avatar0 to switch files without browsing again. Verify Entire Set checks every detected file.")
	return b.String()
}
