package main

import (
	"encoding/binary"
	"errors"
	"fmt"
)

const (
	comradesNoneAbilityFixID       uint32 = 0x01009E27
	comradesDefaultJobCommandFixID uint32 = 0x01027E08
)

// ComradesCharacterAbility is the initialized SaveAbilityStruct record owned by
// the active Glaive. COMRADES packs the five schema bools into one byte, making
// the physical payload 21 bytes: FixID, ability enum, level, weapon bank,
// packed flags, count.
type ComradesCharacterAbility struct {
	MarkerOffset     int
	FixID            uint32
	AbilityID        uint32
	Level            int32
	WeaponBankNumber int32
	Flags            byte
	Count            int32
	OriginalLevel    int32
	OriginalFlags    byte
	OriginalCount    int32
}

func (a ComradesCharacterAbility) Enabled() bool         { return a.Flags&0x01 != 0 }
func (a ComradesCharacterAbility) OriginalEnabled() bool { return a.OriginalFlags&0x01 != 0 }
func (a ComradesCharacterAbility) Enchant() bool         { return a.Flags&0x02 != 0 }
func (a ComradesCharacterAbility) NoctisOnly() bool      { return a.Flags&0x04 != 0 }
func (a ComradesCharacterAbility) WeaponOnly() bool      { return a.Flags&0x08 != 0 }
func (a ComradesCharacterAbility) Party() bool           { return a.Flags&0x10 != 0 }

type ComradesAbilityTreeEntity struct {
	FixID      uint32
	BankNumber int32
}

type ComradesAbilityTreeData struct {
	MarkerOffset   int
	Enabled        []ComradesAbilityTreeEntity
	ReleaseBlocked []uint32
}

func parseComradesCharacterAbilities(data []byte, schemaOffset int, types []SchemaType, status *ComradesStatus) ([]ComradesCharacterAbility, error) {
	if status == nil {
		return nil, errors.New("Comrades status is required to locate active Glaive abilities")
	}
	players := findMarkers(data, playerHash, schemaOffset)
	idx := int(status.SaveIndex)
	if idx < 0 || idx >= len(players) {
		return nil, fmt.Errorf("Comrades avatar save index %d is outside detected player records", status.SaveIndex)
	}
	start := players[idx]
	end := schemaOffset
	if idx+1 < len(players) {
		end = players[idx+1]
	}
	st := schemaTypeByName(types, "Black.Save.Ability.SaveAbilityStruct")
	if st == nil {
		return nil, errors.New("SaveAbilityStruct schema type is missing")
	}
	markers := findMarkers(data[start:end], st.Hash, end-start)
	if len(markers) == 0 || len(markers) > 4096 {
		return nil, fmt.Errorf("active Glaive ability array has unexpected record count %d", len(markers))
	}
	out := make([]ComradesCharacterAbility, 0, 32)
	for _, rel := range markers {
		marker := start + rel
		base := marker + 8
		if base+21 > end || base+21 > schemaOffset {
			return nil, errors.New("active Glaive ability record crosses player/schema boundary")
		}
		id := binary.LittleEndian.Uint32(data[base : base+4])
		if id == 0 || id == comradesNoneAbilityFixID {
			continue
		}
		a := ComradesCharacterAbility{
			MarkerOffset:     marker,
			FixID:            id,
			AbilityID:        binary.LittleEndian.Uint32(data[base+4 : base+8]),
			Level:            int32(binary.LittleEndian.Uint32(data[base+8 : base+12])),
			WeaponBankNumber: int32(binary.LittleEndian.Uint32(data[base+12 : base+16])),
			Flags:            data[base+16],
			Count:            int32(binary.LittleEndian.Uint32(data[base+17 : base+21])),
		}
		a.OriginalLevel = a.Level
		a.OriginalFlags = a.Flags
		a.OriginalCount = a.Count
		out = append(out, a)
	}
	return out, nil
}

func parseComradesAbilityTree(data []byte, schemaOffset int, types []SchemaType) (*ComradesAbilityTreeData, error) {
	treeType := schemaTypeByName(types, "Black.Save.AbilityTree.SaveAbilityTreeStruct")
	entityType := schemaTypeByName(types, "Black.Save.AbilityTree.SaveAbilityTreeEntityStruct")
	if treeType == nil || entityType == nil {
		return nil, errors.New("COMRADES ability-tree schema types are missing")
	}
	markers := findMarkers(data, treeType.Hash, schemaOffset)
	if len(markers) != 1 {
		return nil, fmt.Errorf("expected one SaveAbilityTreeStruct record, found %d", len(markers))
	}
	pos := markers[0] + 8
	if pos+4 > schemaOffset {
		return nil, errors.New("ability-tree enabled-array count is truncated")
	}
	count := int(binary.LittleEndian.Uint32(data[pos : pos+4]))
	pos += 4
	if count < 0 || count > 4096 {
		return nil, fmt.Errorf("ability-tree enabled-array count %d is unreasonable", count)
	}
	result := &ComradesAbilityTreeData{MarkerOffset: markers[0], Enabled: make([]ComradesAbilityTreeEntity, 0, count)}
	for i := 0; i < count; i++ {
		if pos+16 > schemaOffset {
			return nil, errors.New("ability-tree enabled-array is truncated")
		}
		if binary.LittleEndian.Uint64(data[pos:pos+8]) != entityType.Hash {
			return nil, fmt.Errorf("ability-tree entity %d has an unexpected type marker", i)
		}
		result.Enabled = append(result.Enabled, ComradesAbilityTreeEntity{
			FixID:      binary.LittleEndian.Uint32(data[pos+8 : pos+12]),
			BankNumber: int32(binary.LittleEndian.Uint32(data[pos+12 : pos+16])),
		})
		pos += 16
	}
	if pos+4 > schemaOffset {
		return nil, errors.New("ability-tree release-block count is truncated")
	}
	releaseCount := int(binary.LittleEndian.Uint32(data[pos : pos+4]))
	pos += 4
	if releaseCount < 0 || releaseCount > 4096 || pos+releaseCount*4 > schemaOffset {
		return nil, fmt.Errorf("ability-tree release-block count %d is unreasonable or truncated", releaseCount)
	}
	result.ReleaseBlocked = make([]uint32, 0, releaseCount)
	for i := 0; i < releaseCount; i++ {
		result.ReleaseBlocked = append(result.ReleaseBlocked, binary.LittleEndian.Uint32(data[pos:pos+4]))
		pos += 4
	}
	return result, nil
}

func comradesCharacterAbilityByFixID(model *SaveModel, fixID uint32) *ComradesCharacterAbility {
	if model == nil {
		return nil
	}
	for i := range model.ComradesAbilities {
		if model.ComradesAbilities[i].FixID == fixID {
			return &model.ComradesAbilities[i]
		}
	}
	return nil
}

func stageComradesCharacterAbilityExact(model *SaveModel, recordIndex int, fixID, abilityID uint32, weaponBank int32, enabled bool, level int32) error {
	if model == nil || model.GameMode != "Comrades" {
		return errors.New("load a Comrades gameplay0 save first")
	}
	if recordIndex < 0 || recordIndex >= len(model.ComradesAbilities) {
		return fmt.Errorf("character ability record index %d is out of range", recordIndex)
	}
	a := &model.ComradesAbilities[recordIndex]
	if a.FixID != fixID || a.AbilityID != abilityID || a.WeaponBankNumber != weaponBank {
		return fmt.Errorf("character ability identity changed (expected FixID 0x%08X / ability %d / weapon bank %d, found FixID 0x%08X / ability %d / weapon bank %d)", fixID, abilityID, weaponBank, a.FixID, a.AbilityID, a.WeaponBankNumber)
	}
	if level < 0 || level > 99 {
		return errors.New("character ability level must be 0 through 99")
	}
	a.Level = level
	if enabled {
		a.Flags |= 0x01
	} else {
		a.Flags &^= 0x01
	}
	return nil
}

func stageComradesCharacterAbility(model *SaveModel, fixID uint32, enabled bool, level int32) error {
	if model == nil || model.GameMode != "Comrades" {
		return errors.New("load a Comrades gameplay0 save first")
	}
	match := -1
	for i := range model.ComradesAbilities {
		if model.ComradesAbilities[i].FixID != fixID {
			continue
		}
		if match >= 0 {
			return fmt.Errorf("character ability FixID 0x%08X is duplicated; exact record identity is required", fixID)
		}
		match = i
	}
	if match < 0 {
		return fmt.Errorf("character ability 0x%08X is not an initialized ability in this Glaive record", fixID)
	}
	a := model.ComradesAbilities[match]
	return stageComradesCharacterAbilityExact(model, match, a.FixID, a.AbilityID, a.WeaponBankNumber, enabled, level)
}

func restoreComradesCharacterAbilities(model *SaveModel) {
	if model == nil {
		return
	}
	for i := range model.ComradesAbilities {
		a := &model.ComradesAbilities[i]
		a.Level = a.OriginalLevel
		a.Flags = a.OriginalFlags
		a.Count = a.OriginalCount
	}
}

func isDefaultComradesJobCommand(job *JobCommandSlot) bool {
	return job == nil || (job.FixID == comradesDefaultJobCommandFixID && job.BankNumber == -1)
}

func stageComradesSigilOwnership(model *SaveModel, bank int, owned bool) error {
	if model == nil || model.GameMode != "Comrades" {
		return errors.New("load a Comrades gameplay0 save first")
	}
	entry := comradesSigilCatalogByBank(bank)
	if entry == nil {
		return fmt.Errorf("Sigil bank %d is not in the verified COMRADES Sigil catalog", bank)
	}
	r := findMasterRecord(model, "Accessories", bank)
	if r == nil {
		return fmt.Errorf("Sigil bank %d is not present in the save", bank)
	}
	if owned {
		if r.FixID != entry.FixID {
			return errors.New("this Royal Sigil is not initialized in the loaded save; synthesis is disabled until in-game verification")
		}
		r.Exists = true
		return nil
	}

	// We can identify the active job-command tuple but do not yet have a
	// controlled Sigil-equipped save proving the exact Sigil -> job-command map.
	// Refuse Sigil removal whenever a non-default command is equipped rather than
	// risk deleting the currently selected Sigil.
	if !isDefaultComradesJobCommand(model.ComradesJob) {
		return errors.New("a non-default Sigil/job command is currently equipped; unequip it in-game before removing owned Sigils")
	}
	if r.FixID != entry.FixID {
		if isPlaceholderEquipment(r.FixID) {
			return nil
		}
		return fmt.Errorf("Sigil bank %d contains an unexpected accessory", bank)
	}
	if isPlaceholderEquipment(r.OriginalFixID) {
		// Added during this edit session: restore the exact placeholder state.
		r.FixID = r.OriginalFixID
		r.Type = r.OriginalType
		r.NameID = r.OriginalNameID
		r.Exists = r.OriginalExists
		r.EquipmentOwner = r.OriginalEquipmentOwner
		r.EquipmentBank = r.OriginalEquipmentBank
		r.Rank = r.OriginalRank
		r.Strength = r.OriginalStrength
		r.Vitality = r.OriginalVitality
		r.Critical = r.OriginalCritical
		r.RecoverMP = r.OriginalRecoverMP
		r.SlotCount = r.OriginalSlotCount
		r.Abilities = r.OriginalAbilities
		r.ResidentAbility = r.OriginalResidentAbility
		r.StatusAdjust = r.OriginalStatusAdjust
		r.RemodelFailCount = r.OriginalRemodelFailCount
		return nil
	}
	// Already initialized in the loaded save: preserve its verified payload and
	// toggle only the normal ownership bit.
	r.Exists = false
	return nil
}
