package main

// Direct scalar limits used by the COMRADES weapon editor.
//
// Attack is intentionally user-unlocked through 99,999. Prior PS4 testing showed
// that extreme displayed Attack values can still produce 0/1 real damage, so this
// is an editor range, not a claim that the game damage formula supports the value.
// Direct Vitality/Critical remain bounded to the existing verified internal ranges.
//
// The visible HP/MP/STR/VIT/MAG/SPI/resistance bonuses are separate entries in
// status_adjust[19] and are edited independently by the WPF frontend.
const (
	comradesWeaponAttackMax   int32 = 99999
	comradesWeaponVitalityMax int32 = 50
	comradesWeaponCriticalMax int32 = 100
	comradesWeaponSlotMax     int32 = 2
)

// looksLikeUnsafeV262MaxProfile identifies the destructive v2.6.2 pattern.
// The raw 19-value block is checked independently so a partially repaired
// weapon is still rejected when the known dense raw-9999 pattern remains while its
// original raw crafting/status values remain unrecoverable.
func looksLikeUnsafeV262MaxProfile(r *EquipmentRecord) bool {
	if r == nil || r.Category != "Weapons" || !r.Exists {
		return false
	}

	raw9999 := 0
	for _, v := range r.StatusAdjust {
		if v == 9999 {
			raw9999++
		}
	}
	if raw9999 == len(r.StatusAdjust) {
		return true
	}

	// A partially repaired v2.6.2 record can retain a large cluster of the
	// synthetic 9999 raw values even after one or more fields were changed.
	// Real reference weapons do not use this dense signature.
	if raw9999 >= 8 {
		return true
	}

	// Direct values outside the editor's validated ranges are also treated as
	// unsafe on an owned weapon so the user is forced to repair them before save.
	if !weaponDirectStatsWithinTestedRanges(r.Strength, r.Vitality, r.Critical) || r.SlotCount < 0 || r.SlotCount > comradesWeaponSlotMax {
		return true
	}

	// Keep the exact retired scalar signature for completeness.
	return r.Strength == 9999 && r.Vitality == 9999 && r.Critical == 9999 && r.RecoverMP == 9999 && r.SlotCount == 4
}

func countUnsafeV262MaxProfiles(model *SaveModel) int {
	if model == nil {
		return 0
	}
	n := 0
	for i := range model.Equipment {
		if looksLikeUnsafeV262MaxProfile(&model.Equipment[i]) {
			n++
		}
	}
	return n
}

func weaponDirectStatsWithinTestedRanges(strength, vitality, critical int32) bool {
	return strength >= 0 && strength <= comradesWeaponAttackMax &&
		vitality >= 0 && vitality <= comradesWeaponVitalityMax &&
		critical >= 0 && critical <= comradesWeaponCriticalMax
}
