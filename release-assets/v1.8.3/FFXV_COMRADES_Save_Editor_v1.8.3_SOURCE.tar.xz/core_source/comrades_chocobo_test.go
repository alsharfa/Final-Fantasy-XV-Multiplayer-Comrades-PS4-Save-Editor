package main

import (
	"encoding/binary"
	"math"
	"testing"
)

func TestParseComradesChocobosFromSerializedMarkers(t *testing.T) {
	const parentHash uint64 = 0x5E400C02FAA920DB
	const childHash uint64 = 0x11A05E89B8C96B66
	data := make([]byte, 512)
	parentMarker := 16
	binary.LittleEndian.PutUint64(data[parentMarker:parentMarker+8], parentHash)
	parentBase := parentMarker + 8
	binary.LittleEndian.PutUint32(data[parentBase:parentBase+4], 1)

	childMarker := 40
	binary.LittleEndian.PutUint64(data[childMarker:childMarker+8], childHash)
	rb := childMarker + 8
	binary.LittleEndian.PutUint32(data[rb+0x00:rb+0x04], 0x0B01D0C1)
	binary.LittleEndian.PutUint32(data[rb+0x04:rb+0x08], 2)
	binary.LittleEndian.PutUint32(data[rb+0x08:rb+0x0C], 3)
	binary.LittleEndian.PutUint32(data[rb+0x0C:rb+0x10], 4)
	binary.LittleEndian.PutUint32(data[rb+0x10:rb+0x14], 33)
	binary.LittleEndian.PutUint32(data[rb+0x14:rb+0x18], 30)
	binary.LittleEndian.PutUint32(data[rb+0x18:rb+0x1C], math.Float32bits(26.0))
	// Physical serialization includes 4-byte array counts before evolValue_[3],
	// trainingCnt_[5], specialTrainingNum_[5], and trainingBonusCnt_[5].
	binary.LittleEndian.PutUint32(data[rb+0x1C:rb+0x20], 3)
	binary.LittleEndian.PutUint32(data[rb+0x2C:rb+0x30], 5)
	binary.LittleEndian.PutUint32(data[rb+0x3A:rb+0x3E], 5)
	binary.LittleEndian.PutUint16(data[rb+0x48:rb+0x4A], 1)
	binary.LittleEndian.PutUint16(data[rb+0x4A:rb+0x4C], 70)
	binary.LittleEndian.PutUint16(data[rb+0x4C:rb+0x4E], 50)
	binary.LittleEndian.PutUint16(data[rb+0x4E:rb+0x50], 40)
	binary.LittleEndian.PutUint16(data[rb+0x50:rb+0x52], 0)
	data[rb+0x52] = 0x02 // isInjured
	binary.LittleEndian.PutUint32(data[rb+0x53:rb+0x57], 5)
	binary.LittleEndian.PutUint16(data[rb+0x61:rb+0x63], 7)

	types := []SchemaType{
		{Name: "Black.Save.Multiplay.SaveChocoboDataStruct", Hash: parentHash},
		{Name: "Black.Save.Multiplay.SaveChocoboDataStruct.ChocoboDataStruct", Hash: childHash},
	}
	got, err := parseComradesChocobos(data, len(data), types)
	if err != nil {
		t.Fatal(err)
	}
	if len(got) != 1 {
		t.Fatalf("expected 1 chocobo, got %d", len(got))
	}
	c := got[0]
	if c.NameID != 0x0B01D0C1 || c.Level != 40 || c.MaxLevel != 50 || c.LimitMaxLevel != 70 || c.Stamina != 33 || c.Jump != 30 || c.Speed != 26.0 || c.SkillLevel != 1 || !c.IsInjured || c.TrainingRateCnt != 7 {
		t.Fatalf("unexpected chocobo parse: %+v", c)
	}
}

func TestStageComradesChocobo(t *testing.T) {
	m := &SaveModel{GameMode: "Comrades", ComradesChocobos: []ComradesChocobo{{Index: 0, NameID: 0x01038339, Level: 40, MaxLevel: 50, LimitMaxLevel: 99, Stamina: 33, Jump: 30, Speed: 26.0}}}
	if err := stageComradesChocobo(m, 0, 50, 50, 99, 5, 60, 180, 35.0, 0); err != nil {
		t.Fatal(err)
	}
	c := m.ComradesChocobos[0]
	if c.NameID != 0x01038339 || c.Level != 50 || c.Stamina != 60 || c.Jump != 180 || c.Speed != 35.0 || c.SkillLevel != 5 {
		t.Fatalf("unexpected staged chocobo: %+v", c)
	}
}
