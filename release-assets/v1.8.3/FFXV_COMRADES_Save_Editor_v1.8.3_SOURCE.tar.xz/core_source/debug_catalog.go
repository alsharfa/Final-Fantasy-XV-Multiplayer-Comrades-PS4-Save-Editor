package main

// DebugEntry describes developer/test data discovered in the supplied FFXV
// databases and decrypted EBOOT. Only entries with WritableFixID != 0 map to
// a verified normal gameplay inventory record and can be staged by this editor.
type DebugEntry struct {
	Name          string
	Source        string
	Kind          string
	Details       string
	WritableFixID uint32
}

var debugEntries = []DebugEntry{
	{Name: "JET_TEST_PROTEIN", Source: "item.win32.bins", Kind: "Safe inventory-backed test item", Details: "Real BATTLE inventory catalog entry. This one can be inserted through the same verified empty-slot path as normal battle items.", WritableFixID: 0x0106D408},

	{Name: "DEBUG_SET_000", Source: "item.win32.bins", Kind: "Internal debug item set", Details: "Developer item-set definition. No verified direct gameplay inventory slot mapping; view only."},
	{Name: "DEBUG_SET_001", Source: "item.win32.bins", Kind: "Internal debug item set", Details: "Developer item-set definition. No verified direct gameplay inventory slot mapping; view only."},
	{Name: "DEBUG_SET_002", Source: "item.win32.bins", Kind: "Internal debug item set", Details: "Developer item-set definition. No verified direct gameplay inventory slot mapping; view only."},
	{Name: "DEBUG_SET_003", Source: "item.win32.bins", Kind: "Internal debug item set", Details: "Developer item-set definition. No verified direct gameplay inventory slot mapping; view only."},
	{Name: "DEBUG_SET_050", Source: "item.win32.bins", Kind: "Internal debug item set", Details: "Developer item-set definition. No verified direct gameplay inventory slot mapping; view only."},
	{Name: "DEBUG_SET_051", Source: "item.win32.bins", Kind: "Internal debug item set", Details: "Developer item-set definition. No verified direct gameplay inventory slot mapping; view only."},
	{Name: "DEBUG_SET_052", Source: "item.win32.bins", Kind: "Internal debug item set", Details: "Developer item-set definition. No verified direct gameplay inventory slot mapping; view only."},
	{Name: "DEBUG_SET_053", Source: "item.win32.bins", Kind: "Internal debug item set", Details: "Developer item-set definition. No verified direct gameplay inventory slot mapping; view only."},
	{Name: "DEBUG_SET_054", Source: "item.win32.bins", Kind: "Internal debug item set", Details: "Developer item-set definition. No verified direct gameplay inventory slot mapping; view only."},
	{Name: "DEBUG_SET_055", Source: "item.win32.bins", Kind: "Internal debug item set", Details: "Developer item-set definition. No verified direct gameplay inventory slot mapping; view only."},
	{Name: "DEBUG_SET_100", Source: "item.win32.bins", Kind: "Internal debug item set", Details: "Developer item-set definition. No verified direct gameplay inventory slot mapping; view only."},
	{Name: "DEBUG_SET_101", Source: "item.win32.bins", Kind: "Internal debug item set", Details: "Developer item-set definition. No verified direct gameplay inventory slot mapping; view only."},
	{Name: "DEBUG_SET_102", Source: "item.win32.bins", Kind: "Internal debug item set", Details: "Developer item-set definition. No verified direct gameplay inventory slot mapping; view only."},
	{Name: "DEBUG_SET_103", Source: "item.win32.bins", Kind: "Internal debug item set", Details: "Developer item-set definition. No verified direct gameplay inventory slot mapping; view only."},
	{Name: "DEBUG_SET_104", Source: "item.win32.bins", Kind: "Internal debug item set", Details: "Developer item-set definition. No verified direct gameplay inventory slot mapping; view only."},
	{Name: "DEBUG_SET_105", Source: "item.win32.bins", Kind: "Internal debug item set", Details: "Developer item-set definition. No verified direct gameplay inventory slot mapping; view only."},
	{Name: "DEBUG_SET_106", Source: "item.win32.bins", Kind: "Internal debug item set", Details: "Developer item-set definition. No verified direct gameplay inventory slot mapping; view only."},
	{Name: "DEBUG_SET_200", Source: "item.win32.bins", Kind: "Internal debug item set", Details: "Developer item-set definition. No verified direct gameplay inventory slot mapping; view only."},
	{Name: "DEBUG_SET_201", Source: "item.win32.bins", Kind: "Internal debug item set", Details: "Developer item-set definition. No verified direct gameplay inventory slot mapping; view only."},
	{Name: "DEBUG_SET_202", Source: "item.win32.bins", Kind: "Internal debug item set", Details: "Developer item-set definition. No verified direct gameplay inventory slot mapping; view only."},
	{Name: "DEBUG_SET_203", Source: "item.win32.bins", Kind: "Internal debug item set", Details: "Developer item-set definition. No verified direct gameplay inventory slot mapping; view only."},

	{Name: "OM_SHOP_ITEM_DEBUG_1", Source: "shop.win32.bins", Kind: "Debug shop definition", Details: "Developer/debug shop table. Shop-state save mapping is not verified; view only."},
	{Name: "OM_SHOP_ITEM_DEBUG_2", Source: "shop.win32.bins", Kind: "Debug shop definition", Details: "Developer/debug shop table. Shop-state save mapping is not verified; view only."},
	{Name: "OM_SHOP_ITEM_DEBUG_3", Source: "shop.win32.bins", Kind: "Debug shop definition", Details: "Developer/debug shop table. Shop-state save mapping is not verified; view only."},
	{Name: "OM_SHOP_WEAPON_DEBUG_1", Source: "shop.win32.bins", Kind: "Debug weapon shop definition", Details: "Developer/debug weapon shop table. This is not itself a weapon record; view only."},
	{Name: "OM_SHOP_AVATAR_DEBUG_1", Source: "shop.win32.bins", Kind: "Debug avatar shop definition", Details: "Developer/debug avatar shop table. Shop-state save mapping is not verified; view only."},
	{Name: "TEST_ITEM00 ... TEST_ITEM24", Source: "shop.win32.bins", Kind: "Shop test rows", Details: "Multiple TEST_ITEMxx rows are present in the shop database. They are internal shop test definitions, not normal inventory items."},

	{Name: "TEST_ACTIVE_01 ... TEST_ACTIVE_13", Source: "dinnertalk.win32.bins", Kind: "Dinner-talk test data", Details: "Developer/test dinner-talk activation records. No verified gameplay save write mapping; view only."},
	{Name: "TEST_FOUNDER_F/M", Source: "dinnertalk.win32.bins", Kind: "Dinner-talk test data", Details: "Developer/test founder dialogue records. No verified gameplay save write mapping; view only."},
	{Name: "CharaEntry_TEST_*", Source: "resident-character.win32.bins", Kind: "Resident character test entries", Details: "Battle, car-mode, level and non-battle test character entry resources exist for party members. Resource references only; view only."},

	{Name: "Save Load UI Debug On", Source: "eboot.elf", Kind: "EBOOT developer hook", Details: "Debug save/load UI string is present in the supplied decrypted EBOOT. Presence does not prove a retail-accessible activation path."},
	{Name: "DebugMenuSceneLabel", Source: "eboot.elf", Kind: "EBOOT developer hook", Details: "Debug-menu scene label support is present in the executable. Activation path has not been patched or verified."},
	{Name: "SetStatusDebugInvincible", Source: "eboot.elf", Kind: "EBOOT developer action", Details: "Developer status action for invincibility is present in the executable. This is not a save-editor field."},
	{Name: "SequenceActionDebugSetInvincible", Source: "eboot.elf", Kind: "EBOOT developer action", Details: "Developer sequence action for invincibility is present. Requires runtime/sequence activation, not a normal save write."},
	{Name: "SequenceActionDebugItemFull", Source: "eboot.elf", Kind: "EBOOT developer action", Details: "Developer action for filling items is present. Runtime activation is not yet mapped."},
	{Name: "SequenceActionDebugMagicNoCharge", Source: "eboot.elf", Kind: "EBOOT developer action", Details: "Developer action related to magic charge bypass is present. Runtime activation is not yet mapped."},
	{Name: "SequenceActionDebugPhantomGaugeLock", Source: "eboot.elf", Kind: "EBOOT developer action", Details: "Developer action related to locking the Phantom/Armiger gauge is present. Runtime activation is not yet mapped."},
	{Name: "SequenceActionDebugCommandGaugeLock", Source: "eboot.elf", Kind: "EBOOT developer action", Details: "Developer action related to command gauge locking is present. Runtime activation is not yet mapped."},
	{Name: "SequenceActionDebugSetGameSpeed", Source: "eboot.elf", Kind: "EBOOT developer action", Details: "Developer game-speed action is present. Runtime activation is not yet mapped."},
	{Name: "SequenceActionDebugQuestFlagMenu", Source: "eboot.elf", Kind: "EBOOT developer menu", Details: "Developer quest-flag menu action is present. Runtime activation is not yet mapped."},
	{Name: "SequenceActionDebugCommandMenu", Source: "eboot.elf", Kind: "EBOOT developer menu", Details: "Developer command-menu framework is present, including enemy, ingredient, vehicle, player-change and multiplayer variants."},
	{Name: "SequenceActionDebugSaveLoad", Source: "eboot.elf", Kind: "EBOOT developer action", Details: "Developer debug save/load sequence action is present. Runtime activation is not yet mapped."},
	{Name: "SequenceActionDebugGetAnyFish", Source: "eboot.elf", Kind: "EBOOT developer action", Details: "Developer fishing action is present. Runtime activation is not yet mapped."},
	{Name: "SequenceActionDebugFullDropRate", Source: "eboot.elf", Kind: "EBOOT developer action", Details: "Developer full-drop-rate action is present. Runtime activation is not yet mapped."},
	{Name: "SequenceActionDebugSetNoctisMoveSpeed", Source: "eboot.elf", Kind: "EBOOT developer action", Details: "Developer Noctis movement-speed action is present. Runtime activation is not yet mapped."},
	{Name: "SequenceActionDebugToggleRingMagicAlternaAlwaysHit", Source: "eboot.elf", Kind: "EBOOT developer action", Details: "Developer Alterna always-hit toggle is present. Runtime activation is not yet mapped."},
	{Name: "SequenceActionSetDebugPad", Source: "eboot.elf", Kind: "EBOOT developer input hook", Details: "A debug-pad sequence action is present. This is a strong debug-input lead, but its retail activation path is not yet verified."},
}
