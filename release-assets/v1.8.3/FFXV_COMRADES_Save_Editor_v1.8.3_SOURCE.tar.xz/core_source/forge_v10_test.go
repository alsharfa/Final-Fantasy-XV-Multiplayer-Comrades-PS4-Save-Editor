package main

import (
	"os"
	"testing"
)

func TestForgeDatabasePackManifest(t *testing.T) {
	if got, want := len(forgeDatabaseFiles), 49; got != want {
		t.Fatalf("common database manifest=%d, want %d", got, want)
	}
}

func TestForgeSafeModPreservesStructuralWeaponFieldsWhenSamplePresent(t *testing.T) {
	const path = "testdata/gameplay0_decrypted(2).save"
	plain, err := os.ReadFile(path)
	if os.IsNotExist(err) {
		t.Skip("uploaded Comrades sample not present")
	}
	if err != nil {
		t.Fatal(err)
	}
	m, err := parseSaveModelBytes(plain, path)
	if err != nil {
		t.Fatal(err)
	}
	r := findMasterRecord(m, "Weapons", 73) // Sword of the Wise / special weapon
	if r == nil {
		t.Fatal("verified weapon bank 73 missing")
	}
	oldRank := r.Rank
	oldRecover := r.RecoverMP
	oldSlots := r.SlotCount
	oldAbilities := r.Abilities
	oldResident := r.ResidentAbility
	oldCraft := r.StatusAdjust
	oldRemodel := r.RemodelFailCount

	if _, err := stageComradesWeaponSafeModPreset(m, 73); err != nil {
		t.Fatal(err)
	}
	if !r.Exists || r.Strength != comradesWeaponAttackMax || r.Vitality != comradesWeaponVitalityMax || r.Critical != comradesWeaponCriticalMax || r.RecoverMP != oldRecover {
		t.Fatalf("safe mod core stats not staged: %+v", r)
	}
	if r.Rank != oldRank || r.SlotCount != oldSlots || r.Abilities != oldAbilities || r.ResidentAbility != oldResident || r.StatusAdjust != oldCraft || r.RemodelFailCount != oldRemodel {
		t.Fatal("safe mod changed a structural/crafting weapon field")
	}
}

func TestForgeHiddenPackRejectsWrongFixID(t *testing.T) {
	m := &SaveModel{GameMode: "Comrades"}
	for _, d := range comradesHiddenModdedWeapons {
		m.Equipment = append(m.Equipment, EquipmentRecord{Category: "Weapons", CategoryIndex: d.Bank, FixID: d.FixID})
	}
	// Deliberately corrupt one exact identity. Bank-only validation would miss this.
	for i := range m.Equipment {
		if m.Equipment[i].CategoryIndex == 80 {
			m.Equipment[i].FixID = 0x0104CFE4
		}
	}
	if _, err := stageComradesHiddenModdedPack(m); err == nil {
		t.Fatal("expected exact bank+FixID validation failure")
	}
}

func TestForgeGilKWSafeWeaponSurviveEncryptionWhenPairPresent(t *testing.T) {
	const encryptedPath = "testdata/gameplay0(20260821-145222).save"
	const plainPath = "testdata/gameplay0.decrypted.save"
	encrypted, err := os.ReadFile(encryptedPath)
	if os.IsNotExist(err) {
		t.Skip("encrypted sample not present")
	}
	if err != nil {
		t.Fatal(err)
	}
	plain, err := os.ReadFile(plainPath)
	if os.IsNotExist(err) {
		t.Skip("plain sample not present")
	}
	if err != nil {
		t.Fatal(err)
	}

	m, err := parseSaveModelBytes(plain, plainPath)
	if err != nil {
		t.Fatal(err)
	}
	if err := stageComradesKW(m, 777777); err != nil {
		t.Fatal(err)
	}
	w, err := stageComradesWeaponSafeModPreset(m, 73)
	if err != nil {
		t.Fatal(err)
	}
	targetID := w.FixID
	g := GeneralEdits{ControlledCharacter: m.Party.ControlledCharacter, Chapter: m.Party.Chapter, Gil: 987654321, ArenaMedals: m.Party.ArenaMedals, OracleCoins: m.Party.OracleCoins, AbilityPoints: m.Party.AbilityPoints}
	edited, _, _, _, err := applyModelEdits(plain, m, g)
	if err != nil {
		t.Fatal(err)
	}

	mid, err := decryptOuterLayer(encrypted)
	if err != nil {
		t.Fatal(err)
	}
	_, first, err := decodeGameplayChain(mid)
	if err != nil {
		t.Fatal(err)
	}

	d := t.TempDir()
	editedPath := d + "/gameplay0.edited.save"
	if err := os.WriteFile(editedPath, edited, 0o600); err != nil {
		t.Fatal(err)
	}
	if err := writeMetadataExclusive(editedPath+metadataSuffix, makeMetadata(encrypted, plain, first)); err != nil {
		t.Fatal(err)
	}
	res, err := processFile(editedPath, false)
	if err != nil {
		t.Fatal(err)
	}
	encOut, err := os.ReadFile(res.OutputPath)
	if err != nil {
		t.Fatal(err)
	}
	outMid, err := decryptOuterLayer(encOut)
	if err != nil {
		t.Fatal(err)
	}
	recovered, _, err := decodeGameplayChain(outMid)
	if err != nil {
		t.Fatal(err)
	}
	got, err := parseSaveModelBytes(recovered, res.OutputPath)
	if err != nil {
		t.Fatal(err)
	}
	if got.Party.Gil != 987654321 {
		t.Fatalf("Gil=%d", got.Party.Gil)
	}
	if got.ComradesKW == nil || got.ComradesKW.Current != 777777 {
		t.Fatalf("kW=%+v", got.ComradesKW)
	}
	rw := findMasterRecord(got, "Weapons", 73)
	if rw == nil || rw.FixID != targetID || !rw.Exists || rw.Strength != comradesWeaponAttackMax || rw.Vitality != comradesWeaponVitalityMax || rw.Critical != comradesWeaponCriticalMax || rw.RecoverMP != w.OriginalRecoverMP {
		t.Fatalf("safe weapon mod did not survive encrypted round trip: %+v", rw)
	}
}

func TestForgeCustomWeaponStatsPreserveAbilitiesAndCraftWhenSamplePresent(t *testing.T) {
	const path = "testdata/gameplay0_decrypted(2).save"
	plain, err := os.ReadFile(path)
	if os.IsNotExist(err) {
		t.Skip("uploaded Comrades sample not present")
	}
	if err != nil {
		t.Fatal(err)
	}
	m, err := parseSaveModelBytes(plain, path)
	if err != nil {
		t.Fatal(err)
	}
	r := findMasterRecord(m, "Weapons", 73)
	if r == nil {
		t.Fatal("weapon bank 73 missing")
	}
	oldAbilities := r.Abilities
	oldResident := r.ResidentAbility
	oldCraft := r.StatusAdjust
	_, err = stageComradesWeaponCustomStats(m, 73, comradesWeaponEditableStats{
		Rank: 77, Strength: 900, Vitality: 800, Critical: 100, RecoverMP: r.RecoverMP, SlotCount: 2, RemodelFailCount: 7,
	})
	if err != nil {
		t.Fatal(err)
	}
	if r.Rank != 77 || r.Strength != 900 || r.Vitality != 800 || r.Critical != 100 || r.RecoverMP != r.OriginalRecoverMP || r.SlotCount != 2 || r.RemodelFailCount != 7 {
		t.Fatalf("custom stats not staged: %+v", r)
	}
	if r.Abilities != oldAbilities || r.ResidentAbility != oldResident || r.StatusAdjust != oldCraft {
		t.Fatal("custom stat editor changed abilities/crafting fields")
	}
	g := GeneralEdits{ControlledCharacter: m.Party.ControlledCharacter, Chapter: m.Party.Chapter, Gil: m.Party.Gil, ArenaMedals: m.Party.ArenaMedals, OracleCoins: m.Party.OracleCoins, AbilityPoints: m.Party.AbilityPoints}
	out, _, _, _, err := applyModelEdits(plain, m, g)
	if err != nil {
		t.Fatal(err)
	}
	got, err := parseSaveModelBytes(out, "custom-stats.decrypted.save")
	if err != nil {
		t.Fatal(err)
	}
	w := findMasterRecord(got, "Weapons", 73)
	if w == nil || w.Rank != 77 || w.Strength != 900 || w.Vitality != 800 || w.Critical != 100 || w.RecoverMP != r.OriginalRecoverMP || w.SlotCount != 2 || w.RemodelFailCount != 7 {
		t.Fatalf("custom stats did not survive save reparse: %+v", w)
	}
	if w.Abilities != oldAbilities || w.ResidentAbility != oldResident || w.StatusAdjust != oldCraft {
		t.Fatal("custom stats changed abilities/crafting after reparse")
	}
}

func TestForgeCustomWeaponStatsRejectsNewHighRank(t *testing.T) {
	m := &SaveModel{GameMode: "Comrades", Equipment: []EquipmentRecord{{Category: "Weapons", CategoryIndex: 1, FixID: 0x01000001, OriginalRank: 10}}}
	_, err := stageComradesWeaponCustomStats(m, 1, comradesWeaponEditableStats{Rank: 200, Strength: 1, Vitality: 1, Critical: 1, RecoverMP: 1, SlotCount: 1})
	if err == nil {
		t.Fatal("expected arbitrary new rank >99 to be rejected")
	}
}
