# Local integration fixtures

The repository does **not** include personal PS4 save files.

For full release validation, place the controlled regression fixtures used by the integration tests in this directory:

- `gameplay0.decrypted.save`
- `gameplay0_decrypted(2).save`
- `gameplay0(20260821-145222).save`
- at least one of:
  - `gameplay0(20260820-164627).save`
  - `gameplay0(20260820-165114).save`
  - `gameplay0(20260820-171535).save`

Normal `go test ./...` remains usable without these private fixtures; the fixture-dependent tests will explicitly skip. For a release gate, run `RELEASE-VALIDATE-WINDOWS.cmd` from the repository root. That script refuses to claim full integration validation when the required fixtures are absent.
