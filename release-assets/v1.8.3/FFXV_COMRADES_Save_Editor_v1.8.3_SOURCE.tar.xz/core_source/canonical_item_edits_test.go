package main

import (
	"strings"
	"testing"
)

func TestCanonicalItemEditsAllowSameDesiredState(t *testing.T) {
	req := applyRequest{
		CollectionEdits: []collectionEditRequest{{Kind: "Treasures", FixID: 0x0105C4E4, Quantity: 99}},
		InventoryEdits:  []inventoryEditRequest{{Kind: "Multiplayer Materials", FixID: 0x0105C4E4, Owned: true, Quantity: 99}},
	}
	if err := validateCanonicalItemEdits(req); err != nil {
		t.Fatalf("matching duplicate edits should be accepted: %v", err)
	}
}

func TestCanonicalItemEditsRejectConflictingQuantity(t *testing.T) {
	req := applyRequest{
		CollectionEdits: []collectionEditRequest{{Kind: "Treasures", FixID: 0x0105C4E4, Quantity: 99}},
		InventoryEdits:  []inventoryEditRequest{{Kind: "Multiplayer Materials", FixID: 0x0105C4E4, Owned: true, Quantity: 1}},
	}
	err := validateCanonicalItemEdits(req)
	if err == nil || !strings.Contains(err.Error(), "conflicting edits") {
		t.Fatalf("expected conflict error, got %v", err)
	}
}

func TestCanonicalItemEditsRejectOwnedVsRemoved(t *testing.T) {
	req := applyRequest{
		CollectionEdits: []collectionEditRequest{{Kind: "Barter Items", FixID: 0x0107528C, Quantity: 1}},
		InventoryEdits:  []inventoryEditRequest{{Kind: "Tokens", FixID: 0x0107528C, Owned: false, Quantity: 0}},
	}
	if err := validateCanonicalItemEdits(req); err == nil {
		t.Fatal("expected owned/remove conflict to be rejected")
	}
}
