package main

import (
	"os"
	"testing"
)

const comradesEquipmentSample = "testdata/gameplay0.decrypted.save"

func loadEquipmentSample(t *testing.T) ([]byte, *SaveModel) {
	t.Helper()
	plain, err := os.ReadFile(comradesEquipmentSample)
	if os.IsNotExist(err) {
		t.Skip("uploaded Comrades sample not present")
	}
	if err != nil {
		t.Fatal(err)
	}
	m, err := parseSaveModelBytes(plain, comradesEquipmentSample)
	if err != nil {
		t.Fatal(err)
	}
	if m.Comrades == nil {
		t.Fatal("active Comrades Glaive not found")
	}
	return plain, m
}

func TestComradesGlaiveEquipmentLayoutParsed(t *testing.T) {
	_, m := loadEquipmentSample(t)
	if m.Comrades.SaveIndex != 11 {
		t.Fatalf("unexpected sample save index %d", m.Comrades.SaveIndex)
	}
	for i := 1; i <= 4; i++ {
		if equippedSlotBySaveIndex(m, m.Comrades.SaveIndex, "Weapon", i) == nil {
			t.Fatalf("weapon slot %d missing", i)
		}
	}
	for i := 1; i <= 3; i++ {
		if equippedSlotBySaveIndex(m, m.Comrades.SaveIndex, "Accessory", i) == nil {
			t.Fatalf("accessory slot %d missing", i)
		}
	}
	if m.ComradesJob == nil || m.ComradesJob.SaveIndex != m.Comrades.SaveIndex {
		t.Fatal("active Glaive job-command/Sigil tuple missing")
	}
	foundAttire := false
	for i := range m.Attire {
		if m.Attire[i].SaveIndex == m.Comrades.SaveIndex {
			foundAttire = true
			break
		}
	}
	if !foundAttire {
		t.Fatal("active Glaive clothing tuple missing")
	}

	primary := equippedSlotBySaveIndex(m, m.Comrades.SaveIndex, "Weapon", 1)
	if primary == nil || primary.BankNumber != 80 || primary.FixID != 0x0105B505 {
		t.Fatalf("unexpected primary weapon: %+v", primary)
	}
	secondary2 := equippedSlotBySaveIndex(m, m.Comrades.SaveIndex, "Weapon", 3)
	if secondary2 == nil || secondary2.BankNumber != 81 || secondary2.FixID != 0x0105B506 {
		t.Fatalf("unexpected weapon slot 3: %+v", secondary2)
	}
}

func TestComradesEquipmentWeaponSlotRoundTrip(t *testing.T) {
	plain, m := loadEquipmentSample(t)
	var target *EquipmentRecord
	for i := range m.Equipment {
		r := &m.Equipment[i]
		if r.Category == "Weapons" && r.FixID != 0 && !isPlaceholderEquipment(r.FixID) && r.EquipmentOwner < 0 {
			target = r
			break
		}
	}
	if target == nil {
		t.Skip("no unassigned initialized weapon available")
	}
	if err := stageComradesGlaiveEquipmentSlot(m, "Weapon", 2, target.CategoryIndex); err != nil {
		t.Fatal(err)
	}
	g := GeneralEdits{ControlledCharacter: m.Party.ControlledCharacter, Chapter: m.Party.Chapter, Gil: m.Party.Gil, ArenaMedals: m.Party.ArenaMedals, OracleCoins: m.Party.OracleCoins, AbilityPoints: m.Party.AbilityPoints}
	out, _, _, _, err := applyModelEdits(plain, m, g)
	if err != nil {
		t.Fatal(err)
	}
	got, err := parseSaveModelBytes(out, "equipment-weapon-roundtrip.decrypted.save")
	if err != nil {
		t.Fatal(err)
	}
	slot := equippedSlotBySaveIndex(got, got.Comrades.SaveIndex, "Weapon", 2)
	if slot == nil || int(slot.BankNumber) != target.CategoryIndex || slot.FixID != target.FixID {
		t.Fatalf("weapon slot did not survive reparse: %+v target=%+v", slot, target)
	}
	master := findMasterRecord(got, "Weapons", target.CategoryIndex)
	if master == nil || master.EquipmentOwner != int32(got.Comrades.SaveIndex) || master.EquipmentBank != 1 || !master.Exists {
		t.Fatalf("weapon master link did not survive reparse: %+v", master)
	}
}

func TestComradesEquipmentAccessorySlotRoundTrip(t *testing.T) {
	plain, m := loadEquipmentSample(t)
	var target *EquipmentRecord
	for i := range m.Equipment {
		r := &m.Equipment[i]
		if r.Category == "Accessories" && r.CategoryIndex < 32 && r.FixID != 0 && !isPlaceholderEquipment(r.FixID) && r.EquipmentOwner < 0 {
			target = r
			break
		}
	}
	if target == nil {
		t.Skip("no unassigned initialized accessory available")
	}
	if err := stageComradesGlaiveEquipmentSlot(m, "Accessory", 1, target.CategoryIndex); err != nil {
		t.Fatal(err)
	}
	g := GeneralEdits{ControlledCharacter: m.Party.ControlledCharacter, Chapter: m.Party.Chapter, Gil: m.Party.Gil, ArenaMedals: m.Party.ArenaMedals, OracleCoins: m.Party.OracleCoins, AbilityPoints: m.Party.AbilityPoints}
	out, _, _, _, err := applyModelEdits(plain, m, g)
	if err != nil {
		t.Fatal(err)
	}
	got, err := parseSaveModelBytes(out, "equipment-accessory-roundtrip.decrypted.save")
	if err != nil {
		t.Fatal(err)
	}
	slot := equippedSlotBySaveIndex(got, got.Comrades.SaveIndex, "Accessory", 1)
	if slot == nil || int(slot.BankNumber) != target.CategoryIndex || slot.FixID != target.FixID {
		t.Fatalf("accessory slot did not survive reparse: %+v target=%+v", slot, target)
	}
	master := findMasterRecord(got, "Accessories", target.CategoryIndex)
	if master == nil || master.EquipmentOwner != int32(got.Comrades.SaveIndex) || master.EquipmentBank != 0 || !master.Exists {
		t.Fatalf("accessory master link did not survive reparse: %+v", master)
	}
}

func TestComradesEquipmentClearSecondaryAndProtectPrimary(t *testing.T) {
	plain, m := loadEquipmentSample(t)
	if err := stageComradesGlaiveEquipmentSlot(m, "Weapon", 1, -1); err == nil {
		t.Fatal("expected primary weapon clear to be rejected")
	}
	old := findMasterRecord(m, "Weapons", 81)
	if old == nil {
		t.Fatal("sample weapon bank 81 missing")
	}
	if err := stageComradesGlaiveEquipmentSlot(m, "Weapon", 3, -1); err != nil {
		t.Fatal(err)
	}
	g := GeneralEdits{ControlledCharacter: m.Party.ControlledCharacter, Chapter: m.Party.Chapter, Gil: m.Party.Gil, ArenaMedals: m.Party.ArenaMedals, OracleCoins: m.Party.OracleCoins, AbilityPoints: m.Party.AbilityPoints}
	out, _, _, _, err := applyModelEdits(plain, m, g)
	if err != nil {
		t.Fatal(err)
	}
	got, err := parseSaveModelBytes(out, "equipment-clear-roundtrip.decrypted.save")
	if err != nil {
		t.Fatal(err)
	}
	slot := equippedSlotBySaveIndex(got, got.Comrades.SaveIndex, "Weapon", 3)
	if slot == nil || slot.FixID != 0 || slot.BankNumber != ^uint32(0) {
		t.Fatalf("secondary weapon slot not cleared: %+v", slot)
	}
	master := findMasterRecord(got, "Weapons", 81)
	if master == nil || master.EquipmentOwner != -1 || master.EquipmentBank != -1 {
		t.Fatalf("old weapon master link not cleared: %+v", master)
	}
}

func TestComradesRemovalRejectsActiveGlaiveWeapon(t *testing.T) {
	_, m := loadEquipmentSample(t)
	if _, err := stageComradesWeaponOwnershipState(m, 80, false); err == nil {
		t.Fatal("expected active Glaive primary weapon removal to be rejected")
	}
}
