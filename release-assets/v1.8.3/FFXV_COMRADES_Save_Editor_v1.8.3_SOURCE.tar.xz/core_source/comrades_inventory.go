package main

import (
	"errors"
	"fmt"
	"sort"
	"strings"
)

const (
	inventoryIngredients     = "Ingredients / Materials"
	inventoryConsumables     = "Consumables"
	inventoryTokens          = "Tokens"
	inventoryQuestRewards    = "Quest Rewards"
	inventoryMultiplayerMats = "Multiplayer Materials"
)

var comradesInventoryKinds = []string{
	inventoryIngredients,
	inventoryConsumables,
	inventoryTokens,
	inventoryQuestRewards,
	inventoryMultiplayerMats,
}

// Token records confirmed in the COMRADES item table / key-item list.
var comradesTokenFixIDs = map[uint32]struct{}{
	0x0107528C: {}, // Item Token
	0x01075378: {}, // Gold Item Token
}

// Quest-reward/key-reward records confirmed as COMRADES rewards. This list is
// intentionally explicit so the editor does not expose arbitrary EVENT flags
// as normal inventory ownership toggles.
var comradesQuestRewardFixIDs = map[uint32]struct{}{
	0x0106498E: {}, // Crown City Smartphone (unlocked / Bladekeeper reward)
	0x01062E89: {}, // Well-used Daggers - Tenebrae / Pyreburner reward
	0x01062E8A: {}, // Well-used Daggers - Niflheim / Bladekeeper final reward
	0x0106155C: {}, // Hunting License
	0x0106155D: {}, // Coernix Oil Key
	0x01064770: {}, // Crownsguard Sigil
	0x0105C532: {}, // The Bladekeeper's Sigil
	0x01066173: {}, // Fire Elemental Stone
	0x01066174: {}, // Ice Elemental Stone
	0x01066175: {}, // Lightning Elemental Stone
	0x010699EA: {}, // Letter to Ezma
}

func isComradesInventoryEntry(kind string, e ItemCatalogEntry) bool {
	label := gameItemLabel(e.FixID)
	switch kind {
	case inventoryIngredients:
		// COMRADES-specific cooking/food ingredient table. Crafting treasures
		// are kept in Multiplayer Materials below so the groups do not become
		// one giant duplicate list.
		return e.GameCategory == "FOOD" && strings.Contains(label, "MULTI")
	case inventoryConsumables:
		// The COMRADES consumable boost records are serialized in EVENT/key
		// inventory rather than the main-game BATTLE array.
		return e.GameCategory == "EVENT" && strings.HasPrefix(label, "MP_ITEM_BUFF_")
	case inventoryTokens:
		_, ok := comradesTokenFixIDs[e.FixID]
		return ok && e.GameCategory == "EVENT"
	case inventoryQuestRewards:
		_, ok := comradesQuestRewardFixIDs[e.FixID]
		return ok && e.GameCategory == "EVENT"
	case inventoryMultiplayerMats:
		// Enemy drops, dismantling/crafting returns and other COMRADES
		// material records all carry MULTI in the TREASURE label.
		return e.GameCategory == "TREASURE" && strings.Contains(label, "MULTI")
	default:
		return false
	}
}

func comradesInventoryEntries(kind string) []ItemCatalogEntry {
	out := make([]ItemCatalogEntry, 0)
	for _, e := range allGameItemCatalog {
		if isComradesInventoryEntry(kind, e) {
			out = append(out, e)
		}
	}
	sort.Slice(out, func(i, j int) bool {
		return strings.ToLower(itemDisplayName(out[i].FixID)) < strings.ToLower(itemDisplayName(out[j].FixID))
	})
	return out
}

func comradesInventoryRecommendedQuantity(kind string) int32 {
	switch kind {
	case inventoryQuestRewards:
		return 1
	default:
		return 99
	}
}

func comradesInventorySlot(model *SaveModel, fixID uint32) *InventorySlot {
	if model == nil {
		return nil
	}
	entry, ok := catalogEntryByFixID(fixID)
	if !ok {
		return nil
	}
	category, ok := catalogInventoryCategory(entry.GameCategory)
	if !ok {
		return nil
	}
	for i := range model.Inventory {
		s := &model.Inventory[i]
		if s.Category == category && s.FixID == fixID {
			return s
		}
	}
	return nil
}

func stageComradesInventoryItem(model *SaveModel, kind string, fixID uint32, owned bool, quantity int32) error {
	if model == nil || model.GameMode != "Comrades" {
		return errors.New("load a COMRADES gameplay0 save first")
	}
	entry, ok := catalogEntryByFixID(fixID)
	if !ok || !isComradesInventoryEntry(kind, entry) {
		return fmt.Errorf("0x%08X is not a verified %s entry", fixID, kind)
	}

	if !owned {
		slot := comradesInventorySlot(model, fixID)
		if slot == nil {
			return nil
		}
		slot.FixID = 0
		slot.Amount = 0
		return nil
	}

	if quantity < 1 || quantity > 99 {
		return fmt.Errorf("%s quantity must be 1 through 99", kind)
	}
	_, err := addGameItemToInventory(model, fixID, quantity)
	return err
}

func comradesInventoryOwnedCount(model *SaveModel, kind string) (owned, total int) {
	entries := comradesInventoryEntries(kind)
	total = len(entries)
	if model == nil {
		return 0, total
	}
	for _, e := range entries {
		if s := comradesInventorySlot(model, e.FixID); s != nil && s.Amount > 0 {
			owned++
		}
	}
	return owned, total
}
