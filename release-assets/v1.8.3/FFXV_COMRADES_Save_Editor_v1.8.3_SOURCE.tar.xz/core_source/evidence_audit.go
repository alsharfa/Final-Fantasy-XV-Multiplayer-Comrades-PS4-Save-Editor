package main

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"sort"
)

type evidenceFinding struct {
	Severity string `json:"severity"`
	Code     string `json:"code"`
	Message  string `json:"message"`
}

type evidenceInventoryCount struct {
	Kind  string `json:"kind"`
	Owned int    `json:"owned"`
	Total int    `json:"total"`
}

type evidenceWeaponObserved struct {
	Initialized   int   `json:"initialized"`
	Owned         int   `json:"owned"`
	MaxAttack     int32 `json:"maxAttack"`
	MaxVitality   int32 `json:"maxVitality"`
	MaxCritical   int32 `json:"maxCritical"`
	MaxRecoverMP  int32 `json:"maxRecoverMp"`
	MaxRank       int32 `json:"maxRank"`
	MaxSlotCount  int32 `json:"maxSlotCount"`
	UnsafeV262    int   `json:"unsafeV262Profiles"`
	NonzeroMPRefs int   `json:"nonzeroMpRecoveryRecords"`
}

type evidenceAuditView struct {
	CoreVersion          string                   `json:"coreVersion"`
	SourcePath           string                   `json:"sourcePath"`
	SourceSHA256         string                   `json:"sourceSha256"`
	SourceEncrypted      bool                     `json:"sourceEncrypted"`
	CryptoRoundTrip      string                   `json:"cryptoRoundTrip"`
	DetectedKind         string                   `json:"detectedKind"`
	GameMode             string                   `json:"gameMode"`
	FileSize             int                      `json:"fileSize"`
	SchemaOffset         int                      `json:"schemaOffset"`
	SchemaTypeCount      int                      `json:"schemaTypeCount"`
	AvatarName           string                   `json:"avatarName,omitempty"`
	SaveIndex            uint32                   `json:"saveIndex,omitempty"`
	Health               saveHealthView           `json:"health"`
	Weapons              evidenceWeaponObserved   `json:"weapons"`
	Inventory            []evidenceInventoryCount `json:"inventory"`
	CharacterAbilities   int                      `json:"characterAbilities"`
	AbilityTreeEnabled   int                      `json:"abilityTreeEnabled"`
	AbilityTreeBlocked   int                      `json:"abilityTreeReleaseBlocked"`
	SelectedJobCommandID string                   `json:"selectedJobCommandFixId,omitempty"`
	SelectedJobBank      int32                    `json:"selectedJobCommandBank,omitempty"`
	Findings             []evidenceFinding        `json:"findings"`
	Status               string                   `json:"status"`
}

func auditPlainModel(sourcePath string, source []byte, sourceEncrypted bool, cryptoRoundTrip string, detectedKind string, plain []byte) (*evidenceAuditView, error) {
	m, err := parseSaveModelBytes(plain, sourcePath)
	if err != nil {
		return nil, err
	}
	sum := sha256.Sum256(source)
	out := &evidenceAuditView{
		CoreVersion:     coreVersion,
		SourcePath:      sourcePath,
		SourceSHA256:    hex.EncodeToString(sum[:]),
		SourceEncrypted: sourceEncrypted,
		CryptoRoundTrip: cryptoRoundTrip,
		DetectedKind:    detectedKind,
		GameMode:        m.GameMode,
		FileSize:        len(source),
		SchemaOffset:    m.SchemaOffset,
		SchemaTypeCount: len(m.Types),
		Health:          buildSaveHealth(m, sourceEncrypted),
		Status:          "PASS",
	}
	if m.Comrades != nil {
		out.AvatarName = m.Comrades.Name
		out.SaveIndex = m.Comrades.SaveIndex
	}
	if m.ComradesJob != nil {
		out.SelectedJobCommandID = fmt.Sprintf("0x%08X", m.ComradesJob.FixID)
		out.SelectedJobBank = m.ComradesJob.BankNumber
	}
	if m.ComradesAbilityTree != nil {
		out.AbilityTreeEnabled = len(m.ComradesAbilityTree.Enabled)
		out.AbilityTreeBlocked = len(m.ComradesAbilityTree.ReleaseBlocked)
	}
	out.CharacterAbilities = len(m.ComradesAbilities)

	max32 := func(a, b int32) int32 {
		if b > a {
			return b
		}
		return a
	}
	for i := range m.Equipment {
		r := &m.Equipment[i]
		if r.Category != "Weapons" || r.FixID == 0 || isPlaceholderEquipment(r.FixID) {
			continue
		}
		out.Weapons.Initialized++
		if r.Exists {
			out.Weapons.Owned++
		}
		out.Weapons.MaxAttack = max32(out.Weapons.MaxAttack, r.Strength)
		out.Weapons.MaxVitality = max32(out.Weapons.MaxVitality, r.Vitality)
		out.Weapons.MaxCritical = max32(out.Weapons.MaxCritical, r.Critical)
		out.Weapons.MaxRecoverMP = max32(out.Weapons.MaxRecoverMP, r.RecoverMP)
		out.Weapons.MaxRank = max32(out.Weapons.MaxRank, r.Rank)
		out.Weapons.MaxSlotCount = max32(out.Weapons.MaxSlotCount, r.SlotCount)
		if r.RecoverMP != 0 {
			out.Weapons.NonzeroMPRefs++
		}
	}
	out.Weapons.UnsafeV262 = countUnsafeV262MaxProfiles(m)

	for _, kind := range comradesInventoryKinds {
		owned, total := comradesInventoryOwnedCount(m, kind)
		out.Inventory = append(out.Inventory, evidenceInventoryCount{Kind: kind, Owned: owned, Total: total})
	}
	sort.Slice(out.Inventory, func(i, j int) bool { return out.Inventory[i].Kind < out.Inventory[j].Kind })

	add := func(severity, code, message string) {
		out.Findings = append(out.Findings, evidenceFinding{Severity: severity, Code: code, Message: message})
		if severity == "ERROR" {
			out.Status = "FAIL"
		} else if severity == "REVIEW" && out.Status == "PASS" {
			out.Status = "REVIEW"
		}
	}

	if m.GameMode != "Comrades" {
		add("ERROR", "mode-not-comrades", fmt.Sprintf("Detected game mode %q; this project is COMRADES-only.", m.GameMode))
	}
	if out.Health.Status != "GOOD" {
		add("REVIEW", "save-health-caution", out.Health.Summary)
	}
	if out.Weapons.UnsafeV262 > 0 {
		add("ERROR", "unsafe-v262-weapon-profile", fmt.Sprintf("%d initialized weapon(s) match the retired v2.6.2 destructive 9999 pattern.", out.Weapons.UnsafeV262))
	}
	if out.Weapons.MaxAttack > comradesWeaponAttackMax || out.Weapons.MaxVitality > comradesWeaponVitalityMax || out.Weapons.MaxCritical > comradesWeaponCriticalMax {
		add("REVIEW", "direct-weapon-stat-outside-current-policy", fmt.Sprintf("Observed maxima Attack=%d Vitality=%d Critical=%d exceed the current editor policy (%d/%d/%d). Treat this as new evidence; do not normalize automatically.", out.Weapons.MaxAttack, out.Weapons.MaxVitality, out.Weapons.MaxCritical, comradesWeaponAttackMax, comradesWeaponVitalityMax, comradesWeaponCriticalMax))
	}
	if out.Weapons.NonzeroMPRefs > 0 {
		add("REVIEW", "new-nonzero-mp-recovery-evidence", fmt.Sprintf("Found %d initialized weapon record(s) with non-zero MP Recovery (max %d). This contradicts the current 'no verified non-zero reference' assumption and requires manual review before changing write policy.", out.Weapons.NonzeroMPRefs, out.Weapons.MaxRecoverMP))
	}
	if out.Weapons.MaxSlotCount > comradesWeaponSlotMax {
		add("REVIEW", "new-slot-count-evidence", fmt.Sprintf("Observed raw slot count %d exceeds the verified two serialized normal ability links. Preserve the record and review before changing policy.", out.Weapons.MaxSlotCount))
	}
	if m.ComradesJob != nil && !isDefaultComradesJobCommand(m.ComradesJob) {
		add("REVIEW", "new-selected-sigil-evidence", fmt.Sprintf("Non-default job-command tuple observed: FixID 0x%08X bank %d. This is evidence for selected-Sigil mapping and should be compared with the known equipped Sigil before enabling writes.", m.ComradesJob.FixID, m.ComradesJob.BankNumber))
	}
	if out.AbilityTreeBlocked > 0 {
		add("REVIEW", "new-ability-tree-release-block-evidence", fmt.Sprintf("Ability-tree release-block list contains %d entries. Preserve and compare against progression state before enabling tree writes.", out.AbilityTreeBlocked))
	}
	if sourceEncrypted && cryptoRoundTrip != "PASS" {
		add("ERROR", "crypto-roundtrip-failed", "Encrypted evidence did not reproduce byte-for-byte after in-memory decrypt/re-encrypt verification.")
	}
	if len(out.Findings) == 0 {
		add("INFO", "no-contradictions", "No contradictions to the current confirmed engineering findings were detected.")
	}
	return out, nil
}

func auditEvidenceFile(path string) (*evidenceAuditView, error) {
	source, normalized, err := readRegularFile(path)
	if err != nil {
		return nil, err
	}
	if kind, plainErr := detectFFXVPlainKind(source); plainErr == nil {
		return auditPlainModel(normalized, source, false, "N/A", kind, source)
	}

	intermediate, err := decryptOuterLayer(source)
	if err != nil {
		return nil, fmt.Errorf("encrypted evidence outer decrypt failed: %w", err)
	}
	plain, first, err := decodeGameplayChain(intermediate)
	if err != nil {
		return nil, fmt.Errorf("encrypted evidence gameplay-chain decode failed: %w", err)
	}
	kind, err := detectFFXVPlainKind(plain)
	if err != nil {
		return nil, err
	}
	reencoded, err := encodeGameplayChain(plain, first)
	if err != nil {
		return nil, fmt.Errorf("encrypted evidence gameplay-chain re-encode failed: %w", err)
	}
	roundTrip, err := encryptOuterLayer(reencoded)
	if err != nil {
		return nil, fmt.Errorf("encrypted evidence re-encrypt failed: %w", err)
	}
	crypto := "FAIL"
	if equalBytes(roundTrip, source) {
		crypto = "PASS"
	}
	return auditPlainModel(normalized, source, true, crypto, kind, plain)
}
