package main

import (
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"
)

// ComradesWeaponSnapshot contains only mutable weapon-instance data. Identity,
// catalog bank, ownership and equipment-link fields are intentionally excluded
// so a paste cannot silently turn one weapon into another or steal a loadout slot.
type ComradesWeaponSnapshot struct {
	Rank             int32
	Strength         int32
	Vitality         int32
	Critical         int32
	RecoverMP        int32
	SlotCount        int32
	Abilities        [2]AbilityLink
	ResidentAbility  AbilityLink
	StatusAdjust     [19]int32
	RemodelFailCount int32
}

func snapshotComradesWeapon(r *EquipmentRecord) (ComradesWeaponSnapshot, error) {
	if r == nil || r.Category != "Weapons" || r.FixID == 0 || isPlaceholderEquipment(r.FixID) {
		return ComradesWeaponSnapshot{}, errors.New("selected Comrades weapon record is invalid")
	}
	return ComradesWeaponSnapshot{
		Rank: r.Rank, Strength: r.Strength, Vitality: r.Vitality,
		Critical: r.Critical, RecoverMP: r.RecoverMP, SlotCount: r.SlotCount,
		Abilities: r.Abilities, ResidentAbility: r.ResidentAbility,
		StatusAdjust: r.StatusAdjust, RemodelFailCount: r.RemodelFailCount,
	}, nil
}

func pasteComradesWeaponSnapshot(model *SaveModel, bank int, s ComradesWeaponSnapshot) (*EquipmentRecord, error) {
	if model == nil || model.GameMode != "Comrades" {
		return nil, errors.New("load a Comrades gameplay0 save first")
	}
	r := findMasterRecord(model, "Weapons", bank)
	if r == nil || r.FixID == 0 || isPlaceholderEquipment(r.FixID) {
		return nil, errors.New("selected Comrades weapon record is invalid")
	}
	if s.Rank < 0 || s.Rank > 99 || s.SlotCount < 0 || s.SlotCount > comradesWeaponSlotMax || s.RemodelFailCount < 0 || s.RemodelFailCount > 9999 {
		return nil, errors.New("weapon clipboard contains values outside verified ranges")
	}
	if !weaponDirectStatsWithinTestedRanges(s.Strength, s.Vitality, s.Critical) {
		return nil, fmt.Errorf("weapon clipboard direct stats exceed tested editor ranges (Attack/Vitality %d, Critical %d)", comradesWeaponAttackMax, comradesWeaponCriticalMax)
	}
	if s.RecoverMP != r.RecoverMP {
		return nil, errors.New("weapon clipboard cannot change MP Recovery; that field is read-only")
	}
	if s.StatusAdjust != r.StatusAdjust {
		return nil, errors.New("weapon clipboard cannot change the 19 raw crafting/status values; they are read-only")
	}
	for i := range s.Abilities {
		if s.Abilities[i] != r.Abilities[i] && !abilityCatalogContains(s.Abilities[i].FixID) {
			return nil, fmt.Errorf("clipboard ability %d is not in the supplied verified ability database", i+1)
		}
	}
	if s.ResidentAbility != r.ResidentAbility {
		valid := false
		for _, p := range comradesResidentPresets {
			if p.FixID == s.ResidentAbility.FixID && p.Bank == s.ResidentAbility.BankNumber {
				valid = true
				break
			}
		}
		if !valid {
			return nil, errors.New("clipboard resident/passive is not one of the verified presets")
		}
	}
	r.Exists = true
	r.Rank = s.Rank
	r.Strength = s.Strength
	r.Vitality = s.Vitality
	r.Critical = s.Critical
	r.SlotCount = s.SlotCount
	r.Abilities = s.Abilities
	r.ResidentAbility = s.ResidentAbility
	r.RemodelFailCount = s.RemodelFailCount
	return r, nil
}

func stageComradesWeaponPerfect(model *SaveModel, bank int) (*EquipmentRecord, error) {
	r, err := stageComradesWeaponMaxCore(model, bank)
	if err != nil {
		return nil, err
	}
	// Preserve raw status_adjust and slot count; they are not safe bulk-max fields.
	r.RemodelFailCount = 0
	return r, nil
}

func stageComradesAllWeaponsResetRemodel(model *SaveModel) (int, error) {
	if model == nil || model.GameMode != "Comrades" {
		return 0, errors.New("load a Comrades gameplay0 save first")
	}
	n := 0
	for i := range model.Equipment {
		r := &model.Equipment[i]
		if r.Category != "Weapons" || r.FixID == 0 || isPlaceholderEquipment(r.FixID) {
			continue
		}
		r.RemodelFailCount = 0
		n++
	}
	return n, nil
}

func copyComradesSystemLoadout(m *ComradesSystemData, src, dst int) (int, error) {
	if m == nil {
		return 0, errors.New("load a decrypted Comrades system_data save first")
	}
	if src < 0 || src > 7 || dst < 0 || dst > 7 {
		return 0, errors.New("loadout index must be 0 through 7")
	}
	if src == dst {
		return 0, errors.New("source and destination loadouts are the same")
	}
	type key struct {
		kind string
		slot int
	}
	source := map[key]ComradesSystemSlot{}
	for _, s := range m.Slots {
		if s.Loadout == src {
			source[key{s.Kind, s.SlotIndex}] = s
		}
	}
	if len(source) != 7 {
		return 0, fmt.Errorf("source loadout %d does not contain all 7 equipment slots", src)
	}
	changed := 0
	for i := range m.Slots {
		d := &m.Slots[i]
		if d.Loadout != dst {
			continue
		}
		s, ok := source[key{d.Kind, d.SlotIndex}]
		if !ok {
			return changed, fmt.Errorf("source loadout %d is missing %s slot %d", src, d.Kind, d.SlotIndex)
		}
		if d.FixID != s.FixID || d.Type != s.Type || d.Category != s.Category || d.BankNumber != s.BankNumber {
			changed++
		}
		d.FixID, d.Type, d.Category, d.BankNumber = s.FixID, s.Type, s.Category, s.BankNumber
	}
	return changed, nil
}

func comradesGameplayChangeSummary(model *SaveModel) string {
	if model == nil {
		return "No gameplay0 model loaded."
	}
	var b strings.Builder
	inv, eq, weapons := 0, 0, 0
	for i := range model.Inventory {
		s := &model.Inventory[i]
		if s.FixID != s.OriginalFixID || s.Amount != s.OriginalAmount {
			inv++
		}
	}
	for i := range model.Equipment {
		r := &model.Equipment[i]
		changed := r.FixID != r.OriginalFixID || r.Type != r.OriginalType || r.Exists != r.OriginalExists ||
			r.EquipmentOwner != r.OriginalEquipmentOwner || r.EquipmentBank != r.OriginalEquipmentBank ||
			r.Rank != r.OriginalRank || r.Strength != r.OriginalStrength || r.Vitality != r.OriginalVitality ||
			r.Critical != r.OriginalCritical || r.RecoverMP != r.OriginalRecoverMP || r.SlotCount != r.OriginalSlotCount ||
			r.Abilities != r.OriginalAbilities || r.ResidentAbility != r.OriginalResidentAbility ||
			r.StatusAdjust != r.OriginalStatusAdjust || r.RemodelFailCount != r.OriginalRemodelFailCount
		if changed {
			eq++
			if r.Category == "Weapons" {
				weapons++
			}
		}
	}
	fmt.Fprintf(&b, "Staged gameplay0 records\nInventory: %d\nEquipment: %d\nWeapons: %d\n", inv, eq, weapons)
	if model.Comrades != nil {
		c := model.Comrades
		statsChanged := c.HP != c.OriginalHP || c.HPMax != c.OriginalHPMax || c.MP != c.OriginalMP || c.MPMax != c.OriginalMPMax ||
			c.Level != c.OriginalLevel || c.Strength != c.OriginalStrength || c.Vitality != c.OriginalVitality ||
			c.Magic != c.OriginalMagic || c.Spirit != c.OriginalSpirit || c.Critical != c.OriginalCritical ||
			c.Exp != c.OriginalExp || c.ExpTotal != c.OriginalExpTotal || c.AbilityPoints != c.OriginalAbilityPoints
		fmt.Fprintf(&b, "Avatar stats: %v\n", statsChanged)
	}
	if model.ComradesKW != nil {
		fmt.Fprintf(&b, "Direct kW: %d -> %d (changed: %v)\n", model.ComradesKW.Original, model.ComradesKW.Current, model.ComradesKW.Original != model.ComradesKW.Current)
	}
	return b.String()
}

func comradesSystemChangeSummary(m *ComradesSystemData) string {
	if m == nil {
		return "No system_data model loaded."
	}
	changed := 0
	byLoadout := [8]int{}
	for _, s := range m.Slots {
		if s.FixID != s.OriginalFixID || s.Type != s.OriginalType || s.Category != s.OriginalCategory || s.BankNumber != s.OriginalBankNumber {
			changed++
			if s.Loadout >= 0 && s.Loadout < len(byLoadout) {
				byLoadout[s.Loadout]++
			}
		}
	}
	var b strings.Builder
	fmt.Fprintf(&b, "Staged system_data equipment links: %d\n", changed)
	for i, n := range byLoadout {
		if n != 0 {
			fmt.Fprintf(&b, "Loadout %d: %d slot(s)\n", i, n)
		}
	}
	return b.String()
}

func verifyComradesSaveSetConsistency(s *ComradesSaveSet) (string, error) {
	if s == nil {
		return "", errors.New("no Comrades save set loaded")
	}
	gpPath := s.pathFor("gameplay0")
	sysPath := s.pathFor("system_data")
	if gpPath == "" || sysPath == "" {
		return "", errors.New("consistency check requires both gameplay0 and system_data")
	}
	gp, _, _, err := loadSaveModel(gpPath)
	if err != nil {
		return "", fmt.Errorf("open gameplay0 for consistency check: %w", err)
	}
	if gp.GameMode != "Comrades" || gp.Comrades == nil {
		return "", errors.New("gameplay0 is not a decoded Comrades save")
	}
	sys, _, _, err := loadComradesSystemData(sysPath)
	if err != nil {
		return "", fmt.Errorf("open system_data for consistency check: %w", err)
	}
	owner := int32(gp.Comrades.SaveIndex)
	warnings := 0
	var b strings.Builder
	fmt.Fprintf(&b, "COMRADES SET CONSISTENCY\nActive system_data loadout: %d\nGameplay avatar save index: %d\n\n", sys.AvatarUseNo, owner)
	for _, sslot := range sys.Slots {
		if sslot.Loadout != int(sys.AvatarUseNo) {
			continue
		}
		category := "Weapons"
		if sslot.Kind == "Accessory" {
			category = "Accessories"
		}
		r := findMasterRecord(gp, category, int(sslot.BankNumber))
		state := "OK"
		if r == nil || r.FixID != sslot.FixID || r.Type != sslot.Type {
			state = "MASTER MISMATCH"
			warnings++
		} else if !r.Exists {
			state = "NOT OWNED"
			warnings++
		} else if r.EquipmentOwner != owner || r.EquipmentBank != int32(sslot.SlotIndex-1) {
			state = "LINK MISMATCH"
			warnings++
		}
		fmt.Fprintf(&b, "%s Slot %d: %s - %s\n", sslot.Kind, sslot.SlotIndex, equipmentDisplayName(sslot.FixID), state)
	}
	if warnings == 0 {
		b.WriteString("\nResult: all 7 active equipment links agree across gameplay0 and system_data.\n")
	} else {
		fmt.Fprintf(&b, "\nResult: %d warning(s). Mirror ownership/equipment links before using forced equips.\n", warnings)
	}
	return b.String(), nil
}

func saveFamilyStem(path string) string {
	name := filepath.Base(filepath.Clean(path))
	ext := filepath.Ext(name)
	stem := strings.TrimSuffix(name, ext)
	for {
		lower := strings.ToLower(stem)
		changed := false
		for _, tag := range []string{".edited", ".decrypted", ".encrypted", ".backup", ".rollback"} {
			idx := strings.LastIndex(lower, tag)
			if idx < 0 {
				continue
			}
			rest := lower[idx+len(tag):]
			valid := rest == ""
			if strings.HasPrefix(rest, "_") && len(rest) > 1 {
				valid = true
				for _, c := range rest[1:] {
					if c < '0' || c > '9' {
						valid = false
						break
					}
				}
			}
			if valid {
				stem = stem[:idx]
				changed = true
				break
			}
		}
		if !changed {
			return strings.ToLower(stem)
		}
	}
}

func findLatestBackupInDir(path string) (string, error) {
	dir := filepath.Dir(filepath.Clean(path))
	family := saveFamilyStem(path)
	entries, err := os.ReadDir(dir)
	if err != nil {
		return "", err
	}
	type item struct {
		path string
		mod  int64
	}
	var found []item
	for _, e := range entries {
		if e.IsDir() || !strings.Contains(strings.ToLower(e.Name()), ".backup") {
			continue
		}
		candidate := filepath.Join(dir, e.Name())
		if saveFamilyStem(candidate) != family {
			continue
		}
		info, er := e.Info()
		if er != nil {
			continue
		}
		found = append(found, item{candidate, info.ModTime().UnixNano()})
	}
	if len(found) == 0 {
		return "", fmt.Errorf("no matching .backup save was found for %s", filepath.Base(path))
	}
	sort.Slice(found, func(i, j int) bool { return found[i].mod > found[j].mod })
	return found[0].path, nil
}

func findMatchingMetadataSidecar(dir string, family string, plain []byte) string {
	entries, err := os.ReadDir(dir)
	if err != nil {
		return ""
	}
	for _, e := range entries {
		if e.IsDir() || !strings.HasSuffix(strings.ToLower(e.Name()), strings.ToLower(metadataSuffix)) {
			continue
		}
		metaPath := filepath.Join(dir, e.Name())
		payloadName := strings.TrimSuffix(metaPath, metadataSuffix)
		if saveFamilyStem(payloadName) != family {
			continue
		}
		if _, err := readMetadata(metaPath, plain); err == nil {
			return metaPath
		}
	}
	return ""
}

func createRollbackCopy(selectedPath string) (string, string, error) {
	if strings.TrimSpace(selectedPath) == "" {
		return "", "", errors.New("select a save file first")
	}
	backup, err := findLatestBackupInDir(selectedPath)
	if err != nil {
		return "", "", err
	}
	data, _, err := readRegularFile(backup)
	if err != nil {
		return "", "", err
	}
	output, err := uniqueVariantPathV2(selectedPath, ".rollback")
	if err != nil {
		return "", "", err
	}
	if err := writeFileExclusive(output, data, 0o644); err != nil {
		return "", "", err
	}
	// Attach only metadata that cryptographically validates against the restored
	// plaintext. This prevents a rollback copy from inheriting a sidecar that
	// belongs to a different edit or a different Comrades save component.
	if meta := findMatchingMetadataSidecar(filepath.Dir(selectedPath), saveFamilyStem(selectedPath), data); meta != "" {
		if sidecar, er := os.ReadFile(meta); er == nil {
			_ = writeFileExclusive(output+metadataSuffix, sidecar, 0o600)
		}
	}
	return output, backup, nil
}
