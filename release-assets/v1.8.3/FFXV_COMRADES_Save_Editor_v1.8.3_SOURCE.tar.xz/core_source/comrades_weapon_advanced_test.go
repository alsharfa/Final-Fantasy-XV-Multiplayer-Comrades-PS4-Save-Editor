package main

import (
	"os"
	"testing"
)

func TestComradesWeaponAdvancedRoundTripWhenSamplePresent(t *testing.T) {
	const path = "testdata/gameplay0.decrypted.save"
	plain, err := os.ReadFile(path)
	if os.IsNotExist(err) {
		t.Skip("uploaded COMRADES sample not present")
	}
	if err != nil {
		t.Fatal(err)
	}
	m, err := parseSaveModelBytes(plain, path)
	if err != nil {
		t.Fatal(err)
	}
	r := findMasterRecord(m, "Weapons", 73)
	if r == nil {
		t.Fatal("weapon bank 73 missing")
	}

	var ability uint32
	for _, a := range abilityCatalog {
		if a.FixID != r.Abilities[1].FixID && isVerifiedComradesWeaponAbility(a.FixID) && a.FixID != 0x01009E27 {
			ability = a.FixID
			break
		}
	}
	if ability == 0 {
		t.Fatal("no verified COMRADES weapon ability found")
	}

	adjustments := r.StatusAdjust
	originalAdjustments := r.StatusAdjust
	_, err = stageComradesWeaponAdvanced(m, 73, comradesWeaponAdvancedEdits{
		Ability1:            r.Abilities[0].FixID,
		Ability2:            ability,
		ResidentAbility:     r.ResidentAbility.FixID,
		ResidentAbilityBank: r.ResidentAbility.BankNumber,
		StatusAdjust:        adjustments,
	})
	if err != nil {
		t.Fatal(err)
	}
	if r.Abilities[1].FixID != ability || r.Abilities[1].BankNumber != -1 || r.StatusAdjust != originalAdjustments {
		t.Fatalf("advanced values not staged: %+v", r)
	}

	g := GeneralEdits{ControlledCharacter: m.Party.ControlledCharacter, Chapter: m.Party.Chapter, Gil: m.Party.Gil, ArenaMedals: m.Party.ArenaMedals, OracleCoins: m.Party.OracleCoins, AbilityPoints: m.Party.AbilityPoints}
	out, _, _, _, err := applyModelEdits(plain, m, g)
	if err != nil {
		t.Fatal(err)
	}
	got, err := parseSaveModelBytes(out, "weapon-advanced.decrypted.save")
	if err != nil {
		t.Fatal(err)
	}
	w := findMasterRecord(got, "Weapons", 73)
	if w == nil || w.Abilities[1].FixID != ability || w.Abilities[1].BankNumber != -1 || w.StatusAdjust != originalAdjustments {
		t.Fatalf("advanced values did not survive reparse: %+v", w)
	}
}

func TestComradesWeaponAdvancedRejectsUnsafeAbility(t *testing.T) {
	r := EquipmentRecord{Category: "Weapons", CategoryIndex: 1, FixID: 0x01000001, Abilities: [2]AbilityLink{{FixID: 0x01009E27, BankNumber: -1}, {FixID: 0x01009E27, BankNumber: -1}}, ResidentAbility: AbilityLink{FixID: 0x01009E27, BankNumber: -1}}
	m := &SaveModel{GameMode: "Comrades", Equipment: []EquipmentRecord{r}}
	_, err := stageComradesWeaponAdvanced(m, 1, comradesWeaponAdvancedEdits{
		Ability1:            0x0102ACC3, // JOB_COMMAND_TEMPEST: in DB, but not a weapon enchantment
		Ability2:            0x01009E27,
		ResidentAbility:     0x01009E27,
		ResidentAbilityBank: -1,
	})
	if err == nil {
		t.Fatal("expected non-ENC ability to be rejected")
	}
}

func TestComradesWeaponAdvancedRejectsNewRawZero(t *testing.T) {
	r := EquipmentRecord{Category: "Weapons", CategoryIndex: 1, FixID: 0x01000001, Abilities: [2]AbilityLink{{FixID: 0x01009E27, BankNumber: -1}, {FixID: 0x01009E27, BankNumber: -1}}, ResidentAbility: AbilityLink{FixID: 0x01009E27, BankNumber: -1}}
	m := &SaveModel{GameMode: "Comrades", Equipment: []EquipmentRecord{r}}
	_, err := stageComradesWeaponAdvanced(m, 1, comradesWeaponAdvancedEdits{
		Ability1:            0,
		Ability2:            0x01009E27,
		ResidentAbility:     0x01009E27,
		ResidentAbilityBank: -1,
	})
	if err == nil {
		t.Fatal("expected raw zero overwrite to be rejected")
	}
}
