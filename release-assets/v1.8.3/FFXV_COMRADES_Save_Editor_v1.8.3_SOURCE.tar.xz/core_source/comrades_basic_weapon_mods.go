package main

import (
	"errors"
	"fmt"
)

// Hidden/internal weapon masters verified against the supplied Comrades save.
// Both bank and FixID must match before the editor will expose an ownership write.
type comradesHiddenWeaponDef struct {
	Bank  int
	FixID uint32
	Name  string
}

var comradesHiddenModdedWeapons = []comradesHiddenWeaponDef{
	{77, 0x01025FF7, "Stoss Spear"},
	{78, 0x0101AA4A, "Kotetsu"},
	{79, 0x0103248F, "Kikuichimonji"},
	{80, 0x0105B505, "Katana"},
	{81, 0x0105B506, "Daggers"},
	{82, 0x01066216, "Lucian Saber"},
}

func isComradesHiddenModdedBank(bank int) bool {
	for _, d := range comradesHiddenModdedWeapons {
		if bank == d.Bank {
			return true
		}
	}
	return false
}

func verifiedComradesHiddenWeapon(model *SaveModel, d comradesHiddenWeaponDef) (*EquipmentRecord, error) {
	if model == nil || model.GameMode != "Comrades" {
		return nil, errors.New("load a Comrades gameplay0 save first")
	}
	r := findMasterRecord(model, "Weapons", d.Bank)
	if r == nil || r.FixID == 0 || isPlaceholderEquipment(r.FixID) {
		return nil, fmt.Errorf("%s: weapon bank %d is not initialized", d.Name, d.Bank)
	}
	if r.FixID != d.FixID {
		return nil, fmt.Errorf("%s: bank %d FixID mismatch (found 0x%08X, expected 0x%08X); write refused", d.Name, d.Bank, r.FixID, d.FixID)
	}
	return r, nil
}

// stageComradesHiddenModdedPack owns only the six records whose exact verified
// bank+FixID pair matches. No new weapon payload is synthesized.
func stageComradesHiddenModdedPack(model *SaveModel) (int, error) {
	changed := 0
	for _, d := range comradesHiddenModdedWeapons {
		r, err := verifiedComradesHiddenWeapon(model, d)
		if err != nil {
			return changed, err
		}
		if !r.Exists {
			r.Exists = true
			changed++
		}
	}
	return changed, nil
}

type comradesWeaponEditableStats struct {
	Rank             int32
	Strength         int32
	Vitality         int32
	Critical         int32
	RecoverMP        int32
	SlotCount        int32
	RemodelFailCount int32
}

// stageComradesWeaponCustomStats writes only the user-facing scalar weapon
// fields exposed by Forge v1.1. Ability links and all 19 crafting adjustments
// are deliberately preserved. Existing internal ranks above 99 (for example
// the verified rank-200/300 masters) may be preserved, but new >99 ranks are
// refused because the save writer has no evidence that retail weapons accept
// arbitrary high-rank values.
func stageComradesWeaponCustomStats(model *SaveModel, bank int, v comradesWeaponEditableStats) (*EquipmentRecord, error) {
	if model == nil || model.GameMode != "Comrades" {
		return nil, errors.New("load a Comrades gameplay0 save first")
	}
	r := findMasterRecord(model, "Weapons", bank)
	if r == nil || r.FixID == 0 || isPlaceholderEquipment(r.FixID) {
		return nil, errors.New("selected Comrades weapon record is not initialized")
	}
	if v.Rank < 0 || (v.Rank > 99 && v.Rank != r.OriginalRank) {
		return nil, fmt.Errorf("rank must be 0–99; existing internal rank %d may only be preserved", r.OriginalRank)
	}
	limits := map[string]struct {
		value int32
		max   int32
	}{
		"Attack":   {v.Strength, comradesWeaponAttackMax},
		"Vitality": {v.Vitality, comradesWeaponVitalityMax},
		"Critical": {v.Critical, comradesWeaponCriticalMax},
	}
	for name, lim := range limits {
		if lim.value < 0 || lim.value > lim.max {
			return nil, fmt.Errorf("%s must be between 0 and %d", name, lim.max)
		}
	}
	if v.RecoverMP < 0 || v.RecoverMP > 9999 {
		return nil, errors.New("MP Recovery must be between 0 and 9999")
	}
	if v.SlotCount < 0 || v.SlotCount > comradesWeaponSlotMax {
		return nil, fmt.Errorf("raw slot field must be between 0 and %d", comradesWeaponSlotMax)
	}
	if v.RemodelFailCount < 0 || v.RemodelFailCount > 9999 {
		return nil, errors.New("remodel fails must be between 0 and 9999")
	}
	r.Rank = v.Rank
	r.Strength = v.Strength
	r.Vitality = v.Vitality
	r.Critical = v.Critical
	r.RecoverMP = v.RecoverMP
	r.SlotCount = v.SlotCount
	r.RemodelFailCount = v.RemodelFailCount
	return r, nil
}

// Direct-stat MOD changes only the direct scalar fields. Identity, rank, slots,
// abilities, visible crafting bonuses (status_adjust) and remodel state are preserved.
// Attack is user-unlocked to 99,999; this does not imply that extreme values produce
// proportional real combat damage in-game.
func stageComradesWeaponSafeModPreset(model *SaveModel, bank int) (*EquipmentRecord, error) {
	if model == nil || model.GameMode != "Comrades" {
		return nil, errors.New("load a Comrades gameplay0 save first")
	}
	r := findMasterRecord(model, "Weapons", bank)
	if r == nil || r.FixID == 0 || isPlaceholderEquipment(r.FixID) {
		return nil, errors.New("selected Comrades weapon record is not initialized")
	}
	r.Exists = true
	r.Strength = comradesWeaponAttackMax
	r.Vitality = comradesWeaponVitalityMax
	r.Critical = comradesWeaponCriticalMax
	// MP Recovery is intentionally preserved: no initialized reference weapon
	// establishes a safe non-zero cap for this field.
	return r, nil
}

// MAX MOD is intentionally aggressive. It is separate from Safe MOD so special
// weapons (Royal Arms/internal masters) are not altered structurally by default.
func stageComradesWeaponMaxModPreset(model *SaveModel, bank int) (*EquipmentRecord, error) {
	r, err := stageComradesWeaponSafeModPreset(model, bank)
	if err != nil {
		return nil, err
	}
	// Rank, slot count, raw status_adjust values and remodel state are preserved.
	// They are not homogeneous damage stats and forcing them to synthetic maxima
	// produced invalid in-game behavior in v2.6.2.
	return r, nil
}

// Compatibility name retained for older tests/callers: the old "MOD" behavior
// corresponds to the explicit MAX preset in Forge.
func stageComradesWeaponModPreset(model *SaveModel, bank int) (*EquipmentRecord, error) {
	return stageComradesWeaponMaxModPreset(model, bank)
}

func stageComradesAllInitializedWeaponOwnership(model *SaveModel) (changed, total int, err error) {
	if model == nil || model.GameMode != "Comrades" {
		return 0, 0, errors.New("load a Comrades gameplay0 save first")
	}
	for i := range model.Equipment {
		r := &model.Equipment[i]
		if r.Category != "Weapons" || r.FixID == 0 || isPlaceholderEquipment(r.FixID) {
			continue
		}
		total++
		if !r.Exists {
			r.Exists = true
			changed++
		}
	}
	return changed, total, nil
}

func stageComradesAllInitializedWeaponSafeMods(model *SaveModel) (int, error) {
	if model == nil || model.GameMode != "Comrades" {
		return 0, errors.New("load a Comrades gameplay0 save first")
	}
	count := 0
	for i := range model.Equipment {
		r := &model.Equipment[i]
		if r.Category != "Weapons" || r.FixID == 0 || isPlaceholderEquipment(r.FixID) {
			continue
		}
		if _, err := stageComradesWeaponSafeModPreset(model, r.CategoryIndex); err != nil {
			return count, err
		}
		count++
	}
	return count, nil
}

func stageComradesAllInitializedWeaponMaxMods(model *SaveModel) (int, error) {
	if model == nil || model.GameMode != "Comrades" {
		return 0, errors.New("load a Comrades gameplay0 save first")
	}
	count := 0
	for i := range model.Equipment {
		r := &model.Equipment[i]
		if r.Category != "Weapons" || r.FixID == 0 || isPlaceholderEquipment(r.FixID) {
			continue
		}
		if _, err := stageComradesWeaponMaxModPreset(model, r.CategoryIndex); err != nil {
			return count, err
		}
		count++
	}
	return count, nil
}

func stageComradesAllInitializedWeaponMods(model *SaveModel) (int, error) {
	return stageComradesAllInitializedWeaponMaxMods(model)
}
