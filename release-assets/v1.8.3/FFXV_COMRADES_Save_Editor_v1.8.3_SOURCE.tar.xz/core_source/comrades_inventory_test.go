package main

import (
	"os"
	"testing"
)

func TestComradesInventoryCatalogCoverage(t *testing.T) {
	want := map[string]int{
		inventoryIngredients:     50,
		inventoryConsumables:     64,
		inventoryTokens:          2,
		inventoryQuestRewards:    11,
		inventoryMultiplayerMats: 230,
	}
	for kind, count := range want {
		entries := comradesInventoryEntries(kind)
		if len(entries) != count {
			t.Fatalf("%s entries=%d, want %d", kind, len(entries), count)
		}
		for _, e := range entries {
			if _, ok := catalogInventoryCategory(e.GameCategory); !ok {
				t.Fatalf("%s contains non-writable record 0x%08X (%s)", kind, e.FixID, e.GameCategory)
			}
			if itemDisplayName(e.FixID) == "" {
				t.Fatalf("%s has unnamed FixID 0x%08X", kind, e.FixID)
			}
		}
	}
}

func TestComradesInventorySyntheticOwnedToggle(t *testing.T) {
	entry := comradesInventoryEntries(inventoryIngredients)[0]
	category, ok := catalogInventoryCategory(entry.GameCategory)
	if !ok {
		t.Fatal("ingredient category is not writable")
	}
	m := &SaveModel{GameMode: "Comrades", Inventory: make([]InventorySlot, 8)}
	for i := range m.Inventory {
		m.Inventory[i] = InventorySlot{Category: category, CategoryIndex: i, OriginalFixID: 0, OriginalAmount: 0}
	}

	if err := stageComradesInventoryItem(m, inventoryIngredients, entry.FixID, true, 47); err != nil {
		t.Fatal(err)
	}
	s := comradesInventorySlot(m, entry.FixID)
	if s == nil || s.Amount != 47 {
		t.Fatalf("ingredient not staged: %+v", s)
	}
	if err := stageComradesInventoryItem(m, inventoryIngredients, entry.FixID, false, 47); err != nil {
		t.Fatal(err)
	}
	if s.FixID != 0 || s.Amount != 0 {
		t.Fatalf("ingredient not removed: %+v", s)
	}
}

func TestComradesInventoryRemovalRoundTripWhenSamplePresent(t *testing.T) {
	const path = "testdata/gameplay0.decrypted.save"
	input, err := os.ReadFile(path)
	if os.IsNotExist(err) {
		t.Skip("uploaded COMRADES sample not present")
	}
	if err != nil {
		t.Fatal(err)
	}
	m, err := parseSaveModelBytes(input, path)
	if err != nil {
		t.Fatal(err)
	}

	var target uint32
	for _, e := range comradesInventoryEntries(inventoryMultiplayerMats) {
		if s := comradesInventorySlot(m, e.FixID); s != nil && s.Amount > 0 {
			target = e.FixID
			break
		}
	}
	if target == 0 {
		t.Skip("no owned multiplayer material in sample")
	}
	if err := stageComradesInventoryItem(m, inventoryMultiplayerMats, target, false, 0); err != nil {
		t.Fatal(err)
	}

	g := GeneralEdits{
		ControlledCharacter: m.Party.ControlledCharacter,
		Chapter:             m.Party.Chapter,
		Gil:                 m.Party.Gil,
		ArenaMedals:         m.Party.ArenaMedals,
		OracleCoins:         m.Party.OracleCoins,
		AbilityPoints:       m.Party.AbilityPoints,
	}
	out, _, invChanges, _, err := applyModelEdits(input, m, g)
	if err != nil {
		t.Fatal(err)
	}
	if invChanges < 1 {
		t.Fatal("expected at least one inventory change")
	}
	got, err := parseSaveModelBytes(out, "inventory-remove.decrypted.save")
	if err != nil {
		t.Fatal(err)
	}
	if s := comradesInventorySlot(got, target); s != nil && s.Amount > 0 {
		t.Fatalf("removed material 0x%08X still owned after reparse: %+v", target, s)
	}
}

func TestComradesInventoryAddRoundTripWhenSamplePresent(t *testing.T) {
	const path = "testdata/gameplay0.decrypted.save"
	input, err := os.ReadFile(path)
	if os.IsNotExist(err) {
		t.Skip("uploaded COMRADES sample not present")
	}
	if err != nil {
		t.Fatal(err)
	}
	m, err := parseSaveModelBytes(input, path)
	if err != nil {
		t.Fatal(err)
	}

	var target uint32
	for _, e := range comradesInventoryEntries(inventoryTokens) {
		if s := comradesInventorySlot(m, e.FixID); s == nil || s.Amount == 0 {
			target = e.FixID
			break
		}
	}
	if target == 0 {
		// If both tokens already exist, use a missing consumable instead.
		for _, e := range comradesInventoryEntries(inventoryConsumables) {
			if s := comradesInventorySlot(m, e.FixID); s == nil || s.Amount == 0 {
				target = e.FixID
				break
			}
		}
	}
	if target == 0 {
		t.Skip("no missing inventory candidate in sample")
	}

	kind := inventoryTokens
	if e, _ := catalogEntryByFixID(target); !isComradesInventoryEntry(kind, e) {
		kind = inventoryConsumables
	}
	if err := stageComradesInventoryItem(m, kind, target, true, 37); err != nil {
		t.Fatal(err)
	}

	g := GeneralEdits{
		ControlledCharacter: m.Party.ControlledCharacter,
		Chapter:             m.Party.Chapter,
		Gil:                 m.Party.Gil,
		ArenaMedals:         m.Party.ArenaMedals,
		OracleCoins:         m.Party.OracleCoins,
		AbilityPoints:       m.Party.AbilityPoints,
	}
	out, _, _, _, err := applyModelEdits(input, m, g)
	if err != nil {
		t.Fatal(err)
	}
	got, err := parseSaveModelBytes(out, "inventory-add.decrypted.save")
	if err != nil {
		t.Fatal(err)
	}
	s := comradesInventorySlot(got, target)
	if s == nil || s.Amount != 37 {
		t.Fatalf("added item 0x%08X failed reparse: %+v", target, s)
	}
}

func TestComradesInventoryAddAllGroupsFitSampleWhenPresent(t *testing.T) {
	const path = "testdata/gameplay0.decrypted.save"
	input, err := os.ReadFile(path)
	if os.IsNotExist(err) {
		t.Skip("uploaded COMRADES sample not present")
	}
	if err != nil {
		t.Fatal(err)
	}
	m, err := parseSaveModelBytes(input, path)
	if err != nil {
		t.Fatal(err)
	}
	for _, kind := range comradesInventoryKinds {
		qty := comradesInventoryRecommendedQuantity(kind)
		for _, e := range comradesInventoryEntries(kind) {
			if err := stageComradesInventoryItem(m, kind, e.FixID, true, qty); err != nil {
				t.Fatalf("%s add-all failed at 0x%08X: %v", kind, e.FixID, err)
			}
		}
	}
	g := GeneralEdits{
		ControlledCharacter: m.Party.ControlledCharacter,
		Chapter:             m.Party.Chapter,
		Gil:                 m.Party.Gil,
		ArenaMedals:         m.Party.ArenaMedals,
		OracleCoins:         m.Party.OracleCoins,
		AbilityPoints:       m.Party.AbilityPoints,
	}
	out, _, _, _, err := applyModelEdits(input, m, g)
	if err != nil {
		t.Fatal(err)
	}
	got, err := parseSaveModelBytes(out, "inventory-all.decrypted.save")
	if err != nil {
		t.Fatal(err)
	}
	for _, kind := range comradesInventoryKinds {
		owned, total := comradesInventoryOwnedCount(got, kind)
		if owned != total {
			t.Fatalf("%s owned=%d/%d after add-all reparse", kind, owned, total)
		}
	}
}
