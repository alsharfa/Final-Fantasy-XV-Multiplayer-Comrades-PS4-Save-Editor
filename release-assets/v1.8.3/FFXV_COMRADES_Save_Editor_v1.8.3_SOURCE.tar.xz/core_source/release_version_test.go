package main

import "testing"

func TestCoreVersionMatchesWPFRelease(t *testing.T) {
	const want = "2.8.0-wpf"
	if coreVersion != want {
		t.Fatalf("coreVersion=%q, want %q", coreVersion, want)
	}
}
