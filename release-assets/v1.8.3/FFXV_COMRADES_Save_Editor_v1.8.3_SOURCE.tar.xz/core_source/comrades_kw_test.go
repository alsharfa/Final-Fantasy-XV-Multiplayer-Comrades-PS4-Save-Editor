package main

import (
	"encoding/binary"
	"testing"
)

func syntheticKWModel(value uint32) ([]byte, *SaveModel) {
	const marker = 0x40
	data := make([]byte, 0x400)
	t := SchemaType{
		Name: comradesKWTypeName,
		Hash: 0x1122334455667788,
		Fields: []SchemaField{
			{Name: "reserved_", TypeName: "int", Size: 200},
			{Name: "plantMapData_", TypeName: "Black.Save.Multiplay.SavePlantMapDataStruct", Size: 4004},
		},
	}
	binary.LittleEndian.PutUint64(data[marker:marker+8], t.Hash)
	binary.LittleEndian.PutUint32(data[marker+comradesKWOffsetFromMarker:marker+comradesKWOffsetFromMarker+4], value)
	kw, err := parseComradesKW(data, len(data), []SchemaType{t})
	if err != nil {
		panic(err)
	}
	return data, &SaveModel{GameMode: "Comrades", ComradesKW: kw, Types: []SchemaType{t}, SchemaOffset: len(data)}
}

func TestParseComradesKWVerifiedRelativeOffset(t *testing.T) {
	_, m := syntheticKWModel(1320)
	if m.ComradesKW.Current != 1320 {
		t.Fatalf("got %d", m.ComradesKW.Current)
	}
	if m.ComradesKW.ValueOffset-m.ComradesKW.MarkerOffset != comradesKWOffsetFromMarker {
		t.Fatalf("relative offset = 0x%X", m.ComradesKW.ValueOffset-m.ComradesKW.MarkerOffset)
	}
}

func TestStageAndRestoreComradesKW(t *testing.T) {
	_, m := syntheticKWModel(200)
	if err := stageComradesKW(m, 1320); err != nil {
		t.Fatal(err)
	}
	if m.ComradesKW.Current != 1320 {
		t.Fatalf("staged %d", m.ComradesKW.Current)
	}
	restoreComradesKW(m)
	if m.ComradesKW.Current != 200 {
		t.Fatalf("restored %d", m.ComradesKW.Current)
	}
}

func TestComradesKWRejectsUnsignedOverflow(t *testing.T) {
	_, m := syntheticKWModel(200)
	if err := stageComradesKW(m, maxComradesKW+1); err == nil {
		t.Fatal("expected range error")
	}
}
