package main

import (
	"os"
	"testing"
)

func TestComradesCollectionCatalogCoverage(t *testing.T) {
	want := map[string]int{
		collectionTreasures:   230,
		collectionBarter:      52,
		collectionPhrasebooks: 19,
		collectionAvatar:      56,
		collectionClothing:    84,
		collectionKeyItems:    27,
	}
	for kind, count := range want {
		entries := comradesCollectionEntries(kind)
		if len(entries) != count {
			t.Fatalf("%s entries=%d, want %d", kind, len(entries), count)
		}
		for _, e := range entries {
			if _, ok := catalogInventoryCategory(e.GameCategory); !ok {
				t.Fatalf("%s contains non-writable inventory record 0x%08X (%s)", kind, e.FixID, e.GameCategory)
			}
			if itemDisplayName(e.FixID) == "" {
				t.Fatalf("%s has unnamed FixID 0x%08X", kind, e.FixID)
			}
		}
	}
}

func TestComradesCollectionBulkRoundTripWhenSamplePresent(t *testing.T) {
	const path = "testdata/gameplay0_decrypted(2).save"
	plain, err := os.ReadFile(path)
	if os.IsNotExist(err) {
		t.Skip("uploaded Comrades sample not present")
	}
	if err != nil {
		t.Fatal(err)
	}
	m, err := parseSaveModelBytes(plain, path)
	if err != nil {
		t.Fatal(err)
	}
	if m.GameMode != "Comrades" {
		t.Fatalf("mode=%q", m.GameMode)
	}

	for _, kind := range comradesCollectionKinds {
		if _, err := stageComradesCollectionAll(m, kind); err != nil {
			t.Fatalf("stage %s: %v", kind, err)
		}
		qty := comradesCollectionRecommendedQuantity(kind)
		for _, e := range comradesCollectionEntries(kind) {
			s := comradesCollectionInventorySlot(m, e.FixID)
			if s == nil || (kind == collectionBarter && s.Amount <= 0) || (kind != collectionBarter && s.Amount != qty) {
				t.Fatalf("%s 0x%08X not staged at %d: %+v", kind, e.FixID, qty, s)
			}
		}
	}

	g := GeneralEdits{
		ControlledCharacter: m.Party.ControlledCharacter,
		Chapter:             m.Party.Chapter,
		Gil:                 m.Party.Gil,
		ArenaMedals:         m.Party.ArenaMedals,
		OracleCoins:         m.Party.OracleCoins,
		AbilityPoints:       m.Party.AbilityPoints,
	}
	out, _, invChanges, _, err := applyModelEdits(plain, m, g)
	if err != nil {
		t.Fatal(err)
	}
	if invChanges < 100 {
		t.Fatalf("inventory changes=%d, expected collection bulk changes", invChanges)
	}
	got, err := parseSaveModelBytes(out, "collections-roundtrip.decrypted.save")
	if err != nil {
		t.Fatal(err)
	}
	for _, kind := range comradesCollectionKinds {
		qty := comradesCollectionRecommendedQuantity(kind)
		owned, total := comradesCollectionOwnedCount(got, kind)
		if owned != total {
			t.Fatalf("%s owned=%d/%d after reparse", kind, owned, total)
		}
		for _, e := range comradesCollectionEntries(kind) {
			s := comradesCollectionInventorySlot(got, e.FixID)
			if s == nil || (kind == collectionBarter && s.Amount <= 0) || (kind != collectionBarter && s.Amount != qty) {
				t.Fatalf("%s 0x%08X failed save reparse: %+v", kind, e.FixID, s)
			}
		}
	}
}

func TestComradesCollectionRestoreNewInsert(t *testing.T) {
	m := &SaveModel{GameMode: "Comrades", Inventory: make([]InventorySlot, 64)}
	for i := range m.Inventory {
		m.Inventory[i].Category = "Battle Items"
		m.Inventory[i].CategoryIndex = i
		m.Inventory[i].OriginalFixID = 0
		m.Inventory[i].OriginalAmount = 0
	}
	e := comradesCollectionEntries(collectionPhrasebooks)[0]
	s, err := stageComradesCollectionItem(m, collectionPhrasebooks, e.FixID, 1)
	if err != nil {
		t.Fatal(err)
	}
	if s.FixID != e.FixID || s.Amount != 1 {
		t.Fatalf("not staged: %+v", s)
	}
	if n := restoreComradesCollection(m, collectionPhrasebooks); n != 1 {
		t.Fatalf("restored=%d, want 1", n)
	}
	if s.FixID != 0 || s.Amount != 0 {
		t.Fatalf("new insert did not restore to empty: %+v", s)
	}
}

func TestComradesCollectionsSurviveEncryptedRoundTripWhenPairPresent(t *testing.T) {
	const encryptedPath = "testdata/gameplay0(20260821-145222).save"
	const plainPath = "testdata/gameplay0.decrypted.save"
	encrypted, err := os.ReadFile(encryptedPath)
	if os.IsNotExist(err) {
		t.Skip("encrypted COMRADES sample not present")
	}
	if err != nil {
		t.Fatal(err)
	}
	plain, err := os.ReadFile(plainPath)
	if os.IsNotExist(err) {
		t.Skip("plaintext COMRADES sample not present")
	}
	if err != nil {
		t.Fatal(err)
	}
	m, err := parseSaveModelBytes(plain, plainPath)
	if err != nil {
		t.Fatal(err)
	}
	for _, kind := range comradesCollectionKinds {
		if _, err := stageComradesCollectionAll(m, kind); err != nil {
			t.Fatalf("stage %s: %v", kind, err)
		}
	}
	g := GeneralEdits{
		ControlledCharacter: m.Party.ControlledCharacter,
		Chapter:             m.Party.Chapter,
		Gil:                 m.Party.Gil,
		ArenaMedals:         m.Party.ArenaMedals,
		OracleCoins:         m.Party.OracleCoins,
		AbilityPoints:       m.Party.AbilityPoints,
	}
	edited, _, _, _, err := applyModelEdits(plain, m, g)
	if err != nil {
		t.Fatal(err)
	}

	mid, err := decryptOuterLayer(encrypted)
	if err != nil {
		t.Fatal(err)
	}
	_, first, err := decodeGameplayChain(mid)
	if err != nil {
		t.Fatal(err)
	}

	d := t.TempDir()
	editedPath := d + "/gameplay0.edited.save"
	if err := os.WriteFile(editedPath, edited, 0o600); err != nil {
		t.Fatal(err)
	}
	if err := writeMetadataExclusive(editedPath+metadataSuffix, makeMetadata(encrypted, plain, first)); err != nil {
		t.Fatal(err)
	}
	res, err := processFile(editedPath, false)
	if err != nil {
		t.Fatal(err)
	}
	encOut, err := os.ReadFile(res.OutputPath)
	if err != nil {
		t.Fatal(err)
	}
	outMid, err := decryptOuterLayer(encOut)
	if err != nil {
		t.Fatal(err)
	}
	recovered, _, err := decodeGameplayChain(outMid)
	if err != nil {
		t.Fatal(err)
	}
	got, err := parseSaveModelBytes(recovered, res.OutputPath)
	if err != nil {
		t.Fatal(err)
	}
	for _, kind := range comradesCollectionKinds {
		owned, total := comradesCollectionOwnedCount(got, kind)
		if owned != total {
			t.Fatalf("%s encrypted round-trip owned=%d/%d", kind, owned, total)
		}
		wantQty := comradesCollectionRecommendedQuantity(kind)
		for _, e := range comradesCollectionEntries(kind) {
			s := comradesCollectionInventorySlot(got, e.FixID)
			if s == nil || (kind == collectionBarter && s.Amount <= 0) || (kind != collectionBarter && s.Amount != wantQty) {
				t.Fatalf("%s 0x%08X encrypted round-trip quantity=%v want=%d", kind, e.FixID, s, wantQty)
			}
		}
	}
}
