package main

import (
	"os"
	"testing"
)

func TestEvidenceAuditPlaintextFixtureWhenPresent(t *testing.T) {
	const path = "testdata/gameplay0.decrypted.save"
	if _, err := os.Stat(path); os.IsNotExist(err) {
		t.Skip("private plaintext evidence fixture not present")
	}
	a, err := auditEvidenceFile(path)
	if err != nil {
		t.Fatal(err)
	}
	if a.SourceEncrypted {
		t.Fatal("plaintext fixture reported encrypted")
	}
	if a.GameMode != "Comrades" || a.Weapons.Initialized == 0 {
		t.Fatalf("unexpected audit: %+v", a)
	}
	if a.Weapons.UnsafeV262 != 0 {
		t.Fatalf("reference evidence unexpectedly matches unsafe v2.6.2 profile: %+v", a.Weapons)
	}
}

func TestEvidenceAuditEncryptedFixtureIsReadOnlyAndRoundTripsWhenPresent(t *testing.T) {
	const path = "testdata/gameplay0(20260821-145222).save"
	before, err := os.ReadFile(path)
	if os.IsNotExist(err) {
		t.Skip("private encrypted evidence fixture not present")
	}
	if err != nil {
		t.Fatal(err)
	}
	a, err := auditEvidenceFile(path)
	if err != nil {
		t.Fatal(err)
	}
	if !a.SourceEncrypted || a.CryptoRoundTrip != "PASS" {
		t.Fatalf("unexpected encrypted audit: %+v", a)
	}
	after, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	if !equalBytes(before, after) {
		t.Fatal("audit mutated encrypted evidence input")
	}
}

func TestEvidenceAuditFlagsRetiredV262Pattern(t *testing.T) {
	status := [19]int32{}
	for i := range status {
		status[i] = 9999
	}
	m := &SaveModel{Equipment: []EquipmentRecord{{Category: "Weapons", Exists: true, FixID: 0x01000001, StatusAdjust: status}}}
	if got := countUnsafeV262MaxProfiles(m); got != 1 {
		t.Fatalf("unsafe profile count=%d, want 1", got)
	}
}
