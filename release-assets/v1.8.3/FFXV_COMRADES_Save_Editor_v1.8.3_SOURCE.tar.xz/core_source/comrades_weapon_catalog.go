package main

type ComradesWeaponCatalogEntry struct {
	FixID uint32
	Type  uint32
	Bank  int32
	Name  string
}

var comradesWeaponCatalog = []ComradesWeaponCatalogEntry{
	{FixID: 0x0104CFDC, Type: 0, Bank: 0, Name: "Alba Leonis"},
	{FixID: 0x0104CFD8, Type: 4, Bank: 1, Name: "Lion Heart"},
	{FixID: 0x0104CFE7, Type: 1, Bank: 2, Name: "Dodanuki"},
	{FixID: 0x0104CFE8, Type: 1, Bank: 3, Name: "Cactuar Mace"},
	{FixID: 0x0104CFEB, Type: 0, Bank: 4, Name: "Crowbar"},
	{FixID: 0x0104CFE9, Type: 28, Bank: 5, Name: "Crowbar"},
	{FixID: 0x0101AA26, Type: 0, Bank: 6, Name: "???"},
	{FixID: 0x01036600, Type: 0, Bank: 7, Name: "Blazefire Saber"},
	{FixID: 0x0104CFEA, Type: 0, Bank: 8, Name: "Blazefire Saber XV"},
	{FixID: 0x0104CFD3, Type: 0, Bank: 9, Name: "Ragnarok"},
	{FixID: 0x0106AEF4, Type: 0, Bank: 10, Name: "Sarah's Shortsword"},
	{FixID: 0x0104CFF0, Type: 0, Bank: 11, Name: "Garuda's Gaze"},
	{FixID: 0x0104CFEC, Type: 0, Bank: 12, Name: "Gaze of the Vortex"},
	{FixID: 0x0104CFD4, Type: 1, Bank: 13, Name: "Afrosword"},
	{FixID: 0x0103660D, Type: 1, Bank: 14, Name: "Masamune"},
	{FixID: 0x0104CFD7, Type: 1, Bank: 15, Name: "Genji Blade"},
	{FixID: 0x0104CFF1, Type: 1, Bank: 16, Name: "Garuda's Pain"},
	{FixID: 0x0104CFED, Type: 1, Bank: 17, Name: "Pain of the Vortex"},
	{FixID: 0x0104CFD5, Type: 1, Bank: 18, Name: "Mutant Rakshasa Blade"},
	{FixID: 0x0103661A, Type: 2, Bank: 19, Name: "Gae Bolg"},
	{FixID: 0x01036627, Type: 3, Bank: 20, Name: "Mage Mashers"},
	{FixID: 0x0104CFE0, Type: 3, Bank: 21, Name: "Spelldaggers"},
	{FixID: 0x0104CFF2, Type: 3, Bank: 22, Name: "Garuda's Plumes"},
	{FixID: 0x0104CFEE, Type: 3, Bank: 23, Name: "Plumes of the Vortex"},
	{FixID: 0x0104CFDA, Type: 4, Bank: 24, Name: "Lion Heart"},
	{FixID: 0x0106AEF3, Type: 4, Bank: 25, Name: "Garuda's Abandon"},
	{FixID: 0x0104CFEF, Type: 4, Bank: 26, Name: "Abandon of the Vortex"},
	{FixID: 0x0104CFDB, Type: 5, Bank: 27, Name: "Medjay Assassin's Shield"},
	{FixID: 0x0106AEF6, Type: 5, Bank: 28, Name: "Alien Shield"},
	{FixID: 0x01035DAA, Type: 6, Bank: 29, Name: "Circular Saw"},
	{FixID: 0x0104CFDD, Type: 2, Bank: 30, Name: "Trident of the Oracle"},
	{FixID: 0x0104CFDE, Type: 2, Bank: 31, Name: "DLC 011"},
	{FixID: 0x0104CFDF, Type: 2, Bank: 32, Name: "DLC 012"},
	{FixID: 0x0102CEDB, Type: 0, Bank: 33, Name: "Toy Sword"},
	{FixID: 0x010264E6, Type: 0, Bank: 34, Name: "Squeaky Hammer"},
	{FixID: 0x01031117, Type: 1, Bank: 35, Name: "Supersized Squeaky Hammer"},
	{FixID: 0x0105282C, Type: 3, Bank: 36, Name: "Twin Squeaky Hammers"},
	{FixID: 0x0104CFE1, Type: 8, Bank: 37, Name: "Rapidus SMG"},
	{FixID: 0x0104CFE2, Type: 10, Bank: 38, Name: "Alea Bazooka"},
	{FixID: 0x0104CFE3, Type: 9, Bank: 39, Name: "Lumen Flare"},
	{FixID: 0x0104CFE4, Type: 31, Bank: 40, Name: "Katana"},
	{FixID: 0x0104CFE5, Type: 3, Bank: 41, Name: "Daggers"},
	{FixID: 0x0104CFD6, Type: 0, Bank: 42, Name: "DLC 003"},
	{FixID: 0x0104CFD9, Type: 0, Bank: 43, Name: "DLC 006"},
	{FixID: 0x0106AEF7, Type: 0, Bank: 44, Name: "DLC 036"},
	{FixID: 0x0106AEF8, Type: 0, Bank: 45, Name: "DLC 037"},
	{FixID: 0x0106AEF9, Type: 0, Bank: 46, Name: "DLC 038"},
	{FixID: 0x0106AEFA, Type: 0, Bank: 47, Name: "DLC 039"},
	{FixID: 0x0106AEFB, Type: 0, Bank: 48, Name: "DLC 040"},
	{FixID: 0x0106AEFC, Type: 0, Bank: 49, Name: "DLC 041"},
	{FixID: 0x0106AEFD, Type: 0, Bank: 50, Name: "DLC 042"},
	{FixID: 0x0106AEFE, Type: 0, Bank: 51, Name: "DLC 043"},
	{FixID: 0x0106AEFF, Type: 0, Bank: 52, Name: "DLC 044"},
	{FixID: 0x0106AF00, Type: 0, Bank: 53, Name: "DLC 045"},
	{FixID: 0x0106AF01, Type: 0, Bank: 54, Name: "DLC 046"},
	{FixID: 0x0106AF02, Type: 0, Bank: 55, Name: "DLC 047"},
	{FixID: 0x0106AF03, Type: 0, Bank: 56, Name: "DLC 048"},
	{FixID: 0x0106AF04, Type: 0, Bank: 57, Name: "DLC 049"},
	{FixID: 0x0106AF05, Type: 0, Bank: 58, Name: "DLC 050"},
	{FixID: 0x0106AF06, Type: 0, Bank: 59, Name: "DLC 051"},
	{FixID: 0x0106AF07, Type: 0, Bank: 60, Name: "DLC 052"},
	{FixID: 0x0106AF08, Type: 0, Bank: 61, Name: "DLC 053"},
	{FixID: 0x0106AF09, Type: 0, Bank: 62, Name: "DLC 054"},
	{FixID: 0x0106AF0A, Type: 0, Bank: 63, Name: "DLC 055"},
	{FixID: 0x0106AF0B, Type: 0, Bank: 64, Name: "DLC 056"},
	{FixID: 0x0106AF0C, Type: 0, Bank: 65, Name: "DLC 057"},
	{FixID: 0x0106AF0D, Type: 0, Bank: 66, Name: "DLC 058"},
	{FixID: 0x0106AF0E, Type: 0, Bank: 67, Name: "DLC 059"},
	{FixID: 0x0106AF0F, Type: 0, Bank: 68, Name: "DLC 060"},
	{FixID: 0x0106AF10, Type: 0, Bank: 69, Name: "DLC 061"},
	{FixID: 0x0106AF11, Type: 0, Bank: 70, Name: "DLC 062"},
	{FixID: 0x0106AF12, Type: 0, Bank: 71, Name: "DLC 063"},
	{FixID: 0x0104CFE6, Type: 0, Bank: 72, Name: "Sarah's Shortsword"},
	{FixID: 0x01035677, Type: 20, Bank: 73, Name: "Sword of the Wise"},
	{FixID: 0x01035678, Type: 21, Bank: 74, Name: "Axe of the Conqueror"},
	{FixID: 0x0103567A, Type: 23, Bank: 75, Name: "Swords of the Wanderer"},
	{FixID: 0x0103567B, Type: 24, Bank: 76, Name: "Blade of the Mystic"},
	{FixID: 0x01025FF7, Type: 2, Bank: 77, Name: "Stoss Spear"},
	{FixID: 0x0101AA4A, Type: 0, Bank: 78, Name: "Kotetsu"},
	{FixID: 0x0103248F, Type: 3, Bank: 79, Name: "Kikuichimonji"},
	{FixID: 0x0105B505, Type: 31, Bank: 80, Name: "Katana"},
	{FixID: 0x0105B506, Type: 3, Bank: 81, Name: "Daggers"},
	{FixID: 0x01066216, Type: 31, Bank: 82, Name: "Lucian Saber"},
}

func comradesWeaponCatalogByBank(bank int32) *ComradesWeaponCatalogEntry {
	for i := range comradesWeaponCatalog {
		if comradesWeaponCatalog[i].Bank == bank {
			return &comradesWeaponCatalog[i]
		}
	}
	return nil
}
func comradesWeaponCatalogByFixID(id uint32) *ComradesWeaponCatalogEntry {
	for i := range comradesWeaponCatalog {
		if comradesWeaponCatalog[i].FixID == id {
			return &comradesWeaponCatalog[i]
		}
	}
	return nil
}

type ComradesResidentPreset struct {
	Name  string
	FixID uint32
	Bank  int32
}

// Resident/passive ability banks are a weapon-local table, not the global
// ability database. Only pairs observed in the supplied Comrades gameplay0 are
// exposed for writes.
var comradesResidentPresets = []ComradesResidentPreset{
	{"None", 0x01009E27, -1},
	{"Sword of the Wise intrinsic", 0x0101B5A1, 0},
	{"Axe of the Conqueror intrinsic", 0x0101B5A2, 1},
	{"Swords of the Wanderer intrinsic", 0x0101B5A4, 2},
	{"Blade of the Mystic intrinsic", 0x0101B5A5, 3},
}
