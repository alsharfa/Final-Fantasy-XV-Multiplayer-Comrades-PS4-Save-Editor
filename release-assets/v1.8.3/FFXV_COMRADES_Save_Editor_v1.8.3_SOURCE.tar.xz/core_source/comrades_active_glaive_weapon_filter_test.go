package main

import "testing"

func TestAvailableToActiveGlaiveFiltersOtherOwners(t *testing.T) {
	m := &SaveModel{
		GameMode: "Comrades",
		Comrades: &ComradesStatus{SaveIndex: 11},
	}
	unassigned := &EquipmentRecord{Category: "Weapons", CategoryIndex: 81, FixID: 0x0105B506, Exists: true, EquipmentOwner: -1}
	active := &EquipmentRecord{Category: "Weapons", CategoryIndex: 82, FixID: 0x01066216, Exists: true, EquipmentOwner: 11, EquipmentBank: 0}
	other := &EquipmentRecord{Category: "Weapons", CategoryIndex: 73, FixID: 0x01035677, Exists: true, EquipmentOwner: 4, EquipmentBank: 0}
	missing := &EquipmentRecord{Category: "Weapons", CategoryIndex: 80, FixID: 0x0105B505, Exists: false, EquipmentOwner: -1}

	if !availableToActiveGlaive(m, unassigned) {
		t.Fatal("owned unassigned player weapon should be available to active Glaive")
	}
	if !availableToActiveGlaive(m, active) {
		t.Fatal("weapon linked to active Glaive should be available")
	}
	if availableToActiveGlaive(m, other) {
		t.Fatal("weapon assigned to another avatar must not appear in active Glaive weapon list")
	}
	if availableToActiveGlaive(m, missing) {
		t.Fatal("missing unassigned weapon must not appear in active Glaive weapon list")
	}
}

func TestActiveLoadoutTupleKeepsWeaponVisibleWhenMasterOwnerLinkIsBroken(t *testing.T) {
	m := &SaveModel{
		GameMode: "Comrades",
		Comrades: &ComradesStatus{SaveIndex: 11},
		Equipped: []EquippedSlot{{SaveIndex: 11, Kind: "Weapon", SlotIndex: 2, FixID: 0x0105B506, BankNumber: 84}},
	}
	r := &EquipmentRecord{Category: "Weapons", CategoryIndex: 84, FixID: 0x0105B506, Exists: false, EquipmentOwner: -1}
	if !equippedByActiveGlaive(m, r) {
		t.Fatal("active SaveStatusStruct weapon tuple should identify the equipped weapon")
	}
	if !availableToActiveGlaive(m, r) {
		t.Fatal("active equipped weapon should stay visible even with inconsistent master ownership state")
	}
}
