package main

import (
	"os"
	"testing"
)

func TestComradesGameplayDecryptRecoversEBB01WhenPresent(t *testing.T) {
	candidates := []string{
		"testdata/gameplay0(20260820-171535).save",
		"testdata/gameplay0(20260820-165114).save",
		"testdata/gameplay0(20260820-164627).save",
	}
	var encrypted []byte
	var path string
	var err error
	for _, p := range candidates {
		encrypted, err = os.ReadFile(p)
		if err == nil {
			path = p
			break
		}
		if !os.IsNotExist(err) {
			t.Fatal(err)
		}
	}
	if path == "" {
		t.Skip("controlled Comrades encrypted gameplay0 sample not present")
	}

	intermediate, err := decryptOuterLayer(encrypted)
	if err != nil {
		t.Fatal(err)
	}
	plain, first, err := decodeGameplayChain(intermediate)
	if err != nil {
		t.Fatal(err)
	}
	if len(plain) < 4 || plain[0] != 0x65 || plain[1] != 0x62 || plain[2] != 0x62 || plain[3] != 0x01 {
		t.Fatalf("decrypted gameplay0 header = % X, want 65 62 62 01", plain[:4])
	}
	kind, err := detectFFXVPlainKind(plain)
	if err != nil {
		t.Fatal(err)
	}
	if kind != "Comrades gameplay0" {
		t.Fatalf("kind=%q, want Comrades gameplay0", kind)
	}
	encoded, err := encodeGameplayChain(plain, first)
	if err != nil {
		t.Fatal(err)
	}
	round, err := encryptOuterLayer(encoded)
	if err != nil {
		t.Fatal(err)
	}
	if !equalBytes(round, encrypted) {
		t.Fatal("corrected EBB01 plaintext did not re-encrypt byte-for-byte to the source")
	}
}
