package main

import "testing"

func TestV270HealthGoodForSyntheticComradesModel(t *testing.T) {
	kw := &ComradesKWData{Current: 1234}
	m := &SaveModel{
		GameMode: "Comrades", FileSize: footerSize + 4096, SchemaOffset: 2048,
		Comrades: &ComradesStatus{Name: "Test Glaive"}, ComradesKW: kw,
		Inventory: []InventorySlot{{}}, Equipped: []EquippedSlot{{}},
		Equipment: []EquipmentRecord{{Category: "Weapons", FixID: 0x010365FD}},
	}
	h := buildSaveHealth(m, true)
	if h.Status != "GOOD" || h.Confidence != "HIGH" {
		t.Fatalf("unexpected health: %+v", h)
	}
	if len(h.Checks) < 8 {
		t.Fatalf("expected detailed health checks, got %d", len(h.Checks))
	}
	for _, c := range h.Checks {
		if c.Status != "PASS" {
			t.Fatalf("unexpected warning: %+v", c)
		}
	}
}

func TestV270HealthCautionsOnMissingOptionalStructures(t *testing.T) {
	m := &SaveModel{GameMode: "Comrades", FileSize: footerSize + 100, SchemaOffset: 64}
	h := buildSaveHealth(m, false)
	if h.Status != "CAUTION" || h.Confidence != "MEDIUM" {
		t.Fatalf("unexpected health: %+v", h)
	}
}
