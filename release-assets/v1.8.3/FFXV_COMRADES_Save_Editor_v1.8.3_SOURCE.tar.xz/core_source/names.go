package main

import (
	"fmt"
	"strings"
	"unicode"
)

var friendlyItemNames = map[string]string{
	"POTION":          "Potion",
	"HIPOTION":        "Hi-Potion",
	"MEGAPOTION":      "Mega-Potion",
	"PHOENIX":         "Phoenix Down",
	"PHOENIX_FEATHER": "Mega Phoenix",
	"ELIXIR":          "Elixir",
	"HI_ELIXIR":       "Hi-Elixir",
	"LAST_ELIXIR":     "Megalixir",
	"ETHER":           "Ether",
	"ANTIDOTE":        "Antidote",
	"REMEDY":          "Remedy",
}

var friendlyEquipmentNames = map[uint32]string{
	0x010365FD: "Engine Blade",
	0x0104CFD3: "Ragnarok",
	0x0103783D: "Magitek Suit V2",
	0x0104CFB6: "Tech Turbocharger",
}

func gameItemLabel(fixID uint32) string {
	if fixID == 0 {
		return "EMPTY"
	}
	if s, ok := itemGameLabels[fixID]; ok && s != "" {
		return s
	}
	return ""
}

func gameEquipmentLabel(fixID uint32) string {
	if fixID == 0 {
		return "EMPTY"
	}
	if s, ok := equipmentGameLabels[fixID]; ok && s != "" {
		return s
	}
	return ""
}

func isPlaceholderEquipment(fixID uint32) bool {
	label := strings.ToUpper(strings.TrimSpace(gameEquipmentLabel(fixID)))
	return fixID == 0 || label == "NONE" || label == "EMPTY" || label == "NULL"
}

func isPlaceholderCloth(fixID uint32) bool {
	label := strings.ToUpper(strings.TrimSpace(gameClothLabel(fixID)))
	return fixID == 0 || label == "NONE" || label == "EMPTY" || label == "NULL"
}

func itemDisplayName(fixID uint32) string {
	if fixID == 0 {
		return "Empty"
	}
	if name, ok := itemEnglishNames[fixID]; ok && name != "" {
		return name
	}
	label := gameItemLabel(fixID)
	if name, ok := friendlyItemNames[label]; ok {
		return name
	}
	if label != "" {
		return prettyGameLabel(label)
	}
	return fmt.Sprintf("Unknown item 0x%08X", fixID)
}

func equipmentDisplayName(fixID uint32) string {
	if fixID == 0 {
		return "Empty"
	}
	if name, ok := equipmentEnglishNames[fixID]; ok && name != "" {
		return name
	}
	if name, ok := friendlyEquipmentNames[fixID]; ok {
		return name
	}
	label := gameEquipmentLabel(fixID)
	if label != "" {
		return prettyGameLabel(label)
	}
	return fmt.Sprintf("Unknown equipment 0x%08X", fixID)
}

func gameClothLabel(fixID uint32) string {
	if fixID == 0 {
		return "EMPTY"
	}
	if s, ok := clothGameLabels[fixID]; ok && s != "" {
		return s
	}
	return ""
}

func clothDisplayName(fixID uint32) string {
	if fixID == 0 {
		return "Empty"
	}
	if name, ok := clothEnglishNames[fixID]; ok && name != "" {
		return name
	}
	label := gameClothLabel(fixID)
	if label != "" {
		return prettyGameLabel(label)
	}
	return fmt.Sprintf("Unknown attire 0x%08X", fixID)
}

func prettyGameLabel(label string) string {
	if label == "" {
		return "Unknown"
	}
	parts := strings.Split(label, "_")
	for i, p := range parts {
		if p == "" {
			continue
		}
		// Keep compact technical tokens (WE01, DLC, EPG, FF14, IDs) intact.
		hasDigit := false
		allDigits := true
		for _, r := range p {
			if unicode.IsDigit(r) {
				hasDigit = true
			} else {
				allDigits = false
			}
		}
		if allDigits || hasDigit || len(p) <= 3 {
			parts[i] = p
			continue
		}
		lower := strings.ToLower(p)
		parts[i] = strings.ToUpper(lower[:1]) + lower[1:]
	}
	return strings.Join(parts, " ")
}
