# Validation — v1.8.3 Chocobo UI Cleanup

Frontend-only cleanup over the validated v1.8.2 Chocobo mapping. The Exineris **SET REQUIREMENT** preset and its callback were removed; direct Chocobo stat editing and **MAX ALL** remain. Core/save-writing code is unchanged.

Validated against the supplied live encrypted `gameplay0(20260918-154201).save`, whose in-game screenshot shows Black Chocobo 46/50 and Blue Chocobo 20/30.

## Live parse verification

After decrypt/open with the corrected parser:

- Black Chocobo / NameID `0x0B01D0C1`: Level `46/50`, Limit Max `70`, Skill Level `1`, Stamina `82`, Jump `202`, Top Speed `40.531433 mph`, Injury `0`.
- Blue Chocobo / NameID `0x0B01D0C3`: Level `20/30`, Limit Max `50`, Skill Level `1`, Stamina `23`, Jump `24`, Top Speed `22.0 mph`, Injury `0`.

The Blue values match the supplied Training screenshot exactly. The save contains four serialized chocobo records even though two are visible in the supplied Training screen; visibility/registration semantics for the extra records are not yet proven, so v1.8.2 does not add/create/delete records.

## Real-save write verification

A controlled MAX ALL edit was applied to the Blue Chocobo only:

- Level / Level Cap / Limit Max: `99 / 99 / 99`
- Stamina: `300`
- Jump: `300`
- Top Speed: `90.0 mph`
- Injury: `0`
- Skill Level preserved at `1`

Backend verification result: `PASS`

- Model read-back: PASS
- Protected fields: PASS
- Equipment integrity: PASS
- Save size preserved: true
- Footer preserved: true
- Unexpected byte changes: `0`
- Encryption round trip: PASS
- Changed bytes: `9`

All other serialized chocobo records remained unchanged.

## Automated checks

- Python `py_compile`: PASS
- `go test ./...`: PASS
- `go vet ./...`: PASS
- `go test -race ./...`: PASS

## Important correction from v1.8.0

The schema reports logical offsets, but ChocoboDataStruct contains fixed arrays serialized with 4-byte count prefixes. This shifts later physical fields by 12 bytes. The two consecutive bools are also bit-packed. v1.8.0 therefore read/wrote the wrong bytes for level-related fields. v1.8.2 corrects those physical offsets and validates them against live save data.
