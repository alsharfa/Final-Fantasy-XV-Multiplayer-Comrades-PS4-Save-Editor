# Changelog

## v1.8.3 — Chocobo UI Cleanup

- Removed the **SET REQUIREMENT** / Exineris requirement preset from the Chocobo page.
- Chocobo editing now focuses on direct stat editing, **MAX ALL**, Apply, and Reload Current Values.
- No Chocobo record creation was added. Existing registered records only.
- Backend/save mappings are unchanged from v1.8.2.

## v1.8.2 — Real Chocobo Mapping Fix + MAX ALL

- Corrected the physical serialized offsets for Chocobo Current Level, Level Cap, Limit Max Level, Skill Level, Injury %, packed flags, and Training Rate Count.
- The previous v1.8.0 parser incorrectly treated logical schema offsets as physical offsets after fixed-size serialized arrays.
- Verified against the supplied live gameplay0: Black Chocobo reads 46/50 (limit 70) and Blue Chocobo reads 20/30 (limit 50), matching the in-game screenshot.
- Verified Blue Chocobo performance stats from the live save: Stamina 23, Jump 24, Top Speed 22.0 mph.
- Added Chocobo **MAX ALL** preset: Level/Cap/Limit 99, Stamina 300, Jump 300, Top Speed 90.0 mph, Injury 0%.
- No Add Chocobo function is included. Only existing serialized chocobo records can be edited.
- Added verified display names for NameID 0x0B01D0C1 (Black Chocobo) and 0x0B01D0C3 (Blue Chocobo). Unknown IDs remain generic instead of being guessed.

## v1.8.0

- Added initial Chocobo Stats page and structural writer support.
