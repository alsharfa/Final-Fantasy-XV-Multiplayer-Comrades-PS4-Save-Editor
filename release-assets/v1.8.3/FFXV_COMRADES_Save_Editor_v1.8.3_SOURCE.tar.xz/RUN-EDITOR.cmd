@echo off
setlocal
cd /d "%~dp0"
python -c "import sys; raise SystemExit(0 if sys.version_info >= (3,11) else 1)" >nul 2>&1 || (
  echo ERROR: Python 3.11 or newer is required.
  pause
  exit /b 1
)
start "" pythonw FFXV_COMRADES_Save_Editor.pyw
