from __future__ import annotations

import shutil
import sys
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk
from typing import Any

from forge_core import CoreError, ForgeCore

APP_NAME = "FFXV COMRADES Save Editor"
APP_VERSION = "1.8.3"
EXPECTED_CORE_VERSION = "2.8.0-wpf"

BG = "#F3F7FC"
PANEL = "#FFFFFF"
PANEL2 = "#EAF2FB"
PANEL3 = "#F8FBFF"
TEXT = "#102A43"
MUTED = "#60758A"
ACCENT = "#0A84FF"
ACCENT2 = "#006EDC"
NAVY = "#0A1D31"
NAVY2 = "#173B5E"
GOLD = "#D8A62A"
GOLD2 = "#B88618"
GOOD = "#18A55B"
WARN = "#C77A00"
DANGER = "#C83A3A"
BORDER = "#D5E1EE"


def resource_path(relative: str) -> Path:
    base = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))
    return base / relative

# Weapon ability IDs whose in-game COMRADES names have been verified against
# the user's controlled before/after saves.  Do not guess additional ID/name
# pairs: the backend raw ENC_* labels are internal identifiers and are not
# reliable substitutes for the localized names shown by the game.
VERIFIED_WEAPON_ABILITIES: dict[int, str] = {
    0x01009E27: "None",
    # Verified from the user's in-game test plus the controlled Parrying Daggers
    # save: the game's visible ability order is the reverse of the two serialized
    # SaveWeaponStruct links.  0x0105E7CA renders as Penetrator X and
    # 0x0105CE8F renders as Punisher II.
    0x0105E7CA: "Penetrator X",
    0x0105CE8F: "Punisher II",
}

VERIFIED_WEAPON_ABILITY_DESCRIPTIONS: dict[int, str] = {
    0x01009E27: "None — no weapon ability.",
    0x0105E7CA: "Penetrator X — verified in-game name (FixID 0x0105E7CA).",
    0x0105CE8F: "Punisher II — verified in-game name (FixID 0x0105CE8F).",
}



def parse_int(value: str, name: str, minimum: int = 0, maximum: int = 2_147_483_647) -> int:
    try:
        result = int(value.strip().replace(",", ""), 10)
    except ValueError as exc:
        raise ValueError(f"{name} must be a whole number.") from exc
    if result < minimum or result > maximum:
        raise ValueError(f"{name} must be between {minimum:,} and {maximum:,}.")
    return result


def parse_float(value: str, name: str, minimum: float = 0.0, maximum: float = 999.9) -> float:
    try:
        result = float(value.strip().replace(",", ""))
    except ValueError as exc:
        raise ValueError(f"{name} must be a number.") from exc
    if result < minimum or result > maximum:
        raise ValueError(f"{name} must be between {minimum:g} and {maximum:g}.")
    return result


class ScrollFrame(ttk.Frame):
    def __init__(self, master: tk.Misc):
        super().__init__(master)
        canvas = tk.Canvas(self, bg=BG, highlightthickness=0, bd=0)
        bar = ttk.Scrollbar(self, orient="vertical", command=canvas.yview)
        self.body = ttk.Frame(canvas)
        window = canvas.create_window((0, 0), window=self.body, anchor="nw")
        self.body.bind("<Configure>", lambda _e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>", lambda e: canvas.itemconfigure(window, width=e.width))
        canvas.configure(yscrollcommand=bar.set)
        canvas.pack(side="left", fill="both", expand=True)
        bar.pack(side="right", fill="y")


class EditorApp(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title(f"{APP_NAME} v{APP_VERSION}")
        screen_w = max(1, self.winfo_screenwidth())
        screen_h = max(1, self.winfo_screenheight())
        self.compact_height = screen_h <= 760
        self.initial_window_width = min(1400, max(1000, screen_w - 40))
        initial_height = min(880, max(680, screen_h - 30))
        self.geometry(f"{self.initial_window_width}x{initial_height}")
        self.minsize(min(1000, self.initial_window_width), min(680, initial_height))
        self.configure(bg=BG)
        try:
            self.iconphoto(True, tk.PhotoImage(file=str(resource_path("assets/app_icon.png"))))
        except tk.TclError:
            pass
        self.core = ForgeCore()
        self.core_ready = False
        self.core_version = ""
        self.summary: dict[str, Any] | None = None
        self.plain_path: Path | None = None
        self.source_path: Path | None = None
        self.avatar_summary: dict[str, Any] | None = None
        self.avatar_plain_path: Path | None = None
        self.avatar_source_path: Path | None = None
        self.export_outputs: dict[str, tuple[Path, bool]] = {}
        self.catalog_rows: list[dict[str, Any]] | None = None
        self.last_output_path: Path | None = None
        self.last_verification: dict[str, Any] = {}
        self.last_output_encrypted = False
        self.edits: dict[str, Any] = {}
        self.collection_edits: dict[int, dict[str, Any]] = {}
        self.inventory_edits: dict[int, dict[str, Any]] = {}
        self.sigil_edits: dict[int, dict[str, Any]] = {}
        self.ability_edits: dict[int, dict[str, Any]] = {}
        self.weapon_edits: dict[int, dict[str, Any]] = {}
        self.chocobo_edits: dict[int, dict[str, Any]] = {}
        self.unexported_kinds: set[str] = set()
        self._style()
        self._build_shell()
        self.protocol("WM_DELETE_WINDOW", self._on_close)
        self.bind_all("<Control-o>", lambda _e: self.open_save())
        self.bind_all("<Control-O>", lambda _e: self.open_save())
        self.bind_all("<Control-Shift-O>", lambda _e: self.load_avatar())
        self.bind_all("<Control-s>", lambda _e: self.save_current())
        self.bind_all("<Control-S>", lambda _e: self.save_current())
        self.show_page("Dashboard")
        self.after(100, self._check_core)

    def _style(self) -> None:
        s = ttk.Style(self)
        try:
            s.theme_use("clam")
        except tk.TclError:
            pass

        # Base surfaces
        s.configure(".", background=BG, foreground=TEXT, fieldbackground=PANEL, bordercolor=BORDER, lightcolor=BORDER, darkcolor=BORDER)
        s.configure("TFrame", background=BG)
        s.configure("Content.TFrame", background=BG)
        s.configure("HeaderTools.TFrame", background=PANEL)
        s.configure("Sidebar.TFrame", background="#F7FAFE")
        s.configure("Card.TFrame", background=PANEL, borderwidth=1, relief="solid")
        s.configure("SoftCard.TFrame", background=PANEL3, borderwidth=1, relief="solid")

        # Text
        s.configure("TLabel", background=BG, foreground=TEXT, font=("Segoe UI", 10))
        s.configure("Muted.TLabel", foreground=MUTED, background=BG, font=("Segoe UI", 9))
        s.configure("Card.TLabel", background=PANEL, foreground=TEXT)
        s.configure("SoftCard.TLabel", background=PANEL3, foreground=TEXT)
        s.configure("Title.TLabel", font=("Segoe UI Semibold", 22), foreground=TEXT, background=BG)
        s.configure("Section.TLabel", font=("Segoe UI Semibold", 14), foreground=TEXT)
        s.configure("Value.TLabel", font=("Segoe UI Semibold", 18), foreground=TEXT, background=PANEL)
        s.configure("ToolbarStatus.TLabel", background=PANEL, foreground=MUTED, font=("Segoe UI", 9))
        s.configure("ToolbarGood.TLabel", background=PANEL, foreground=GOOD, font=("Segoe UI Semibold", 9))
        s.configure("Footer.TLabel", background="#EAF1F8", foreground=MUTED, font=("Segoe UI", 9))
        s.configure("SidebarMuted.TLabel", background="#F7FAFE", foreground=MUTED, font=("Segoe UI", 9))
        s.configure("SidebarBody.TLabel", background="#F7FAFE", foreground=TEXT, font=("Segoe UI", 9))

        # Buttons
        s.configure("TButton", padding=(12, 7), font=("Segoe UI Semibold", 10), background=PANEL, foreground=TEXT, bordercolor=BORDER, focusthickness=0)
        s.map("TButton", background=[("active", PANEL2), ("pressed", "#DCEAF9")])
        s.configure("Accent.TButton", padding=(14, 8), background=ACCENT, foreground="white", borderwidth=0, focusthickness=0)
        s.map("Accent.TButton", background=[("active", ACCENT2), ("pressed", "#005EBB")], foreground=[("disabled", "#DCE8F6")])
        s.configure("Gold.TButton", padding=(14, 8), background="#F0C75E", foreground="#2B2414", borderwidth=1, bordercolor="#D4A942")
        s.map("Gold.TButton", background=[("active", "#E7B944"), ("pressed", "#D9A831")])
        s.configure("Toolbar.TButton", padding=(13, 8), background=PANEL, foreground=TEXT, bordercolor=BORDER)
        s.map("Toolbar.TButton", background=[("active", PANEL2)])
        s.configure("Sidebar.TButton", anchor="w", padding=(18, 12), background="#F7FAFE", foreground=NAVY2, borderwidth=0, font=("Segoe UI Semibold", 10))
        s.map("Sidebar.TButton", background=[("active", "#E7F1FC")])
        s.configure("SidebarSelected.TButton", anchor="w", padding=(18, 12), background=ACCENT, foreground="white", borderwidth=0, font=("Segoe UI Semibold", 10))
        s.map("SidebarSelected.TButton", background=[("active", ACCENT2)], foreground=[("active", "white")])

        # Inputs
        s.configure("TEntry", padding=8, fieldbackground=PANEL, foreground=TEXT, insertcolor=TEXT, bordercolor=BORDER, relief="solid")
        s.configure("TCombobox", padding=7, fieldbackground=PANEL, foreground=TEXT, bordercolor=BORDER)
        s.configure("TCheckbutton", background=BG, foreground=TEXT)
        s.configure("Treeview", background=PANEL, fieldbackground=PANEL, foreground=TEXT, rowheight=31, borderwidth=1, bordercolor=BORDER)
        s.configure("Treeview.Heading", background=PANEL2, foreground=TEXT, font=("Segoe UI Semibold", 9), relief="flat")
        s.map("Treeview", background=[("selected", "#DCEEFF")], foreground=[("selected", TEXT)])
        s.configure("TLabelframe", background=PANEL, foreground=TEXT, bordercolor=BORDER, relief="solid")
        s.configure("TLabelframe.Label", background=PANEL, foreground=TEXT, font=("Segoe UI Semibold", 11))
        s.configure("TNotebook", background=BG, borderwidth=0)
        s.configure("TNotebook.Tab", background=PANEL2, foreground=TEXT, padding=(12, 7))
        s.map("TNotebook.Tab", background=[("selected", PANEL)], foreground=[("selected", TEXT)])
        self.option_add("*TCombobox*Listbox.background", PANEL)
        self.option_add("*TCombobox*Listbox.foreground", TEXT)

    def _build_shell(self) -> None:
        # Branded FFXV COMRADES banner, based on the approved modern UI mock-up.
        banner_height = 64 if self.compact_height else 90
        banner = tk.Frame(self, bg=NAVY, height=banner_height)
        banner.pack(fill="x")
        banner.pack_propagate(False)
        try:
            if self.compact_height:
                header_asset = "assets/comrades_header_1240_64.png" if self.initial_window_width <= 1280 else "assets/comrades_header_64.png"
            else:
                header_asset = "assets/comrades_header_1240_90.png" if self.initial_window_width <= 1280 else "assets/comrades_header_90.png"
            self.header_image = tk.PhotoImage(file=str(resource_path(header_asset)))
            tk.Label(banner, image=self.header_image, bg=NAVY, bd=0).pack(fill="x")
        except tk.TclError:
            fallback = tk.Frame(banner, bg=NAVY)
            fallback.pack(fill="both", expand=True)
            tk.Label(fallback, text="FINAL FANTASY XV  COMRADES", bg=NAVY, fg="white", font=("Segoe UI Semibold", 25)).pack(side="left", padx=28)
            tk.Label(fallback, text="SAVE EDITOR", bg=NAVY, fg="#D7E9FA", font=("Segoe UI Semibold", 15)).pack(side="right", padx=34)

        # File toolbar/status row.
        tools = ttk.Frame(self, style="HeaderTools.TFrame", padding=(18, 4 if self.compact_height else 7))
        tools.pack(fill="x")
        self.open_btn = ttk.Button(tools, text="▣  OPEN GAMEPLAY0", style="Toolbar.TButton", command=self.open_save, state="disabled")
        self.open_btn.pack(side="left", padx=(0, 8))
        self.avatar_btn = ttk.Button(tools, text="▣  LOAD AVATAR0", style="Toolbar.TButton", command=self.load_avatar, state="disabled")
        self.avatar_btn.pack(side="left", padx=(0, 12))
        self.gameplay_status = ttk.Label(tools, text="○ gameplay0 not loaded", style="ToolbarStatus.TLabel")
        self.gameplay_status.pack(side="left", padx=(8, 16))
        self.avatar_status = ttk.Label(tools, text="○ avatar0 not loaded", style="ToolbarStatus.TLabel")
        self.avatar_status.pack(side="left", padx=(0, 16))
        self.file_label = ttk.Label(tools, text="", style="ToolbarStatus.TLabel")
        self.file_label.pack(side="left", fill="x", expand=True)
        self.save_state_label = ttk.Label(tools, text="", style="ToolbarStatus.TLabel")
        self.save_state_label.pack(side="right", padx=(0, 8))
        self.save_btn = ttk.Button(tools, text="▣  SAVE FILES...", style="Accent.TButton", command=self.save_current, state="disabled")
        self.save_btn.pack(side="right", padx=(8, 0))

        body = ttk.Frame(self, style="Content.TFrame")
        body.pack(fill="both", expand=True)

        side = ttk.Frame(body, style="Sidebar.TFrame", padding=(12, 16))
        side.pack(side="left", fill="y", padx=(0, 0))
        ttk.Label(side, text="SAVE EDITOR", style="SidebarMuted.TLabel").pack(anchor="w", padx=10, pady=(0, 8))
        self.nav_buttons: dict[str, ttk.Button] = {}
        nav = [
            ("Dashboard", "⌂"),
            ("Gil + kW", "◆"),
            ("Character", "●"),
            ("Chocobos", "♞"),
            ("Weapons", "⚔"),
            ("Abilities / Sigils", "✦"),
            ("Collections", "◇"),
            ("Inventory", "▣"),
            ("Database", "◉"),
            ("About", "ⓘ"),
        ]
        for name, icon in nav:
            b = ttk.Button(side, text=f"{icon}   {name}", style="Sidebar.TButton", width=24, command=lambda n=name: self.show_page(n))
            b.pack(fill="x", pady=2)
            self.nav_buttons[name] = b
        if not self.compact_height:
            ttk.Separator(side).pack(fill="x", pady=16)
            ttk.Label(side, text="SAFE WORKFLOW", style="SidebarMuted.TLabel").pack(anchor="w", padx=8)
            ttk.Label(side, text="Edit → Apply → Save files", style="SidebarBody.TLabel").pack(anchor="w", padx=8, pady=(5, 2))
            ttk.Label(side, text="Originals are preserved.", style="SidebarMuted.TLabel").pack(anchor="w", padx=8)

        self.content = ttk.Frame(body, style="Content.TFrame", padding=(20, 6 if self.compact_height else 12, 20, 6 if self.compact_height else 12))
        self.content.pack(side="left", fill="both", expand=True)
        self.pages: dict[str, ttk.Frame] = {}
        self.page_builders = {
            "Dashboard": self.build_dashboard,
            "Gil + kW": self.build_currency,
            "Character": self.build_character,
            "Chocobos": self.build_chocobos,
            "Weapons": self.build_weapons,
            "Abilities / Sigils": self.build_abilities,
            "Collections": self.build_collections,
            "Inventory": self.build_inventory,
            "Database": self.build_database,
            "About": self.build_about,
        }

        footer = ttk.Frame(self, style="HeaderTools.TFrame")
        footer.pack(fill="x", side="bottom")
        self.status = ttk.Label(footer, text="Ready.", style="Footer.TLabel", padding=(14, 7))
        self.status.pack(side="left", fill="x", expand=True)
        ttk.Label(footer, text=f"FINAL FANTASY XV COMRADES   •   SAVE EDITOR v{APP_VERSION}", style="Footer.TLabel", padding=(14, 7)).pack(side="right")

    def _set_busy(self, busy: bool) -> None:
        if not busy:
            try:
                self.configure(cursor="")
            except tk.TclError:
                pass
            return
        for cursor in ("wait", "watch", "arrow"):
            try:
                self.configure(cursor=cursor)
                break
            except tk.TclError:
                continue
        self.update_idletasks()

    def _check_core(self) -> None:
        try:
            v = self.core.version()
            self.core_version = v
            if v != EXPECTED_CORE_VERSION:
                self.core_ready = False
                self.status.config(text=f"Backend version mismatch: {v} (expected {EXPECTED_CORE_VERSION})")
                messagebox.showerror(
                    APP_NAME,
                    f"This editor requires ForgeCore {EXPECTED_CORE_VERSION}, but the bundled backend reports {v}.\n\n"
                    "Re-extract the complete release so the editor and backend stay matched.",
                )
                return
            self.core_ready = True
            self.open_btn.config(state="normal")
            self.avatar_btn.config(state="normal" if self.summary else "disabled")
            self.status.config(text=f"Ready • ForgeCore {v} • Ctrl+O open • Ctrl+S save")
        except CoreError as exc:
            self.core_ready = False
            self.status.config(text="Backend not available")
            messagebox.showerror(APP_NAME, str(exc))

    def _refresh_save_controls(self) -> None:
        ready = {k: v for k, v in self.export_outputs.items() if v[0].is_file()}
        self.save_btn.config(state="normal" if ready else "disabled")
        if hasattr(self, "avatar_btn"):
            self.avatar_btn.config(state="normal" if self.core_ready and self.summary else "disabled")
        dirty = bool(self.unexported_kinds)
        self.title(f"{APP_NAME} v{APP_VERSION}{' *' if dirty else ''}")
        if dirty:
            names = " + ".join(sorted(self.unexported_kinds))
            self.save_state_label.config(text=f"● Applied, not exported: {names}", foreground=WARN)
        elif ready:
            self.save_state_label.config(text="✓ Last applied changes exported", foreground=GOOD)
        else:
            self.save_state_label.config(text="")

    def _discard_export_kind(self, kind: str) -> None:
        self.export_outputs.pop(kind, None)
        self.unexported_kinds.discard(kind)
        self._refresh_save_controls()

    def _confirm_discard(self, kinds: set[str], action: str) -> bool:
        pending = sorted(kinds & self.unexported_kinds)
        if not pending:
            return True
        return messagebox.askyesno(
            APP_NAME,
            f"Applied changes for {', '.join(pending)} have not been exported yet.\n\n"
            f"{action} will discard those pending export results. Continue?",
            icon="warning",
        )

    def _on_close(self) -> None:
        if self.unexported_kinds and not self._confirm_discard(set(self.unexported_kinds), "Closing the editor"):
            return
        self.destroy()

    def show_page(self, name: str) -> None:
        for p in self.pages.values():
            p.pack_forget()
        for nav_name, button in self.nav_buttons.items():
            button.configure(style="SidebarSelected.TButton" if nav_name == name else "Sidebar.TButton")
        if name not in self.pages:
            frame = ttk.Frame(self.content, style="Content.TFrame")
            self.pages[name] = frame
            self.page_builders[name](frame)
        self.pages[name].pack(fill="both", expand=True)

    def rebuild_all(self) -> None:
        current = next((name for name, page in self.pages.items() if page.winfo_ismapped()), "Dashboard")
        for p in self.pages.values():
            p.destroy()
        self.pages.clear()
        self.show_page(current)

    def require_save(self, parent: ttk.Frame) -> bool:
        if self.summary is not None:
            return True
        ttk.Label(parent, text="Open a COMRADES gameplay0 save to use this page.", style="Section.TLabel").pack(anchor="w", pady=20)
        return False

    def open_save(self) -> None:
        if not self.core_ready:
            messagebox.showerror(APP_NAME, "The verified ForgeCore backend is not ready.")
            return
        if not self._confirm_discard(set(self.unexported_kinds), "Opening another gameplay0"):
            return
        path = filedialog.askopenfilename(title="Open FFXV COMRADES gameplay0", filetypes=[("FFXV save", "*.save"), ("All files", "*.*")])
        if not path:
            return
        self._set_busy(True)
        try:
            data = self.core.open_save(path)
            self.summary = data
            self.source_path = Path(path)
            self.plain_path = Path(data["plainPath"])
            self.avatar_summary = None
            self.avatar_plain_path = None
            self.avatar_source_path = None
            self.export_outputs.clear()
            self.unexported_kinds.clear()
            self.clear_edits(rebuild=False)
            self.file_label.config(text=f"{data.get('avatarName') or 'COMRADES'}  •  {data.get('fileSize', 0)/1024/1024:.2f} MB")
            self.gameplay_status.config(text=f"● gameplay0 loaded", style="ToolbarGood.TLabel")
            self.last_output_path = None
            self.last_verification = {}
            self.last_output_encrypted = False
            self._refresh_save_controls()
            avatar_note = self._try_auto_load_avatar(Path(path).parent)
            self.status.config(text=f"Loaded gameplay0 • {data.get('health', {}).get('status', 'UNKNOWN')}{avatar_note}")
            if self.avatar_summary:
                self.avatar_status.config(text="● avatar0 loaded", style="ToolbarGood.TLabel")
            else:
                self.avatar_status.config(text="○ avatar0 not loaded", style="ToolbarStatus.TLabel")
            self.rebuild_all()
        except (CoreError, OSError, KeyError) as exc:
            messagebox.showerror(APP_NAME, str(exc))
        finally:
            self._set_busy(False)

    def _try_auto_load_avatar(self, folder: Path) -> str:
        candidate = folder / "avatar0.save"
        if not candidate.is_file():
            return " • avatar0 not loaded"
        try:
            data = self.core.open_avatar(candidate)
            self.avatar_summary = data
            self.avatar_source_path = candidate
            self.avatar_plain_path = Path(data["plainPath"])
            return " • avatar0 loaded"
        except (CoreError, OSError, KeyError):
            return " • avatar0 found but could not be loaded"

    def load_avatar(self) -> None:
        if not self.core_ready:
            messagebox.showerror(APP_NAME, "The verified ForgeCore backend is not ready.")
            return
        if not self.summary:
            messagebox.showinfo(APP_NAME, "Open the matching gameplay0 first, then load avatar0 from the same save folder.")
            return
        if not self._confirm_discard({"avatar0"}, "Loading another avatar0"):
            return
        path = filedialog.askopenfilename(title="Open FFXV COMRADES avatar0", filetypes=[("FFXV save", "*.save"), ("All files", "*.*")])
        if not path:
            return
        self._set_busy(True)
        try:
            data = self.core.open_avatar(path)
            candidate_source = Path(path)
            mismatch = False
            if self.source_path:
                try:
                    mismatch = candidate_source.parent.resolve() != self.source_path.parent.resolve()
                except OSError:
                    mismatch = candidate_source.parent != self.source_path.parent
            if mismatch and not messagebox.askyesno(
                APP_NAME,
                "This avatar0 is from a different folder than the loaded gameplay0.\n\n"
                "Mixing save-set files can produce inconsistent character data. Use it anyway?",
                icon="warning",
            ):
                return
            self.avatar_summary = data
            self.avatar_source_path = candidate_source
            self.avatar_plain_path = Path(data["plainPath"])
            self._discard_export_kind("avatar0")
            self.avatar_status.config(text="● avatar0 loaded", style="ToolbarGood.TLabel")
            mismatch_note = " • different-folder avatar0 accepted" if mismatch else ""
            self.status.config(text=f"avatar0 loaded and verified: Level {data.get('level', 0)} • base STR {data.get('strength', 0)}{mismatch_note}")
            self.rebuild_all()
        except (CoreError, OSError, KeyError) as exc:
            messagebox.showerror(APP_NAME, str(exc))
        finally:
            self._set_busy(False)

    def _request(self) -> dict[str, Any]:
        req: dict[str, Any] = dict(self.edits)
        if self.collection_edits:
            req["collectionEdits"] = list(self.collection_edits.values())
        if self.inventory_edits:
            req["inventoryEdits"] = list(self.inventory_edits.values())
        if self.sigil_edits:
            req["sigilEdits"] = list(self.sigil_edits.values())
        if self.ability_edits:
            req["characterAbilityEdits"] = list(self.ability_edits.values())
        if self.weapon_edits:
            req["weaponEdits"] = list(self.weapon_edits.values())
        if self.chocobo_edits:
            req["chocoboEdits"] = list(self.chocobo_edits.values())
        return req

    def clear_edits(self, rebuild: bool = True) -> None:
        self.edits.clear()
        self.collection_edits.clear()
        self.inventory_edits.clear()
        self.sigil_edits.clear()
        self.ability_edits.clear()
        self.weapon_edits.clear()
        self.chocobo_edits.clear()
        if rebuild and self.summary:
            self.rebuild_all()

    def apply_changes(self, success_text: str = "Changes applied.") -> bool:
        if not self.summary or not self.plain_path:
            return False
        req = self._request()
        if not req:
            messagebox.showinfo(APP_NAME, "Nothing changed on this page.")
            return False
        self._set_busy(True)
        try:
            result = self.core.apply(self.plain_path, req)
            output = result.get("moddedPath") or result.get("editedPlainPath")
            if not output:
                raise CoreError("The backend did not return an output file.")
            self.summary = result.get("summary") or self.summary
            self.plain_path = Path(result.get("editedPlainPath") or self.plain_path)
            self.last_output_path = Path(output)
            self.last_output_encrypted = bool(result.get("moddedPath"))
            self.last_verification = result.get("verification", {})
            self.export_outputs["gameplay0"] = (Path(output), self.last_output_encrypted)
            self.unexported_kinds.add("gameplay0")
            self.clear_edits(rebuild=False)
            self._refresh_save_controls()
            self.rebuild_all()
            verify = self.last_verification.get("result", "UNKNOWN")
            self.status.config(text=f"{success_text} Verification: {verify}. Click SAVE FILES... to export.")
            return True
        except (CoreError, OSError) as exc:
            # The UI is immediate-apply, not a hidden staging queue. A failed
            # request must not poison a later Apply on another page.
            self.clear_edits(rebuild=False)
            messagebox.showerror(APP_NAME, str(exc))
            return False
        finally:
            self._set_busy(False)

    def _unique_backup_path(self, path: Path) -> Path:
        candidate = path.with_name(f"{path.stem}.backup{path.suffix}")
        n = 2
        while candidate.exists():
            candidate = path.with_name(f"{path.stem}.backup{n}{path.suffix}")
            n += 1
        return candidate

    @staticmethod
    def _same_path(a: Path, b: Path) -> bool:
        try:
            return a.resolve() == b.resolve()
        except OSError:
            return str(a.absolute()).casefold() == str(b.absolute()).casefold()

    def save_current(self) -> None:
        ready = {k: v for k, v in self.export_outputs.items() if v[0].is_file()}
        if not ready:
            messagebox.showinfo(APP_NAME, "Apply a change first, then use Save Files.")
            return
        target_dir = filedialog.askdirectory(title="Choose folder for edited COMRADES save files")
        if not target_dir:
            return
        written: list[str] = []
        backups: list[str] = []
        saved_kinds: set[str] = set()
        try:
            out_dir = Path(target_dir)
            out_dir.mkdir(parents=True, exist_ok=True)
            for kind, (src, encrypted) in ready.items():
                name = f"{kind}.save" if encrypted else f"{kind}.edited.save"
                dst = out_dir / name
                original = self.source_path if kind == "gameplay0" else self.avatar_source_path

                # Never replace the file the user originally opened. If they
                # choose that same folder, keep import-ready filenames inside
                # a MODDED subfolder instead.
                if original is not None and self._same_path(dst, original):
                    modded_dir = out_dir / "MODDED"
                    modded_dir.mkdir(parents=True, exist_ok=True)
                    dst = modded_dir / name

                if dst.exists() and not self._same_path(dst, src):
                    backup = self._unique_backup_path(dst)
                    shutil.copy2(dst, backup)
                    backups.append(str(backup))
                if not self._same_path(dst, src):
                    shutil.copy2(src, dst)
                written.append(str(dst))
                saved_kinds.add(kind)

            self.unexported_kinds.difference_update(saved_kinds)
            self._refresh_save_controls()
            msg = "Save completed.\n\n" + "\n".join(written)
            if backups:
                msg += "\n\nExisting destination file(s) were backed up first:\n" + "\n".join(backups)
            messagebox.showinfo(APP_NAME, msg)
            self.status.config(text=f"Saved {len(written)} modified file(s) • source files preserved")
        except OSError as exc:
            messagebox.showerror(APP_NAME, str(exc))

    def heading(self, parent: ttk.Frame, title: str, subtitle: str = "") -> None:
        head = ttk.Frame(parent, style="Content.TFrame")
        head.pack(fill="x", pady=(0, 3 if self.compact_height else 7))
        ttk.Label(head, text=title, style="Title.TLabel").pack(anchor="w")
        if subtitle and not self.compact_height:
            ttk.Label(head, text=subtitle, style="Muted.TLabel", wraplength=980).pack(anchor="w", pady=(3, 2))

    def card(self, parent: ttk.Frame, title: str, value: str, note: str = "") -> ttk.Frame:
        f = ttk.Frame(parent, style="Card.TFrame", padding=18)
        ttk.Label(f, text=title, style="Card.TLabel").pack(anchor="w")
        ttk.Label(f, text=value, style="Value.TLabel").pack(anchor="w", pady=(6, 0))
        if note:
            ttk.Label(f, text=note, style="Card.TLabel", wraplength=250).pack(anchor="w", pady=(6, 0))
        return f

    def build_dashboard(self, p: ttk.Frame) -> None:
        self.heading(p, "Dashboard", "COMRADES save-set overview. Character base stats use avatar0; gameplay0 holds inventory, currency, equipment and calculated totals.")
        if not self.require_save(p):
            return
        s = self.summary or {}
        row = ttk.Frame(p)
        row.pack(fill="x")
        cards = [
            ("Glaive", s.get("avatarName", "—"), f"Save index {s.get('saveIndex', '—')}"),
            ("Gil", f"{s.get('gil', 0):,}", "Currency"),
            ("kW", f"{s.get('kw', 0):,}", "Power"),
            ("Save health", s.get("health", {}).get("status", "UNKNOWN"), s.get("health", {}).get("confidence", "")),
        ]
        for i, x in enumerate(cards):
            c = self.card(row, *x)
            c.grid(row=0, column=i, sticky="nsew", padx=(0 if i == 0 else 8, 0))
            row.columnconfigure(i, weight=1)
        char = s.get("character") or {}
        box = ttk.LabelFrame(p, text="Active character", padding=14)
        box.pack(fill="x", pady=18)
        labels = [
            ("Level", f"{char.get('level', 0)} / {char.get('levelMax', 0)}"),
            ("HP", f"{char.get('hp', 0):,} / {char.get('hpMax', 0):,}"),
            ("MP", f"{char.get('mp', 0):,} / {char.get('mpMax', 0):,}"),
            ("Strength", f"{char.get('strength', 0):,}"),
            ("Vitality", f"{char.get('vitality', 0):,}"),
            ("Magic", f"{char.get('magic', 0):,}"),
            ("Spirit", f"{char.get('spirit', 0):,}"),
            ("Critical", f"{char.get('critical', 0):,}"),
        ]
        for i, (name, value) in enumerate(labels):
            ttk.Label(box, text=name, style="Muted.TLabel").grid(row=(i // 4) * 2, column=i % 4, sticky="w", padx=10, pady=(4, 0))
            ttk.Label(box, text=value, style="Section.TLabel").grid(row=(i // 4) * 2 + 1, column=i % 4, sticky="w", padx=10, pady=(0, 8))
            box.columnconfigure(i % 4, weight=1)
        health = s.get("health", {})
        hb = ttk.LabelFrame(p, text="Validation", padding=12)
        hb.pack(fill="both", expand=True)
        ttk.Label(hb, text=health.get("summary", ""), wraplength=900).pack(anchor="w", pady=(0, 8))
        for check in health.get("checks", []):
            ttk.Label(hb, text=f"{check.get('status','')}  {check.get('name','')}: {check.get('detail','')}", style="Muted.TLabel", wraplength=980).pack(anchor="w", pady=2)

    def build_currency(self, p: ttk.Frame) -> None:
        self.heading(p, "Gil + kW", "Edit currency and COMRADES power without touching player weapons.")
        if not self.require_save(p):
            return
        s = self.summary or {}
        box = ttk.LabelFrame(p, text="Values", padding=18)
        box.pack(fill="x")
        self.gil_var = tk.StringVar(value=str(s.get("gil", 0)))
        self.kw_var = tk.StringVar(value=str(s.get("kw", 0)))
        for r, (name, var, note) in enumerate([
            ("Gil", self.gil_var, "0 – 999,999,999"),
            ("kW", self.kw_var, "0 – 2,147,483,647"),
        ]):
            ttk.Label(box, text=name).grid(row=r, column=0, sticky="w", pady=8)
            ttk.Entry(box, textvariable=var, width=28).grid(row=r, column=1, sticky="w", padx=12)
            ttk.Label(box, text=note, style="Muted.TLabel").grid(row=r, column=2, sticky="w")
        ttk.Button(box, text="Apply", style="Accent.TButton", command=self.apply_currency).grid(row=3, column=1, sticky="w", pady=(16, 0), padx=12)
        ttk.Button(box, text="Max preset", command=lambda: (self.gil_var.set("999999999"), self.kw_var.set("2147483647"))).grid(row=3, column=2, sticky="w", pady=(16, 0))

    def apply_currency(self) -> None:
        try:
            self.edits["gil"] = parse_int(self.gil_var.get(), "Gil", 0, 999_999_999)
            self.edits["kw"] = parse_int(self.kw_var.get(), "kW", 0, 2_147_483_647)
            self.apply_changes("Gil and kW applied.")
        except ValueError as exc:
            messagebox.showerror(APP_NAME, str(exc))

    def build_character(self, p: ttk.Frame) -> None:
        self.heading(p, "Character / Glaive", "Persistent base stats are stored in avatar0. gameplay0 totals are calculated from base stats plus equipment.")
        if not self.require_save(p):
            return
        if not self.avatar_summary:
            total = (self.summary or {}).get("character") or {}
            box = ttk.LabelFrame(p, text="avatar0 required", padding=18)
            box.pack(fill="x")
            ttk.Label(box, text="The old editor changed gameplay0's calculated status copy, which the game rebuilt. Load the matching avatar0 to edit persistent Glaive stats.", wraplength=900).pack(anchor="w")
            ttk.Button(box, text="LOAD AVATAR0", style="Accent.TButton", command=self.load_avatar).pack(anchor="w", pady=(14, 0))
            ttk.Label(box, text=f"Current gameplay0 total: Level {total.get('level',0)} • HP {total.get('hp',0)}/{total.get('hpMax',0)} • STR {total.get('strength',0)} • VIT {total.get('vitality',0)} • MAG {total.get('magic',0)} • SPI {total.get('spirit',0)}", style="Muted.TLabel", wraplength=900).pack(anchor="w", pady=(14, 0))
            return

        c = self.avatar_summary
        sf = ScrollFrame(p)
        sf.pack(fill="both", expand=True)
        box = ttk.LabelFrame(sf.body, text="Persistent base stats (avatar0)", padding=16)
        box.pack(fill="x")
        fields = [
            ("HP", "hp", 0, 9_999_999), ("Max HP", "hpMax", 1, 9_999_999),
            ("MP", "mp", 0, 9_999_999), ("Max MP", "mpMax", 1, 9_999_999),
            ("Level", "level", 1, int(c.get("levelMax", 99))),
            ("Strength", "strength", 0, 999_999), ("Vitality", "vitality", 0, 999_999),
            ("Magic", "magic", 0, 999_999), ("Spirit", "spirit", 0, 999_999), ("Critical", "critical", 0, 999_999),
        ]
        self.char_vars: dict[str, tuple[tk.StringVar, int, int, str]] = {}
        for i, (label, key, lo, hi) in enumerate(fields):
            r, col = divmod(i, 2)
            cell = ttk.Frame(box)
            cell.grid(row=r, column=col, sticky="ew", padx=8, pady=7)
            box.columnconfigure(col, weight=1)
            ttk.Label(cell, text=label).pack(anchor="w")
            var = tk.StringVar(value=str(c.get(key, 0)))
            ttk.Entry(cell, textvariable=var).pack(fill="x", pady=(3, 0))
            ttk.Label(cell, text=f"{lo:,} – {hi:,}", style="Muted.TLabel").pack(anchor="w")
            self.char_vars[key] = (var, lo, hi, label)

        actions = ttk.Frame(sf.body)
        actions.pack(fill="x", pady=14)
        ttk.Button(actions, text="Apply", style="Accent.TButton", command=self.apply_character).pack(side="left")
        ttk.Button(actions, text="Max preset", command=self.max_character).pack(side="left", padx=8)
        ttk.Button(actions, text="Reload current values", command=lambda: self.rebuild_page_and_show("Character")).pack(side="left")

        total = (self.summary or {}).get("character") or {}
        info = ttk.LabelFrame(sf.body, text="Current gameplay0 total (read-only)", padding=14)
        info.pack(fill="x", pady=(4, 16))
        ttk.Label(info, text=(
            f"Level {total.get('level',0)}/{total.get('levelMax',0)}     "
            f"HP {total.get('hp',0)}/{total.get('hpMax',0)}     MP {total.get('mp',0)}/{total.get('mpMax',0)}     "
            f"STR {total.get('strength',0)}     VIT {total.get('vitality',0)}     MAG {total.get('magic',0)}     SPI {total.get('spirit',0)}     CRIT {total.get('critical',0)}"
        ), wraplength=950).pack(anchor="w")
        ttk.Label(info, text="The game recalculates this total from avatar0 base stats and equipped weapon/accessory bonuses.", style="Muted.TLabel").pack(anchor="w", pady=(6,0))

    def max_character(self) -> None:
        if not self.avatar_summary:
            return
        preset = {"hp": 99999, "hpMax": 99999, "mp": 9999, "mpMax": 9999, "level": self.avatar_summary.get("levelMax", 99), "strength": 9999, "vitality": 9999, "magic": 9999, "spirit": 9999, "critical": 9999}
        for k, v in preset.items():
            self.char_vars[k][0].set(str(v))

    def apply_character(self) -> None:
        if not self.avatar_summary or not self.avatar_plain_path:
            messagebox.showerror(APP_NAME, "Load the matching avatar0 save first.")
            return
        try:
            values: dict[str, int] = {}
            for key, (var, lo, hi, label) in self.char_vars.items():
                values[key] = parse_int(var.get(), label, lo, hi)
            if values["hp"] > values["hpMax"]:
                raise ValueError("HP cannot be greater than Max HP.")
            if values["mp"] > values["mpMax"]:
                raise ValueError("MP cannot be greater than Max MP.")
        except ValueError as exc:
            messagebox.showerror(APP_NAME, str(exc))
            return

        self._set_busy(True)
        try:
            result = self.core.apply_avatar(self.avatar_plain_path, values)
            output = result.get("moddedPath") or result.get("editedPlainPath")
            if not output:
                raise CoreError("The backend did not return an avatar0 output file.")
            self.avatar_summary = result.get("summary") or self.avatar_summary
            self.avatar_plain_path = Path(result.get("editedPlainPath") or self.avatar_plain_path)
            encrypted = bool(result.get("moddedPath"))
            self.export_outputs["avatar0"] = (Path(output), encrypted)
            self.unexported_kinds.add("avatar0")
            self._refresh_save_controls()
            self.rebuild_all()
            verify = (result.get("verification") or {}).get("result", "UNKNOWN")
            self.status.config(text=f"Persistent avatar0 stats applied. Verification: {verify}. Click SAVE FILES... to export.")
        except (CoreError, OSError, KeyError) as exc:
            messagebox.showerror(APP_NAME, str(exc))
        finally:
            self._set_busy(False)

    def build_chocobos(self, p: ttk.Frame) -> None:
        self.heading(p, "♞  Chocobo Stats", "Edit registered COMRADES chocobos: level, stamina, jump and top speed are mapped directly from SaveChocoboDataStruct.")
        if not self.require_save(p):
            return
        rows = list((self.summary or {}).get("chocobos") or [])
        if not rows:
            box = ttk.LabelFrame(p, text="No registered chocobos found", padding=18)
            box.pack(fill="x")
            ttk.Label(
                box,
                text="This gameplay0 currently reports 0 registered chocobos. The editor will not create a new chocobo record because the unlock/registration flags have not been verified.",
                wraplength=900,
            ).pack(anchor="w")
            return

        root = ttk.Frame(p, style="Content.TFrame")
        root.pack(fill="both", expand=True)

        chooser = ttk.Frame(root, style="Card.TFrame", padding=(12, 8))
        chooser.pack(fill="x", pady=(0, 8))
        ttk.Label(chooser, text="Select Chocobo", style="Card.TLabel", font=("Segoe UI Semibold", 10)).pack(side="left", padx=(0, 10))
        # Real-save verification: NameID 0x0B01D0C1 is shown in-game as Black
        # Chocobo and 0x0B01D0C3 as Blue Chocobo. Leave all other IDs generic
        # instead of guessing a color/name.
        verified_names = {0x0B01D0C1: "Black Chocobo", 0x0B01D0C3: "Blue Chocobo"}
        self.chocobo_rows = {}
        for c in rows:
            name_id = int(c.get("nameId", 0))
            display = verified_names.get(name_id, c.get("name", "Chocobo"))
            label = f"{display}  •  #{int(c.get('index', 0)) + 1}"
            if label in self.chocobo_rows:
                label = f"{label}  •  record {int(c.get('index', 0)) + 1}"
            c = dict(c)
            c["displayName"] = display
            self.chocobo_rows[label] = c
        self.chocobo_choice = tk.StringVar(value=next(iter(self.chocobo_rows)))
        cb = ttk.Combobox(chooser, textvariable=self.chocobo_choice, values=list(self.chocobo_rows), state="readonly", width=44)
        cb.pack(side="left", fill="x", expand=True)
        cb.bind("<<ComboboxSelected>>", lambda _e: self.load_selected_chocobo_fields())

        self.chocobo_vars: dict[str, tk.StringVar] = {}
        top = ttk.LabelFrame(root, text="Level", padding=(8, 6))
        top.pack(fill="x", pady=(0, 8))
        for i, (label, key) in enumerate([
            ("Current Level", "level"),
            ("Level Cap", "levelCap"),
            ("Limit Max Level", "limitMaxLevel"),
            ("Skill Level", "skillLevel"),
        ]):
            top.columnconfigure(i, weight=1, uniform="chocolevel")
            cell = ttk.Frame(top, style="SoftCard.TFrame", padding=(8, 5))
            cell.grid(row=0, column=i, sticky="ew", padx=3)
            ttk.Label(cell, text=label, style="SoftCard.TLabel", font=("Segoe UI Semibold", 9)).pack(anchor="w")
            var = tk.StringVar()
            ttk.Entry(cell, textvariable=var).pack(fill="x", pady=(3, 0))
            self.chocobo_vars[key] = var

        stats = ttk.LabelFrame(root, text="Performance Stats", padding=(8, 6))
        stats.pack(fill="x", pady=(0, 8))
        for i, (label, key, note) in enumerate([
            ("Stamina", "stamina", "0 – 9,999"),
            ("Jump", "jump", "0 – 9,999"),
            ("Top Speed", "speed", "mph • 0 – 999.9"),
            ("Injury %", "injuryPercent", "0 – 100"),
        ]):
            stats.columnconfigure(i, weight=1, uniform="chocostats")
            cell = ttk.Frame(stats, style="Card.TFrame", padding=(10, 6))
            cell.grid(row=0, column=i, sticky="ew", padx=3)
            ttk.Label(cell, text=label, style="Card.TLabel", font=("Segoe UI Semibold", 9)).pack(anchor="w")
            var = tk.StringVar()
            ttk.Entry(cell, textvariable=var, font=("Segoe UI Semibold", 12)).pack(fill="x", pady=(3, 0))
            ttk.Label(cell, text=note, style="Card.TLabel").pack(anchor="w", pady=(2, 0))
            self.chocobo_vars[key] = var

        actions = ttk.Frame(root, style="Content.TFrame")
        actions.pack(fill="x", pady=(1, 6))
        ttk.Button(actions, text="✎  APPLY CHOCOBO", style="Accent.TButton", command=self.apply_chocobo).pack(side="left")
        ttk.Button(actions, text="★  MAX ALL", style="Gold.TButton", command=self.max_selected_chocobo).pack(side="left", padx=8)
        ttk.Button(actions, text="↶  RELOAD CURRENT VALUES", style="Toolbar.TButton", command=self.load_selected_chocobo_fields).pack(side="left")

        self.chocobo_info = ttk.Label(root, text="", style="Muted.TLabel", wraplength=980)
        self.chocobo_info.pack(anchor="w", pady=(4, 0))
        self.load_selected_chocobo_fields()

    def load_selected_chocobo_fields(self) -> None:
        if not hasattr(self, "chocobo_rows"):
            return
        c = self.chocobo_rows.get(self.chocobo_choice.get())
        if not c:
            return
        for key in ("level", "levelCap", "limitMaxLevel", "skillLevel", "stamina", "jump", "injuryPercent"):
            self.chocobo_vars[key].set(str(c.get(key, 0)))
        speed = float(c.get("speed", 0.0))
        self.chocobo_vars["speed"].set(f"{speed:.1f}")
        injured = "Yes" if c.get("isInjured") else "No"
        self.chocobo_info.config(text=f"{c.get('displayName', c.get('name','Chocobo'))}  •  NameID {c.get('nameIdHex','0x00000000')}  •  Rarity {c.get('rarity',0)}  •  Color {c.get('color',0)}  •  Injured: {injured}")

    def max_selected_chocobo(self) -> None:
        """Set a strong in-game-oriented preset without creating new chocobos."""
        if not hasattr(self, "chocobo_vars"):
            return
        # 99 is the intended level preset; performance values are deliberately
        # high but kept far below the serializer's technical 9,999/999.9 limits.
        self.chocobo_vars["level"].set("99")
        self.chocobo_vars["levelCap"].set("99")
        self.chocobo_vars["limitMaxLevel"].set("99")
        self.chocobo_vars["stamina"].set("300")
        self.chocobo_vars["jump"].set("300")
        self.chocobo_vars["speed"].set("90.0")
        self.chocobo_vars["injuryPercent"].set("0")

    def apply_chocobo(self) -> None:
        if not self.summary or not hasattr(self, "chocobo_rows"):
            return
        c = self.chocobo_rows.get(self.chocobo_choice.get())
        if not c:
            return
        try:
            level = parse_int(self.chocobo_vars["level"].get(), "Current Level", 1, 999)
            cap = parse_int(self.chocobo_vars["levelCap"].get(), "Level Cap", 1, 999)
            limit = parse_int(self.chocobo_vars["limitMaxLevel"].get(), "Limit Max Level", 1, 999)
            skill = parse_int(self.chocobo_vars["skillLevel"].get(), "Skill Level", 0, 999)
            stamina = parse_int(self.chocobo_vars["stamina"].get(), "Stamina", 0, 9999)
            jump = parse_int(self.chocobo_vars["jump"].get(), "Jump", 0, 9999)
            speed = parse_float(self.chocobo_vars["speed"].get(), "Top Speed", 0.0, 999.9)
            injury = parse_int(self.chocobo_vars["injuryPercent"].get(), "Injury %", 0, 100)
            if level > cap:
                raise ValueError("Current Level cannot be greater than Level Cap.")
            if cap > limit:
                raise ValueError("Level Cap cannot be greater than Limit Max Level.")
        except ValueError as exc:
            messagebox.showerror(APP_NAME, str(exc))
            return
        idx = int(c.get("index", 0))
        self.chocobo_edits[idx] = {
            "index": idx,
            "level": level,
            "levelCap": cap,
            "limitMaxLevel": limit,
            "skillLevel": skill,
            "stamina": stamina,
            "jump": jump,
            "speed": speed,
            "injuryPercent": injury,
        }
        self.apply_changes("Chocobo stats applied.")

    def _active_player_weapons(self) -> list[dict[str, Any]]:
        rows = []
        for w in (self.summary or {}).get("weapons", []):
            if not w.get("initialized") or not w.get("owned"):
                continue
            if not w.get("availableToActiveGlaive"):
                continue
            rows.append(w)
        rows.sort(key=lambda w: (0 if w.get("equippedByActiveGlaive") else 1, int(w.get("equipmentSlot", 999)), str(w.get("name", "")).lower(), int(w.get("bank", 0))))
        return rows

    def _weapon_label(self, w: dict[str, Any]) -> str:
        if w.get("equippedByActiveGlaive"):
            where = f"Equipped slot {w.get('equipmentSlot', '?')}"
        else:
            where = "Owned inventory"
        return f"{w.get('name','Weapon')}  •  {where}"

    def _step_weapon(self, delta: int) -> None:
        labels = list(getattr(self, "weapon_rows", {}))
        if not labels:
            return
        try:
            idx = labels.index(self.weapon_choice.get())
        except ValueError:
            idx = 0
        self.weapon_choice.set(labels[(idx + delta) % len(labels)])
        self.load_selected_weapon_fields()

    def _update_weapon_position(self) -> None:
        if not hasattr(self, "weapon_position"):
            return
        labels = list(getattr(self, "weapon_rows", {}))
        try:
            idx = labels.index(self.weapon_choice.get()) + 1
        except ValueError:
            idx = 0
        if not labels:
            text = ""
        elif self.initial_window_width <= 1100:
            text = f"{idx} / {len(labels)}"
        else:
            text = f"Weapon {idx} / {len(labels)}"
        self.weapon_position.config(text=text)

    def build_weapons(self, p: ttk.Frame) -> None:
        self.heading(p, "⚔  Player Weapons", "Edit the active Glaive's owned weapon instance. Verified in-game ability names are selectable.")
        if not self.require_save(p):
            return
        rows = self._active_player_weapons()
        if not rows:
            box = ttk.LabelFrame(p, text="No player weapons found", padding=14)
            box.pack(fill="x")
            ttk.Label(box, text="No initialized weapon record owned by the active Glaive was found.", wraplength=900).pack(anchor="w")
            return

        root = ttk.Frame(p, style="Content.TFrame")
        root.pack(fill="both", expand=True)

        chooser = ttk.Frame(root, style="Card.TFrame", padding=(10, 6))
        chooser.pack(fill="x", pady=(0, 6))
        ttk.Label(chooser, text="Select Weapon", style="Card.TLabel", font=("Segoe UI Semibold", 10)).pack(side="left", padx=(0, 10))
        base_labels = [self._weapon_label(w) for w in rows]
        label_totals = {label: base_labels.count(label) for label in set(base_labels)}
        label_seen: dict[str, int] = {}
        self.weapon_rows: dict[str, dict[str, Any]] = {}
        for w, base_label in zip(rows, base_labels):
            label_seen[base_label] = label_seen.get(base_label, 0) + 1
            label = base_label
            if label_totals[base_label] > 1:
                label = f"{base_label}  •  Copy {label_seen[base_label]}"
            self.weapon_rows[label] = w
        self.weapon_choice = tk.StringVar(value=next(iter(self.weapon_rows)))
        ttk.Button(chooser, text="‹", style="Toolbar.TButton", width=3, command=lambda: self._step_weapon(-1)).pack(side="left", padx=(0, 6))
        self.weapon_position = ttk.Label(chooser, text="", style="Card.TLabel")
        self.weapon_position.pack(side="right", padx=(8, 0))
        ttk.Button(chooser, text="›", style="Toolbar.TButton", width=3, command=lambda: self._step_weapon(1)).pack(side="right", padx=(6, 0))
        cb = ttk.Combobox(chooser, textvariable=self.weapon_choice, values=list(self.weapon_rows), state="readonly", width=48)
        cb.pack(side="left", fill="x", expand=True)
        cb.bind("<<ComboboxSelected>>", lambda _e: self.load_selected_weapon_fields())

        topstats = ttk.Frame(root, style="Content.TFrame")
        topstats.pack(fill="x", pady=(0, 6))
        self.weapon_vars: dict[str, tuple[tk.StringVar, int, int, str]] = {}
        for col in range(3):
            topstats.columnconfigure(col, weight=1, uniform="topweapon")
        for col, (label, key, lo, hi) in enumerate([
            ("Current Level", "level", 1, 9999),
            ("Level Cap", "levelCap", 1, 9999),
            ("Attack", "attack", 0, 99999),
        ]):
            card = ttk.Frame(topstats, style="Card.TFrame", padding=(10, 5))
            card.grid(row=0, column=col, sticky="nsew", padx=(0 if col == 0 else 5, 0))
            ttk.Label(card, text=label, style="Card.TLabel", font=("Segoe UI Semibold", 9)).pack(anchor="w")
            var = tk.StringVar()
            ttk.Entry(card, textvariable=var, font=("Segoe UI Semibold", 12)).pack(fill="x", pady=(3, 0))
            self.weapon_vars[key] = (var, lo, hi, label)

        core = ttk.LabelFrame(root, text="Core Stats", padding=(6, 3))
        core.pack(fill="x", pady=(0, 6))
        core_fields = [
            ("HP Bonus", "hpBonus", -9999, 9999), ("MP Bonus", "mpBonus", -9999, 9999),
            ("Strength", "strength", -9999, 9999), ("Vitality", "vitalityBonus", -9999, 9999),
            ("Magic", "magic", -9999, 9999), ("Spirit", "spirit", -9999, 9999),
        ]
        for i, (label, key, lo, hi) in enumerate(core_fields):
            core.columnconfigure(i, weight=1, uniform="coreweapon")
            cell = ttk.Frame(core, style="SoftCard.TFrame", padding=(5, 3))
            cell.grid(row=0, column=i, sticky="ew", padx=2)
            ttk.Label(cell, text=label, style="SoftCard.TLabel", font=("Segoe UI Semibold", 9)).pack(anchor="w")
            var = tk.StringVar()
            ttk.Entry(cell, textvariable=var, width=10).pack(fill="x", pady=(2, 0))
            self.weapon_vars[key] = (var, lo, hi, label)

        res = ttk.LabelFrame(root, text="Resistances (%)  •  −100 to 100", padding=(6, 3))
        res.pack(fill="x", pady=(0, 6))
        self.weapon_res_vars: dict[str, tk.StringVar] = {}
        res_fields = [("Shot", "shot"), ("Fire", "fire"), ("Ice", "ice"), ("Lightning", "lightning"), ("Dark", "dark")]
        for i, (label, key) in enumerate(res_fields):
            res.columnconfigure(i, weight=1, uniform="weaponres")
            cell = ttk.Frame(res, style="SoftCard.TFrame", padding=(5, 3))
            cell.grid(row=0, column=i, sticky="ew", padx=2)
            ttk.Label(cell, text=label, style="SoftCard.TLabel", font=("Segoe UI Semibold", 9)).pack(anchor="w")
            var = tk.StringVar()
            ttk.Entry(cell, textvariable=var, width=8).pack(fill="x", pady=(2, 0))
            self.weapon_res_vars[key] = var

        abilities = ttk.LabelFrame(root, text="Abilities (In-Game Names)", padding=(7, 3))
        abilities.pack(fill="x", pady=(0, 6))
        abilities.columnconfigure(1, weight=1)
        abilities.columnconfigure(3, weight=1)
        self.weapon_ability_vars: list[tk.StringVar] = [tk.StringVar(), tk.StringVar()]
        self.weapon_ability_boxes: list[ttk.Combobox] = []
        for col, label in ((0, "Ability 1"), (2, "Ability 2")):
            idx = 0 if col == 0 else 1
            ttk.Label(abilities, text=label, style="Card.TLabel").grid(row=0, column=col, sticky="w", padx=(0 if col == 0 else 14, 7), pady=2)
            box = ttk.Combobox(abilities, textvariable=self.weapon_ability_vars[idx], state="readonly", width=32)
            box.grid(row=0, column=col + 1, sticky="ew", pady=2)
            box.bind("<<ComboboxSelected>>", lambda _e: self._update_weapon_ability_description())
            self.weapon_ability_boxes.append(box)
        actions = ttk.Frame(root, style="Content.TFrame")
        actions.pack(fill="x", pady=(1, 5))
        ttk.Button(actions, text="✎  APPLY WEAPON", style="Accent.TButton", command=self.apply_weapon).pack(side="left")
        ttk.Button(actions, text="★  MAX ALL", style="Gold.TButton", command=self.max_selected_weapon).pack(side="left", padx=8)
        ttk.Button(actions, text="↶  RELOAD CURRENT VALUES", style="Toolbar.TButton", command=self.load_selected_weapon_fields).pack(side="left")

        self.weapon_info = None
        if self.winfo_screenheight() >= 820:
            info = ttk.Frame(root, style="SoftCard.TFrame", padding=(10, 5))
            info.pack(fill="x")
            self.weapon_info = ttk.Label(info, text="", style="SoftCard.TLabel", wraplength=1000)
            self.weapon_info.pack(side="left", fill="x", expand=True)
        self.load_selected_weapon_fields()

    def load_selected_weapon_fields(self) -> None:
        if not hasattr(self, "weapon_rows"):
            return
        w = self.weapon_rows.get(self.weapon_choice.get())
        if not w:
            return
        self._update_weapon_position()
        st = list(w.get("statusAdjust") or [0] * 19)
        st += [0] * max(0, 19 - len(st))
        values = {
            "level": int(w.get("remodelFails", 0)),
            "levelCap": int(st[17]),
            "attack": int(w.get("attack", 0)),
            "hpBonus": int(st[4]),
            "mpBonus": int(st[6]),
            "strength": int(st[0]),
            "vitalityBonus": int(st[1]),
            "magic": int(st[2]),
            "spirit": int(st[3]),
        }
        for key, value in values.items():
            self.weapon_vars[key][0].set(str(value))
        for key, idx in [("shot", 11), ("fire", 12), ("ice", 13), ("lightning", 14), ("dark", 15)]:
            raw = int(st[idx])
            self.weapon_res_vars[key].set(str(-raw))

        self._load_weapon_ability_choices(w)
        hidden_unsafe = []
        if int(w.get("vitality", 0)) < 0 or int(w.get("vitality", 0)) > 50:
            hidden_unsafe.append(f"internal direct Vitality={w.get('vitality')}")
        if int(w.get("critical", 0)) < 0 or int(w.get("critical", 0)) > 100:
            hidden_unsafe.append(f"internal Critical={w.get('critical')}")
        if int(w.get("slotCount", 0)) < 0 or int(w.get("slotCount", 0)) > 2:
            hidden_unsafe.append(f"raw slots={w.get('slotCount')}")
        safety = ""
        if hidden_unsafe:
            safety = " • WARNING: legacy unsafe hidden value(s): " + ", ".join(hidden_unsafe) + ". Apply/MAX ALL will automatically normalize these hidden legacy values."
        info_text = (
            f"{w.get('name')}  •  {w.get('fixIdHex')}  •  bank {w.get('bank')}  •  "
            + (f"equipped slot {w.get('equipmentSlot')}" if w.get('equippedByActiveGlaive') else "owned inventory copy")
            + "  •  mapped bonuses ±9,999; resistances −100–100%"
            + safety
        )
        if self.weapon_info is not None:
            self.weapon_info.config(text=info_text)
        elif safety:
            self.status.config(text=f"Weapon warning: {safety.removeprefix(' • ')}")

    def _ability_label(self, ability_id: int, fallback_name: str = "") -> str:
        real = VERIFIED_WEAPON_ABILITIES.get(int(ability_id))
        if real:
            return real
        fallback = (fallback_name or "").strip()
        if fallback and fallback.lower() not in {"unknown", "none"}:
            return f"Current / unmapped: {fallback} [{int(ability_id):#010x}]"
        return f"Current / unmapped [{int(ability_id):#010x}]"

    def _load_weapon_ability_choices(self, w: dict[str, Any]) -> None:
        # Keep the selectable list deliberately conservative.  The old backend
        # catalog contains hundreds of internal ENC_* identifiers whose real
        # localized COMRADES names are not proven.  We expose only verified
        # real-name mappings plus the selected weapon's current IDs so nothing
        # is silently lost when opening older or unusual saves.
        ids_by_label: dict[str, int] = {name: aid for aid, name in VERIFIED_WEAPON_ABILITIES.items()}
        for slot in (1, 2):
            aid = int(w.get(f"ability{slot}", 0))
            if aid not in VERIFIED_WEAPON_ABILITIES:
                label = self._ability_label(aid, str(w.get(f"ability{slot}Name", "")))
                ids_by_label[label] = aid
        labels = list(VERIFIED_WEAPON_ABILITIES.values())
        labels += sorted(label for label in ids_by_label if label not in VERIFIED_WEAPON_ABILITIES.values())
        self.weapon_ability_ids_by_label = ids_by_label
        for box in self.weapon_ability_boxes:
            box.configure(values=labels)
        # SaveWeaponStruct serializes the two links in the opposite order from
        # the left-to-right ability boxes shown by COMRADES in game.  Keep the
        # editor labels aligned with what the player sees: UI Ability 1 (left)
        # reads backend ability2; UI Ability 2 (right) reads backend ability1.
        visible_to_backend_slot = (2, 1)
        for idx, backend_slot in enumerate(visible_to_backend_slot):
            aid = int(w.get(f"ability{backend_slot}", 0))
            self.weapon_ability_vars[idx].set(
                self._ability_label(aid, str(w.get(f"ability{backend_slot}Name", "")))
            )
        self._update_weapon_ability_description()

    def _selected_weapon_ability_id(self, slot_index: int) -> int:
        label = self.weapon_ability_vars[slot_index].get()
        if label not in getattr(self, "weapon_ability_ids_by_label", {}):
            raise ValueError(f"Ability {slot_index + 1} is not a recognized verified choice.")
        return int(self.weapon_ability_ids_by_label[label])

    def _update_weapon_ability_description(self) -> None:
        parts: list[str] = []
        for idx in range(2):
            try:
                aid = self._selected_weapon_ability_id(idx)
            except (ValueError, AttributeError):
                continue
            desc = VERIFIED_WEAPON_ABILITY_DESCRIPTIONS.get(aid)
            if desc and desc not in parts:
                parts.append(desc)
        if hasattr(self, "weapon_ability_description"):
            self.weapon_ability_description.config(text="  •  ".join(parts) if parts else "Current unmapped ability IDs are preserved unless you choose a verified real-name ability.")

    def _normalized_internal_weapon_fields(self, w: dict[str, Any], *, max_all: bool = False) -> dict[str, int]:
        """Return backend-safe hidden scalar fields for the selected weapon.

        Older Forge builds wrote invalid values such as direct Vitality=999/9999.
        Those hidden scalars are not the visible VIT bonus in status_adjust[1].
        Normal Apply repairs only out-of-range legacy values; MAX ALL deliberately
        sets the verified backend maxima so an old corrupted weapon can be edited.
        """
        if max_all:
            return {
                "vitality": 50,
                "critical": 100,
                "recoverMp": 9999,
                "slotCount": 2,
            }
        return {
            "vitality": min(50, max(0, int(w.get("vitality", 0)))),
            "critical": min(100, max(0, int(w.get("critical", 0)))),
            "recoverMp": min(9999, max(0, int(w.get("recoverMp", 0)))),
            "slotCount": min(2, max(0, int(w.get("slotCount", 0)))),
        }

    def _max_weapon_payload(self, w: dict[str, Any]) -> dict[str, Any]:
        st = list(w.get("statusAdjust") or [0] * 19)
        st += [0] * max(0, 19 - len(st))
        # Max only mapped display fields. Unknown/opaque status slots and
        # identity/ability links remain preserved. Hidden legacy scalar fields
        # are normalized separately because old saves can contain invalid 999s.
        for idx in (0, 1, 2, 3, 4, 6):
            st[idx] = 9999
        for idx in (11, 12, 13, 14, 15):
            st[idx] = -100
        st[17] = 9999
        internal = self._normalized_internal_weapon_fields(w, max_all=True)
        return {
            "bank": int(w["bank"]),
            "owned": bool(w.get("owned")),
            "rank": int(w.get("rank", 0)),
            "attack": 99999,
            "vitality": internal["vitality"],
            "critical": internal["critical"],
            "recoverMp": internal["recoverMp"],
            "slotCount": internal["slotCount"],
            "remodelFails": 9999,
            "ability1": int(w.get("ability1", 0)),
            "ability2": int(w.get("ability2", 0)),
            "residentAbility": int(w.get("residentAbility", 0)),
            "residentAbilityBank": int(w.get("residentAbilityBank", 0)),
            "statusAdjust": st[:19],
        }

    def max_selected_weapon(self) -> None:
        w = getattr(self, "weapon_rows", {}).get(self.weapon_choice.get())
        if not w:
            messagebox.showinfo(APP_NAME, "Select a player weapon first.")
            return
        if not messagebox.askyesno(
            APP_NAME,
            "Set every mapped stat on the selected weapon to the editor maximum?\n\n"
            "Attack = 99,999\nLevel / Level Cap = 9,999\nHP/MP/STR/VIT/MAG/SPI = 9,999\nResistances = 100%\n\n"
            "Extreme Attack values are intentionally allowed, but prior testing showed that very high displayed Attack can still produce 0-1 real damage.",
        ):
            return
        bank = int(w["bank"])
        self.weapon_edits[bank] = self._max_weapon_payload(w)
        self.apply_changes(f"MAX ALL applied: {w.get('name')}.")

    def apply_weapon(self) -> None:
        if not self.summary:
            return
        w = getattr(self, "weapon_rows", {}).get(self.weapon_choice.get())
        if not w:
            messagebox.showinfo(APP_NAME, "Select a player weapon first.")
            return
        try:
            vals: dict[str, int] = {}
            for key, (var, lo, hi, label) in self.weapon_vars.items():
                vals[key] = parse_int(var.get(), label, lo, hi)
            resist = {key: parse_int(var.get(), f"{key.title()} resistance", -100, 100) for key, var in self.weapon_res_vars.items()}
            # These are the two visible in-game slots, left then right.
            visible_ability1_id = self._selected_weapon_ability_id(0)
            visible_ability2_id = self._selected_weapon_ability_id(1)
            if vals["level"] > vals["levelCap"]:
                raise ValueError("Current Level cannot be greater than Level Cap.")
        except ValueError as exc:
            messagebox.showerror(APP_NAME, str(exc))
            return

        st = list(w.get("statusAdjust") or [0] * 19)
        st += [0] * max(0, 19 - len(st))
        st[0] = vals["strength"]
        st[1] = vals["vitalityBonus"]
        st[2] = vals["magic"]
        st[3] = vals["spirit"]
        st[4] = vals["hpBonus"]
        st[6] = vals["mpBonus"]
        st[11] = -resist["shot"]
        st[12] = -resist["fire"]
        st[13] = -resist["ice"]
        st[14] = -resist["lightning"]
        st[15] = -resist["dark"]
        st[17] = vals["levelCap"]

        bank = int(w["bank"])
        internal = self._normalized_internal_weapon_fields(w)
        self.weapon_edits[bank] = {
            "bank": bank,
            "owned": bool(w.get("owned")),
            "rank": int(w.get("rank", 0)),
            "attack": vals["attack"],
            "vitality": internal["vitality"],
            "critical": internal["critical"],
            "recoverMp": internal["recoverMp"],
            "slotCount": internal["slotCount"],
            "remodelFails": vals["level"],
            # Game-visible order is reversed relative to the serialized links.
            # UI Ability 1 (left) -> backend ability2; UI Ability 2 (right) ->
            # backend ability1.
            "ability1": visible_ability2_id,
            "ability2": visible_ability1_id,
            "residentAbility": int(w.get("residentAbility", 0)),
            "residentAbilityBank": int(w.get("residentAbilityBank", 0)),
            "statusAdjust": st[:19],
        }
        self.apply_changes(f"Weapon applied: {w.get('name')}.")

    def build_abilities(self, p: ttk.Frame) -> None:
        self.heading(p, "Abilities / Sigils", "Edit initialized character abilities and verified Sigil ownership. Ability-tree structure stays read-only.")
        if not self.require_save(p):
            return
        a = (self.summary or {}).get("abilitiesSigils") or {}
        nb = ttk.Notebook(p)
        nb.pack(fill="both", expand=True)
        ab = ttk.Frame(nb, padding=10)
        sg = ttk.Frame(nb, padding=10)
        tr = ttk.Frame(nb, padding=10)
        nb.add(ab, text="Character abilities")
        nb.add(sg, text="Sigils")
        nb.add(tr, text="Ability tree")

        ab_table = ttk.Frame(ab)
        ab_table.pack(fill="both", expand=True)
        self.ability_tree = ttk.Treeview(ab_table, columns=("name", "level", "enabled", "fix"), show="headings")
        for col, text, width in [("name", "Ability", 440), ("level", "Level", 80), ("enabled", "Enabled", 90), ("fix", "FixID", 120)]:
            self.ability_tree.heading(col, text=text); self.ability_tree.column(col, width=width, anchor="w")
        for x in a.get("characterAbilities", []):
            self.ability_tree.insert("", "end", iid=str(x["recordIndex"]), values=(x["name"], x["level"], "Yes" if x["enabled"] else "No", x["fixIdHex"]))
        ab_scroll = ttk.Scrollbar(ab_table, orient="vertical", command=self.ability_tree.yview)
        self.ability_tree.configure(yscrollcommand=ab_scroll.set)
        self.ability_tree.pack(side="left", fill="both", expand=True)
        ab_scroll.pack(side="right", fill="y")
        edit = ttk.Frame(ab)
        edit.pack(fill="x", pady=10)
        self.ability_level = tk.StringVar(value="1")
        self.ability_enabled = tk.BooleanVar(value=True)
        ttk.Label(edit, text="Selected level").pack(side="left")
        ttk.Entry(edit, textvariable=self.ability_level, width=8).pack(side="left", padx=8)
        ttk.Checkbutton(edit, text="Enabled", variable=self.ability_enabled).pack(side="left", padx=8)
        ttk.Button(edit, text="Apply selected ability", style="Accent.TButton", command=self.apply_ability).pack(side="left", padx=8)
        self.ability_tree.bind("<<TreeviewSelect>>", self.on_ability_select)

        sg_table = ttk.Frame(sg)
        sg_table.pack(fill="both", expand=True)
        self.sigil_tree = ttk.Treeview(sg_table, columns=("name", "owned", "writable", "fix"), show="headings")
        for col, text, width in [("name", "Sigil", 500), ("owned", "Owned", 80), ("writable", "Writable", 90), ("fix", "FixID", 120)]:
            self.sigil_tree.heading(col, text=text); self.sigil_tree.column(col, width=width, anchor="w")
        for x in a.get("sigils", []):
            self.sigil_tree.insert("", "end", iid=str(x["bank"]), values=(x["name"], "Yes" if x["owned"] else "No", "Yes" if x["writable"] else "No", x["fixIdHex"]))
        sg_scroll = ttk.Scrollbar(sg_table, orient="vertical", command=self.sigil_tree.yview)
        self.sigil_tree.configure(yscrollcommand=sg_scroll.set)
        self.sigil_tree.pack(side="left", fill="both", expand=True)
        sg_scroll.pack(side="right", fill="y")
        sg_actions = ttk.Frame(sg); sg_actions.pack(fill="x", pady=10)
        ttk.Button(sg_actions, text="Set Owned", command=lambda: self.apply_sigil(True)).pack(side="left")
        ttk.Button(sg_actions, text="Set Not Owned", command=lambda: self.apply_sigil(False)).pack(side="left", padx=8)
        ttk.Label(sg_actions, text="Uninitialized Sigils may be read-only; the backend will refuse guessed synthesis.", style="Muted.TLabel").pack(side="left", padx=10)

        tree = a.get("abilityTree") or {}
        ttk.Label(tr, text=tree.get("note", ""), wraplength=900).pack(anchor="w", pady=(0, 10))
        tr_table = ttk.Frame(tr)
        tr_table.pack(fill="both", expand=True)
        tv = ttk.Treeview(tr_table, columns=("fix", "bank"), show="headings")
        tv.heading("fix", text="Enabled FixID"); tv.heading("bank", text="Bank")
        for x in tree.get("enabled", []):
            tv.insert("", "end", values=(x.get("fixIdHex"), x.get("bankNumber")))
        tr_scroll = ttk.Scrollbar(tr_table, orient="vertical", command=tv.yview)
        tv.configure(yscrollcommand=tr_scroll.set)
        tv.pack(side="left", fill="both", expand=True)
        tr_scroll.pack(side="right", fill="y")

    def on_ability_select(self, _event=None) -> None:
        sel = self.ability_tree.selection()
        if not sel or not self.summary:
            return
        idx = int(sel[0])
        for x in self.summary.get("abilitiesSigils", {}).get("characterAbilities", []):
            if int(x["recordIndex"]) == idx:
                self.ability_level.set(str(x["level"]))
                self.ability_enabled.set(bool(x["enabled"]))
                return

    def apply_ability(self) -> None:
        sel = self.ability_tree.selection()
        if not sel or not self.summary:
            messagebox.showinfo(APP_NAME, "Select an ability first.")
            return
        idx = int(sel[0])
        try:
            level = parse_int(self.ability_level.get(), "Ability level", 0, 99)
        except ValueError as exc:
            messagebox.showerror(APP_NAME, str(exc))
            return
        x = next((a for a in self.summary["abilitiesSigils"]["characterAbilities"] if int(a["recordIndex"]) == idx), None)
        if x is None:
            messagebox.showerror(APP_NAME, "The selected ability is no longer present in the current working save.")
            return
        self.ability_edits[idx] = {"recordIndex": idx, "fixId": x["fixId"], "abilityId": x["abilityId"], "weaponBank": x["weaponBank"], "enabled": bool(self.ability_enabled.get()), "level": level}
        self.apply_changes(f"Ability applied: {x['name']}.")

    def apply_sigil(self, owned: bool) -> None:
        sel = self.sigil_tree.selection()
        if not sel or not self.summary:
            messagebox.showinfo(APP_NAME, "Select a Sigil first.")
            return
        bank = int(sel[0])
        x = next((sig for sig in self.summary["abilitiesSigils"]["sigils"] if int(sig["bank"]) == bank), None)
        if x is None:
            messagebox.showerror(APP_NAME, "The selected Sigil is no longer present in the current working save.")
            return
        if owned and not x.get("writable"):
            messagebox.showwarning(APP_NAME, "This Sigil is not initialized/writable in the loaded save, so it cannot be applied.")
            return
        self.sigil_edits[bank] = {"bank": bank, "owned": owned}
        self.apply_changes(f"Sigil ownership applied: {x['name']}.")

    def build_collections(self, p: ttk.Frame) -> None:
        self.heading(p, "Collections", "Treasures, barter items, phrasebooks, avatar unlocks, clothing, and key items.")
        if not self.require_save(p):
            return
        top = ttk.Frame(p); top.pack(fill="x", pady=(0, 8))
        groups = (self.summary or {}).get("collections", [])
        self.collection_group = tk.StringVar(value=groups[0]["kind"] if groups else "")
        ttk.Label(top, text="Group").pack(side="left")
        cb = ttk.Combobox(top, textvariable=self.collection_group, values=[g["kind"] for g in groups], state="readonly", width=28)
        cb.pack(side="left", padx=8); cb.bind("<<ComboboxSelected>>", lambda _e: self.refresh_collection_tree())
        self.collection_search = tk.StringVar()
        collection_entry = ttk.Entry(top, textvariable=self.collection_search, width=28)
        collection_entry.pack(side="left", padx=8)
        collection_entry.bind("<Return>", lambda _e: self.refresh_collection_tree())
        ttk.Button(top, text="Search", command=self.refresh_collection_tree).pack(side="left")
        ttk.Button(top, text="Apply Add All", command=self.apply_collection_all).pack(side="right")

        collection_table = ttk.Frame(p)
        collection_table.pack(fill="both", expand=True)
        self.collection_tree = ttk.Treeview(collection_table, columns=("name", "qty", "owned", "fix"), show="headings")
        for col, text, width in [("name", "Item", 520), ("qty", "Qty", 70), ("owned", "Owned", 80), ("fix", "FixID", 120)]:
            self.collection_tree.heading(col, text=text); self.collection_tree.column(col, width=width, anchor="w")
        collection_scroll = ttk.Scrollbar(collection_table, orient="vertical", command=self.collection_tree.yview)
        self.collection_tree.configure(yscrollcommand=collection_scroll.set)
        self.collection_tree.pack(side="left", fill="both", expand=True)
        collection_scroll.pack(side="right", fill="y")
        self.collection_tree.bind("<<TreeviewSelect>>", self.on_collection_select)
        bottom = ttk.Frame(p); bottom.pack(fill="x", pady=10)
        self.collection_qty = tk.StringVar(value="1")
        ttk.Label(bottom, text="Quantity").pack(side="left")
        ttk.Entry(bottom, textvariable=self.collection_qty, width=8).pack(side="left", padx=8)
        ttk.Button(bottom, text="Apply selected", style="Accent.TButton", command=self.apply_collection_selected).pack(side="left")
        self.refresh_collection_tree()

    def current_collection_group(self) -> dict[str, Any] | None:
        for g in (self.summary or {}).get("collections", []):
            if g["kind"] == self.collection_group.get():
                return g
        return None

    def refresh_collection_tree(self) -> None:
        if not hasattr(self, "collection_tree"):
            return
        self.collection_tree.delete(*self.collection_tree.get_children())
        g = self.current_collection_group()
        if not g: return
        q = self.collection_search.get().lower().strip()
        for x in g.get("entries", []):
            if q and q not in x["name"].lower() and q not in x["fixIdHex"].lower():
                continue
            self.collection_tree.insert("", "end", iid=str(x["fixId"]), values=(x["name"], x["quantity"], "Yes" if x["owned"] else "No", x["fixIdHex"]))
        self.collection_qty.set(str(g.get("recommendedQuantity", 1)))

    def on_collection_select(self, _event=None) -> None:
        sel = self.collection_tree.selection() if hasattr(self, "collection_tree") else ()
        g = self.current_collection_group()
        if not sel or not g:
            return
        try:
            fix = int(sel[0])
        except ValueError:
            return
        item = next((x for x in g.get("entries", []) if int(x.get("fixId", -1)) == fix), None)
        if item is None:
            return
        current = int(item.get("quantity", 0))
        recommended = int(g.get("recommendedQuantity", 1))
        self.collection_qty.set(str(current if current > 0 else recommended))

    def apply_collection_selected(self) -> None:
        sel = self.collection_tree.selection(); g = self.current_collection_group()
        if not sel or not g:
            messagebox.showinfo(APP_NAME, "Select a collection item first."); return
        try:
            fix = int(sel[0])
            qty = parse_int(self.collection_qty.get(), "Quantity", 1, 99)
        except (ValueError, TypeError) as exc:
            messagebox.showerror(APP_NAME, str(exc))
            return
        self.inventory_edits.pop(fix, None)
        self.collection_edits[fix] = {"kind": g["kind"], "fixId": fix, "quantity": qty}
        self.apply_changes("Collection item applied.")

    def apply_collection_all(self) -> None:
        g = self.current_collection_group()
        if not g: return
        if not messagebox.askyesno(
            APP_NAME,
            f"Apply the recommended quantity to every entry in {g['kind']}?",
            icon="warning",
        ):
            return
        qty = int(g.get("recommendedQuantity", 1))
        for x in g.get("entries", []):
            fix = int(x["fixId"])
            self.inventory_edits.pop(fix, None)
            self.collection_edits[fix] = {"kind": g["kind"], "fixId": fix, "quantity": qty}
        self.apply_changes(f"All {g['kind']} entries applied.")

    def build_inventory(self, p: ttk.Frame) -> None:
        self.heading(p, "Inventory", "Edit verified materials, consumables, tokens, quest rewards, and multiplayer materials.")
        if not self.require_save(p):
            return
        groups = (self.summary or {}).get("inventoryGroups", [])
        top = ttk.Frame(p); top.pack(fill="x", pady=(0, 8))
        self.inventory_group = tk.StringVar(value=groups[0]["kind"] if groups else "")
        ttk.Label(top, text="Group").pack(side="left")
        cb = ttk.Combobox(top, textvariable=self.inventory_group, values=[g["kind"] for g in groups], state="readonly", width=30)
        cb.pack(side="left", padx=8); cb.bind("<<ComboboxSelected>>", lambda _e: self.refresh_inventory_tree())
        self.inventory_search = tk.StringVar()
        inventory_entry = ttk.Entry(top, textvariable=self.inventory_search, width=30)
        inventory_entry.pack(side="left", padx=8)
        inventory_entry.bind("<Return>", lambda _e: self.refresh_inventory_tree())
        ttk.Button(top, text="Search", command=self.refresh_inventory_tree).pack(side="left")
        ttk.Button(top, text="Apply Max All", command=self.apply_inventory_all).pack(side="right")

        inventory_table = ttk.Frame(p)
        inventory_table.pack(fill="both", expand=True)
        self.inventory_tree = ttk.Treeview(inventory_table, columns=("name", "qty", "owned", "fix"), show="headings")
        for col, text, width in [("name", "Item", 520), ("qty", "Qty", 70), ("owned", "Owned", 80), ("fix", "FixID", 120)]:
            self.inventory_tree.heading(col, text=text); self.inventory_tree.column(col, width=width, anchor="w")
        inventory_scroll = ttk.Scrollbar(inventory_table, orient="vertical", command=self.inventory_tree.yview)
        self.inventory_tree.configure(yscrollcommand=inventory_scroll.set)
        self.inventory_tree.pack(side="left", fill="both", expand=True)
        inventory_scroll.pack(side="right", fill="y")
        self.inventory_tree.bind("<<TreeviewSelect>>", self.on_inventory_select)
        bottom = ttk.Frame(p); bottom.pack(fill="x", pady=10)
        self.inventory_owned = tk.BooleanVar(value=True); self.inventory_qty = tk.StringVar(value="99")
        ttk.Checkbutton(bottom, text="Owned", variable=self.inventory_owned).pack(side="left")
        ttk.Label(bottom, text="Quantity").pack(side="left", padx=(12, 3))
        ttk.Entry(bottom, textvariable=self.inventory_qty, width=8).pack(side="left")
        ttk.Button(bottom, text="Apply selected", style="Accent.TButton", command=self.apply_inventory_selected).pack(side="left", padx=8)
        self.refresh_inventory_tree()

    def current_inventory_group(self) -> dict[str, Any] | None:
        for g in (self.summary or {}).get("inventoryGroups", []):
            if g["kind"] == self.inventory_group.get(): return g
        return None

    def refresh_inventory_tree(self) -> None:
        if not hasattr(self, "inventory_tree"): return
        self.inventory_tree.delete(*self.inventory_tree.get_children())
        g = self.current_inventory_group()
        if not g: return
        q = self.inventory_search.get().lower().strip()
        for x in g.get("entries", []):
            if q and q not in x["name"].lower() and q not in x["fixIdHex"].lower(): continue
            self.inventory_tree.insert("", "end", iid=str(x["fixId"]), values=(x["name"], x["quantity"], "Yes" if x["owned"] else "No", x["fixIdHex"]))
        self.inventory_qty.set(str(g.get("recommendedQuantity", 99)))

    def on_inventory_select(self, _event=None) -> None:
        sel = self.inventory_tree.selection() if hasattr(self, "inventory_tree") else ()
        g = self.current_inventory_group()
        if not sel or not g:
            return
        try:
            fix = int(sel[0])
        except ValueError:
            return
        item = next((x for x in g.get("entries", []) if int(x.get("fixId", -1)) == fix), None)
        if item is None:
            return
        owned = bool(item.get("owned"))
        self.inventory_owned.set(owned)
        current = int(item.get("quantity", 0))
        recommended = int(g.get("recommendedQuantity", 99))
        self.inventory_qty.set(str(current if owned and current > 0 else recommended))

    def apply_inventory_selected(self) -> None:
        sel = self.inventory_tree.selection(); g = self.current_inventory_group()
        if not sel or not g:
            messagebox.showinfo(APP_NAME, "Select an inventory item first."); return
        try:
            fix = int(sel[0])
            owned = bool(self.inventory_owned.get())
            qty = parse_int(self.inventory_qty.get(), "Quantity", 1, 99) if owned else 0
        except (ValueError, TypeError) as exc:
            messagebox.showerror(APP_NAME, str(exc))
            return
        self.collection_edits.pop(fix, None)
        self.inventory_edits[fix] = {"kind": g["kind"], "fixId": fix, "owned": owned, "quantity": qty}
        self.apply_changes("Inventory item applied.")

    def apply_inventory_all(self) -> None:
        g = self.current_inventory_group()
        if not g: return
        if not messagebox.askyesno(
            APP_NAME,
            f"Set every verified item in {g['kind']} to owned with its maximum/recommended quantity?",
            icon="warning",
        ):
            return
        qty = int(g.get("recommendedQuantity", 99))
        qty = max(1, min(99, qty))
        for x in g.get("entries", []):
            fix = int(x["fixId"])
            self.collection_edits.pop(fix, None)
            self.inventory_edits[fix] = {"kind": g["kind"], "fixId": fix, "owned": True, "quantity": qty}
        self.apply_changes(f"Maximum applied for {g['kind']}.")

    def build_database(self, p: ttk.Frame) -> None:
        self.heading(p, "Database", "Search the verified item, equipment, and ability catalog. This page is read-only.")
        top = ttk.Frame(p); top.pack(fill="x", pady=(0, 8))
        self.db_search = tk.StringVar()
        db_entry = ttk.Entry(top, textvariable=self.db_search, width=45)
        db_entry.pack(side="left")
        db_entry.bind("<Return>", lambda _e: self.refresh_database())
        ttk.Button(top, text="Search", command=self.refresh_database).pack(side="left", padx=8)
        self.db_count = ttk.Label(top, text="", style="Muted.TLabel")
        self.db_count.pack(side="right")
        database_table = ttk.Frame(p)
        database_table.pack(fill="both", expand=True)
        self.db_tree = ttk.Treeview(database_table, columns=("kind", "name", "category", "fix", "bank"), show="headings")
        for col, text, width in [("kind", "Kind", 100), ("name", "Name", 470), ("category", "Category", 180), ("fix", "FixID", 120), ("bank", "Bank", 70)]:
            self.db_tree.heading(col, text=text); self.db_tree.column(col, width=width, anchor="w")
        database_scroll = ttk.Scrollbar(database_table, orient="vertical", command=self.db_tree.yview)
        self.db_tree.configure(yscrollcommand=database_scroll.set)
        self.db_tree.pack(side="left", fill="both", expand=True)
        database_scroll.pack(side="right", fill="y")
        self.after_idle(self._refresh_database_if_alive)

    def _refresh_database_if_alive(self) -> None:
        tree = getattr(self, "db_tree", None)
        try:
            if tree is not None and tree.winfo_exists():
                self.refresh_database()
        except tk.TclError:
            return

    def refresh_database(self) -> None:
        if not hasattr(self, "db_tree"): return
        if self.catalog_rows is None:
            try:
                self.catalog_rows = self.core.catalog()
            except CoreError as exc:
                messagebox.showerror(APP_NAME, str(exc)); return
        self.db_tree.delete(*self.db_tree.get_children())
        q = self.db_search.get().lower().strip()
        shown = 0
        matched = 0
        for x in self.catalog_rows:
            text = f"{x.get('kind','')} {x.get('name','')} {x.get('category','')} {x.get('fixIdHex','')}".lower()
            if q and q not in text:
                continue
            matched += 1
            if shown < 1000:
                self.db_tree.insert("", "end", values=(x.get("kind"), x.get("name"), x.get("category"), x.get("fixIdHex"), x.get("bank")))
                shown += 1
        if hasattr(self, "db_count"):
            suffix = " (first 1,000 shown)" if matched > 1000 else ""
            self.db_count.config(text=f"{matched:,} match{'es' if matched != 1 else ''}{suffix}")

    def build_about(self, p: ttk.Frame) -> None:
        self.heading(p, f"{APP_NAME} v{APP_VERSION}", "Modern FFXV COMRADES save editing with verified apply/encrypt workflow and source-safe export.")
        card = ttk.Frame(p, style="Card.TFrame", padding=22)
        card.pack(fill="x", pady=8)
        ttk.Label(card, text="FINAL FANTASY XV COMRADES", style="Card.TLabel", font=("Segoe UI Semibold", 18)).pack(anchor="w")
        ttk.Label(card, text="SAVE EDITOR", style="Card.TLabel", font=("Segoe UI Semibold", 12)).pack(anchor="w", pady=(2, 14))
        text = (
            "Included editing: Gil, kW, persistent Glaive stats, active-player weapon stats and verified weapon abilities, initialized character abilities, "
            "verified Sigil ownership, collections, inventory, and database browsing.\n\n"
            "The Weapons page targets owned records available to the active Glaive and preserves identity plus unknown/internal fields.\n\n"
            "Apply writes edits to a verified working copy. SAVE FILES protects the originally opened save, creates backups when replacing an existing destination file, and exports every modified save file."
        )
        ttk.Label(card, text=text, style="Card.TLabel", wraplength=900, justify="left").pack(anchor="w")

    def rebuild_page_and_show(self, name: str) -> None:
        old = self.pages.pop(name, None)
        if old: old.destroy()
        self.show_page(name)


if __name__ == "__main__":
    app = EditorApp()
    app.mainloop()
