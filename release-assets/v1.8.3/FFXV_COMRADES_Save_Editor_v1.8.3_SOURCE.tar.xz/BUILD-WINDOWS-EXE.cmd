@echo off
setlocal
cd /d "%~dp0"
echo =====================================================
echo  FFXV COMRADES Save Editor v1.8.2 - Windows Build
echo =====================================================

echo [1/5] Checking Python 3.11+...
python -c "import sys; raise SystemExit(0 if sys.version_info >= (3,11) else 1)" >nul 2>&1 || (
  echo ERROR: Python 3.11 or newer is required.
  pause
  exit /b 1
)
python --version

echo [2/5] Checking required bundled files...
if not exist "Bundled\ForgeCore.exe" (
  echo ERROR: Bundled\ForgeCore.exe is missing.
  pause
  exit /b 1
)
if not exist "assets\app_icon.ico" (
  echo ERROR: assets\app_icon.ico is missing.
  pause
  exit /b 1
)
if not exist "assets\comrades_header.png" (
  echo ERROR: assets\comrades_header.png is missing.
  pause
  exit /b 1
)

echo [3/5] Compiling Python sources...
python -m py_compile app.py forge_core.py FFXV_COMRADES_Save_Editor.pyw || goto :fail

echo [4/5] Checking PyInstaller...
python -m pip show pyinstaller >nul 2>&1 || (
  echo PyInstaller is not installed. Attempting installation...
  python -m pip install --user pyinstaller || goto :fail
)

echo [5/5] Building single EXE...
python -m PyInstaller --noconfirm --clean --windowed --onefile ^
  --name "FFXV_COMRADES_Save_Editor" ^
  --icon "assets\app_icon.ico" ^
  --add-binary "Bundled\ForgeCore.exe;Bundled" ^
  --add-data "assets;assets" ^
  FFXV_COMRADES_Save_Editor.pyw || goto :fail
if not exist "dist\FFXV_COMRADES_Save_Editor.exe" goto :fail

echo.
echo SUCCESS:
echo %CD%\dist\FFXV_COMRADES_Save_Editor.exe
echo.
pause
exit /b 0

:fail
echo.
echo BUILD FAILED.
pause
exit /b 1
