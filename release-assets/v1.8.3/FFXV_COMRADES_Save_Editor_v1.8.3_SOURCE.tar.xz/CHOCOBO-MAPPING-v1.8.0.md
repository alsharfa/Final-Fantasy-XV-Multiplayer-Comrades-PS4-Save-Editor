# Chocobo Mapping — v1.8.2 Live-Save Verification

The ChocoboDataStruct schema contains fixed arrays. The physical save serializer writes a 4-byte array count before each array, which shifts later scalar fields. Consecutive bools are bit-packed. v1.8.0 did not account for this and therefore read the level fields from the wrong bytes.

## Verified physical offsets

- +0x10: Stamina (int32)
- +0x14: Jump (int32)
- +0x18: Top Speed (float32)
- +0x48: Skill Level (int16)
- +0x4A: Limit Max Level (int16)
- +0x4C: Level Cap / Max Level (int16)
- +0x4E: Current Level (int16)
- +0x50: Injury Percent (int16)
- +0x52: packed isNew / isInjured bool byte
- +0x61: Training Rate Count (int16)

## Live save evidence

Supplied gameplay0(20260918-154201).save matches the screenshot exactly for the first two visible birds:

- Black Chocobo, NameID 0x0B01D0C1: Level 46/50, Limit Max 70, Stamina 82, Jump 202, Speed ~40.53 mph.
- Blue Chocobo, NameID 0x0B01D0C3: Level 20/30, Limit Max 50, Stamina 23, Jump 24, Speed 22.0 mph.

The save contains additional serialized chocobo records beyond the two shown in the training screenshot. Their visibility/registration semantics are not yet proven, so the editor does not create new records and does not guess their color names.
