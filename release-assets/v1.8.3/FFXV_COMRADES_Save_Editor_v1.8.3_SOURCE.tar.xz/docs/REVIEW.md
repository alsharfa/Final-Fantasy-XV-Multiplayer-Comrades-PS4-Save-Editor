# Deep review — v1.7.0

The v1.7.0 pass reviewed frontend state management, export safety, backend invocation, weapon-instance selection, signed stat mapping, input validation, responsive layout, and save-set handling.

## High-impact defects corrected

1. **Signed weapon resistance regression** — negative stored resistance values could be converted to positive display/write values by unrelated edits. v1.7.0 preserves sign correctly.
2. **Duplicate weapon UI collision** — identical weapon names/instances could collide in the selector map. Instances are now disambiguated as separate copies while preserving the exact selected record.
3. **Failed Apply contamination** — a failed backend edit could leave a temporary request that affected the next operation. Temporary edit payloads are cleared on failure.
4. **Stale avatar export** — changing the loaded avatar could leave an earlier edited avatar queued. Reloading avatar data now resets that pending export state.
5. **Unsafe output destination** — exporting to the source save directory could risk overwriting source files. Source-directory export is redirected to a MODDED destination and existing destination files are backed up first.
6. **Backend robustness** — Core subprocess calls now have timeouts and clearer failures; the GUI checks for the exact `2.8.0-wpf` protocol before editing.
7. **Input handling** — malformed Collection/Inventory quantity text is now validated instead of becoming an uncaught exception; bulk actions require confirmation.
8. **UI stale-state issues** — Database and Abilities/Sigils selection state was hardened, table scrollbars were made explicit, and Database shows result counts.
9. **Preset ceiling mismatch** — the kW Max action now uses the verified signed-int ceiling `2,147,483,647`.
10. **Responsive GUI** — the branded UI was tightened so key weapon controls remain visible at smaller desktop resolutions around 1000×700.

## Weapon ability mapping retained

- Penetrator X = `0x0105E7CA`
- Punisher II = `0x0105CE8F`
- COMRADES renders the two serialized ability links in reverse left/right display order. The frontend compensates for this.

## Validation outcome

Python compilation, Go tests, Go vet, Go race tests, all-page GUI smoke tests, resistance-sign preservation, export safety, avatar export reset, failed-Apply cleanup and controlled Parrying Daggers weapon editing all pass in the review environment.
