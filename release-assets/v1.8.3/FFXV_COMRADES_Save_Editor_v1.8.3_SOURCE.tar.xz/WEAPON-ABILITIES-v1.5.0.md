# Weapon abilities — v1.5.0

The Python Weapons page now edits both serialized weapon ability slots by name.

## Verified real-name mappings

| In-game name | FixID |
| --- | --- |
| None | `0x01009E27` |
| Penetrator X | `0x0105CE8F` |
| Punisher II | `0x0105E7CA` |

`Penetrator X` and `Punisher II` were verified against the supplied Parrying Daggers controlled save/screenshot pair. The backend's raw labels for these IDs do not match the localized names shown by the game, so v1.5.0 does not guess names for the rest of the internal `ENC_*` catalog.

If a loaded weapon contains another ability ID, the editor displays it as **Current / unmapped** and preserves it unless the user deliberately selects one of the verified real-name choices.

MAX ALL does not change Ability 1 or Ability 2.
