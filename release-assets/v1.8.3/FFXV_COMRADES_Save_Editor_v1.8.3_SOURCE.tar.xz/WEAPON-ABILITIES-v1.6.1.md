# Weapon abilities — v1.6.1 correction

A controlled in-game retest showed that v1.5.0/v1.6.0 had two related mistakes:

1. The real-name FixID labels for Penetrator X and Punisher II were reversed.
2. The two serialized `SaveWeaponStruct` ability links are displayed by COMRADES in the opposite left-to-right order.

## Corrected verified mapping

| In-game name | FixID |
| --- | --- |
| None | `0x01009E27` |
| Penetrator X | `0x0105E7CA` |
| Punisher II | `0x0105CE8F` |

## Visible slot mapping

- Editor **Ability 1** (left in game) reads/writes serialized `ability2`.
- Editor **Ability 2** (right in game) reads/writes serialized `ability1`.

This matches the controlled Parrying Daggers save where serialized `ability1=0x0105CE8F` and `ability2=0x0105E7CA`, while the game displays **Penetrator X** on the left and **Punisher II** on the right.

Unknown ability IDs remain preserved. `MAX ALL` does not change either ability.
