# Player weapon mapping used by v1.3.0

The Python weapon editor is based on the supplied before/after saves and the verified COMRADES `SaveWeaponStruct` parser.

| UI field | Save field |
|---|---|
| Current Level | `RemodelFailCount` (old/misleading schema name) |
| Level Cap | `status_adjust[17]` |
| Attack | direct weapon Attack / `Strength` scalar in the old parser |
| STR | `status_adjust[0]` |
| VIT | `status_adjust[1]` |
| MAG | `status_adjust[2]` |
| SPI | `status_adjust[3]` |
| HP bonus | `status_adjust[4]` |
| MP bonus | `status_adjust[6]` |
| Shot resistance | `status_adjust[11]`, stored negative |
| Fire resistance | `status_adjust[12]`, stored negative |
| Ice resistance | `status_adjust[13]`, stored negative |
| Lightning resistance | `status_adjust[14]`, stored negative |
| Dark resistance | `status_adjust[15]`, stored negative |

The editor does not synthesize or rewrite the weapon identity, internal Rank, resident ability, raw slot field, or unknown status entries. Ability IDs are shown but preserved in v1.3.0 pending a clean localized-name mapping.
