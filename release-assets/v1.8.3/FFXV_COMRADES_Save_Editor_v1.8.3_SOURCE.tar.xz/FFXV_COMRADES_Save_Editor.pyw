from app import EditorApp

EditorApp().mainloop()
